-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: es577.mirohost.net
-- Время создания: Дек 15 2020 г., 18:38
-- Версия сервера: 10.2.36-MariaDB-10.2.36+maria~jessie-log
-- Версия PHP: 7.3.19-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `toyotalara`
--

-- --------------------------------------------------------

--
-- Структура таблицы `available_cars`
--

CREATE TABLE IF NOT EXISTS `available_cars` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT NULL,
  `modification_id` int(11) DEFAULT NULL,
  `engine_id` int(11) DEFAULT NULL,
  `gearbox_id` int(11) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `main_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interior_id` int(11) DEFAULT NULL,
  `drive_type_id` int(11) DEFAULT NULL,
  `body_type_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `available_cars`
--

INSERT INTO `available_cars` (`id`, `model_id`, `modification_id`, `engine_id`, `gearbox_id`, `color_id`, `year`, `price`, `main_image`, `image`, `country`, `interior_id`, `drive_type_id`, `body_type_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 8, 30, 15, 7, 23, 2020, 1845700, 'available-cars/August2020/JCIiOB1o6NnPcGztEUSQ.JPG', '[\"available-cars\\/August2020\\/sE4ZwcGQCJ9sUzLs5fHp.JPG\",\"available-cars\\/August2020\\/lWfwwvbG3p8D3FXRZl9f.JPG\",\"available-cars\\/August2020\\/58YzMidbemOdxy2gyLgh.JPG\",\"available-cars\\/August2020\\/DHZAFGDzKnv3TPOdByv6.JPG\",\"available-cars\\/August2020\\/jracraJkQW1L6apFUmVl.JPG\",\"available-cars\\/August2020\\/UFWfIxWUau83ydYXfjKl.JPG\",\"available-cars\\/August2020\\/irrPhvHyZDI7qpbYpTDN.JPG\",\"available-cars\\/August2020\\/WARB3A6Vju2WpNnMli5G.JPG\",\"available-cars\\/August2020\\/F2Dz50Md93vX9Hk9g8OD.JPG\",\"available-cars\\/August2020\\/CWfaQU3ESiQDV6i3VV6I.JPG\",\"available-cars\\/August2020\\/XQYUMkbWikBouC3acxFV.JPG\",\"available-cars\\/August2020\\/LDD0JPROO0Bji9T88cqy.JPG\",\"available-cars\\/August2020\\/NoUaZujn6v1iPZCYTT1B.JPG\",\"available-cars\\/August2020\\/PyVROSiMVw5aFAoZ0bO4.JPG\",\"available-cars\\/August2020\\/AQwnUiF5sUaG9yyKIMPw.JPG\",\"available-cars\\/August2020\\/ACFvz7I3Fz5PHESiA88e.JPG\"]', NULL, NULL, 3, 5, NULL, '2020-09-29 05:15:33', '2020-09-29 05:15:33'),
(7, 7, 26, 14, 7, 23, 2020, 1187310, 'available-cars/August2020/RlS67P69CuMAmCI2SDYx.jpeg', '[\"available-cars\\/August2020\\/1P9tmeldtDbocsdUpmOw.jpeg\",\"available-cars\\/August2020\\/O7PCn5rTYw1GJuowuE5j.jpeg\",\"available-cars\\/August2020\\/tsoWepntwzg8dfPdyMgK.jpeg\",\"available-cars\\/August2020\\/bSe1H7vC3EFjWXJtmoLO.jpeg\",\"available-cars\\/August2020\\/naaF2C567zUfXW3Oa6Me.jpeg\",\"available-cars\\/August2020\\/ca0ZLPY4rhYi3ZPMadVj.jpeg\",\"available-cars\\/August2020\\/tbVL0sCH332SOhSNbDYY.jpeg\",\"available-cars\\/August2020\\/E3hu56MAnAKYsSQt2jdz.jpeg\",\"available-cars\\/August2020\\/Isp0OlRCCSmYn6kEFolD.jpeg\",\"available-cars\\/August2020\\/Z7R5rF3u8UuQm4jSM3U5.jpeg\",\"available-cars\\/August2020\\/GAo0wGtRjmBnDlt40cBE.jpeg\",\"available-cars\\/August2020\\/f2Hh6TEMHMUdQ8eOKVQi.jpeg\"]', NULL, NULL, 3, 5, '2020-05-08 09:19:42', '2020-09-29 05:16:29', '2020-09-29 05:16:29'),
(8, 7, 27, 13, NULL, NULL, 2019, 1551050, 'available-cars/May2020/z56CmbclU2YyfCC5lnWw.JPG', '[\"available-cars\\/May2020\\/PyFUZo6YFqa7iXQ26nIl.JPG\",\"available-cars\\/May2020\\/Jzsef0HJ0RFOt57TdVtH.JPG\",\"available-cars\\/May2020\\/X7uTYWDS7sp6yu3v4F44.JPG\",\"available-cars\\/May2020\\/GjmzqrDWCeDx3LzKyowZ.JPG\"]', NULL, NULL, 3, NULL, '2020-05-15 04:57:53', '2020-08-25 09:22:07', '2020-08-25 09:22:07'),
(9, 5, 22, 16, 6, 12, 2020, 1298080, 'available-cars/August2020/6WMkmlGd5UTdFFjnppDe.jpeg', '[\"available-cars\\/August2020\\/kIDbq6bqlpreqV6i1rzF.jpeg\",\"available-cars\\/August2020\\/gM5s0anh8cfat1wfTK9O.jpeg\",\"available-cars\\/August2020\\/62bFxbogLeOd5fze0DWA.jpeg\",\"available-cars\\/August2020\\/EqIPKiBiCPDufHQygLRi.jpeg\",\"available-cars\\/August2020\\/AhOy6AFjAFHSpX2F8byk.jpeg\",\"available-cars\\/August2020\\/56JgajB9qijHN8BLpLFy.jpeg\",\"available-cars\\/August2020\\/Xytq5P9TwZf7q9icDXnk.jpeg\",\"available-cars\\/August2020\\/9aG9UCbe5Mzaw8HlUwQs.jpeg\",\"available-cars\\/August2020\\/e9dsvyUL0H3JCHvS2Ght.jpeg\",\"available-cars\\/August2020\\/DhgWfm3OOEDTYDqPGYUs.jpeg\",\"available-cars\\/August2020\\/OEWEe11bUZ3fVnio8AvT.jpeg\",\"available-cars\\/August2020\\/ZtZbwW3k98GKcnQpGNpc.jpeg\"]', NULL, NULL, 3, 1, '2020-05-15 05:08:30', '2020-11-09 12:38:13', NULL),
(10, 5, 21, 7, 6, 38, 2020, 1446200, 'available-cars/August2020/Polw5sDmS2BGNqoOTQDa.jpeg', '[\"available-cars\\/August2020\\/qRc8284ih3Vuqi5fkPGM.jpeg\",\"available-cars\\/August2020\\/EfkjIzR6WKsBfrY0xDvB.jpeg\",\"available-cars\\/August2020\\/tYyLwRSuyslj0gcdjz1u.jpeg\",\"available-cars\\/August2020\\/MWnj0OBWUBzWnC9oJaIZ.jpeg\",\"available-cars\\/August2020\\/Hb5d0X4UOpRL1g49TaJR.jpeg\",\"available-cars\\/August2020\\/40YLdVAHLas07GERLo34.jpeg\",\"available-cars\\/August2020\\/PIr0UHosgN8rNZi8f475.jpeg\",\"available-cars\\/August2020\\/6ysqASwmoQoyMzMFJVub.jpeg\",\"available-cars\\/August2020\\/d6IHMGfkscTUJwAqY01X.jpeg\",\"available-cars\\/August2020\\/ChU13aNtgWSR8WrM6pn6.jpeg\",\"available-cars\\/August2020\\/bZJJulxclNIvf65bhjGV.jpeg\",\"available-cars\\/August2020\\/pHobYrEySSRx21VZ5p4X.jpeg\",\"available-cars\\/August2020\\/KbhHke9n6AdN5CxC2ccF.jpeg\",\"available-cars\\/August2020\\/2L7W139oPhaMLbt8KB7T.jpeg\",\"available-cars\\/August2020\\/JtP2CBPFtN2qEFbNiTI4.jpeg\",\"available-cars\\/August2020\\/bFGr5D4z3cqnyJjSCmRQ.jpeg\"]', 'Японія', NULL, 3, 1, '2020-05-25 06:12:59', '2020-11-25 11:26:13', '2020-11-25 11:26:13'),
(12, 9, 35, 14, 7, 15, 2020, 1373490, 'available-cars/August2020/0iCDKVyXX44UsLu6HaeL.jpeg', '[\"available-cars\\/August2020\\/uFk8t8aVS6OBGQhqUwXO.jpeg\",\"available-cars\\/August2020\\/oM2BXd4nkN4HaH6ahne4.jpeg\",\"available-cars\\/August2020\\/pwwecPgwjtrlnMKf85q4.jpeg\",\"available-cars\\/August2020\\/gsfjjG45sWnmVq6zjTK9.jpeg\",\"available-cars\\/August2020\\/adYUgnzSBIPi01xfabSB.jpeg\",\"available-cars\\/August2020\\/bWK0agvbsX8TQynPbniw.jpeg\",\"available-cars\\/August2020\\/ciXVtzWnvKFs6k9iSZ6i.jpeg\",\"available-cars\\/August2020\\/AVgXRDoqyt80gjd3PL2Z.jpeg\",\"available-cars\\/August2020\\/sfgPJzsGKoDxAhOdBzG2.jpeg\",\"available-cars\\/August2020\\/gbh4cP1BKM4uwdTBAAEm.jpeg\",\"available-cars\\/August2020\\/OZUzALxWWiv6pvILNn2F.jpeg\",\"available-cars\\/August2020\\/qWDOZbUcYKmxszPxEJSP.jpeg\",\"available-cars\\/August2020\\/NVyoduyzVvWUhasTcUUf.jpeg\",\"available-cars\\/August2020\\/DH76R7Hg8rmbQOeZRi83.jpeg\",\"available-cars\\/August2020\\/wyEgAYceFW8fD18PrKwG.jpeg\",\"available-cars\\/August2020\\/5DVsC3aMVoW7ZAceGKrB.jpeg\",\"available-cars\\/August2020\\/beWm7hfqS4yH06H3PPrZ.jpeg\",\"available-cars\\/August2020\\/OvjnT1WHy0yVftxCoZ2h.jpeg\",\"available-cars\\/August2020\\/86zT5OAJgm0oTRddaeeJ.jpeg\"]', NULL, NULL, 3, 4, '2020-05-25 06:19:24', '2020-11-03 09:47:44', '2020-11-03 09:47:44'),
(14, 8, 37, 17, 7, NULL, 2020, 2324580, 'available-cars/August2020/2yjIb3JgDewHLwsXRIZl.jpeg', '[\"available-cars\\/August2020\\/Z6FaoDbHVe7kBnY8IVd1.jpeg\",\"available-cars\\/August2020\\/SHUxqG0NYO752RpOED8S.jpeg\",\"available-cars\\/August2020\\/xF6ZGnoo0VvopT4vRRye.jpeg\",\"available-cars\\/August2020\\/47dRXA2EqxJUVaRDALWb.jpeg\",\"available-cars\\/August2020\\/hIJ4wQNMikRfjgY7Kw6B.jpeg\",\"available-cars\\/August2020\\/9rW6TgDjPF5ao8lMSC0G.jpeg\",\"available-cars\\/August2020\\/javCRGvT4ZotplBBSOvu.jpeg\",\"available-cars\\/August2020\\/ibuOLc592x3WJxHaOhlo.jpeg\",\"available-cars\\/August2020\\/YnHJIWqjqzcKVaB6zopg.jpeg\",\"available-cars\\/August2020\\/zIQBJtv89MOZLpaVx8qp.jpeg\",\"available-cars\\/August2020\\/dVzO8H37JNPAB1oovOOe.jpeg\",\"available-cars\\/August2020\\/QSGpO9T6UplXuZnpsmZN.jpeg\",\"available-cars\\/August2020\\/x1HMwvAYJuT0AlClNjKe.jpeg\",\"available-cars\\/August2020\\/cmYcdfvuOxTnsGgWW680.jpeg\",\"available-cars\\/August2020\\/CLFvIbdhq94KOi5fL3sA.jpeg\",\"available-cars\\/August2020\\/M241G4TAbEnynfzBJEI2.jpeg\",\"available-cars\\/August2020\\/4bkwnFzcqUpNyYSJQIBR.jpeg\",\"available-cars\\/August2020\\/tkj4VLIvdvMoDZtPw8M8.jpeg\"]', NULL, NULL, 3, 5, '2020-08-18 06:28:06', '2020-08-27 05:15:08', '2020-08-27 05:15:08'),
(15, 5, 18, 11, 9, 4, 2020, 773283, 'available-cars/August2020/7k2MNkrqcmXW1XhwC2O2.JPG', '[\"available-cars\\/August2020\\/o1cvIdhoMevKFStOeOb0.JPG\",\"available-cars\\/August2020\\/YwSn4ClsoLUnerY4gA0S.JPG\",\"available-cars\\/August2020\\/vDwL9qvHMzMz9G5oodR9.JPG\",\"available-cars\\/August2020\\/ulTgIggpm1x22jN2Q4Bn.JPG\",\"available-cars\\/August2020\\/LvOc6z85GAzJmPVcwiqQ.JPG\",\"available-cars\\/August2020\\/yFs4KEsjeuDnoZKCmaxX.JPG\",\"available-cars\\/August2020\\/cJ741QnvmlkKaxWORFTV.JPG\",\"available-cars\\/August2020\\/npeX6I2qcKrrKt2YxCV7.JPG\",\"available-cars\\/August2020\\/G8BzIwVTdMnm2YSYHBHl.JPG\",\"available-cars\\/August2020\\/XsCkNsATAEf3XFX0PrMx.JPG\",\"available-cars\\/August2020\\/3YwjVQhjAg9EWiJxAmQg.JPG\",\"available-cars\\/August2020\\/uHPc1O6uEY3Vvbv3w9Ix.JPG\",\"available-cars\\/August2020\\/Oy3rYVf9BivCnVu18M2Y.JPG\"]', NULL, NULL, 4, 1, '2020-08-28 05:15:26', '2020-11-03 10:29:02', '2020-11-03 10:29:02'),
(16, 2, 7, 10, 6, 5, 2020, 929763, 'available-cars/September2020/sG1WwRJ3Hbzmpv9PKG8m.jpeg', '[\"available-cars\\/September2020\\/JpT2YUhXOzayO7d6Sld5.jpeg\",\"available-cars\\/September2020\\/1e1bQPxvtIGh0xjVrJUw.jpeg\",\"available-cars\\/September2020\\/HgC5HQvvhoOGih9xsyoN.jpeg\",\"available-cars\\/September2020\\/N9okfRWfXQ3XxMWv5ogR.jpeg\",\"available-cars\\/September2020\\/DyfPK02uCpn5bI5FkpZ6.jpeg\",\"available-cars\\/September2020\\/7Dw0O4s2hyuop3QMvJZG.jpeg\",\"available-cars\\/September2020\\/fmMLvi6MpOTbcYlpJ2hG.jpg\"]', 'Туреччина', NULL, 4, 1, '2020-09-01 09:39:20', '2020-12-04 08:16:43', '2020-12-04 08:16:43'),
(17, 8, 37, 17, NULL, 12, 2020, 2463750, NULL, '[\"available-cars\\/September2020\\/Kfad4yQV0VMPfdaFkuGM.jpeg\",\"available-cars\\/September2020\\/rk4Ak8TUduEIR7Q2f6dG.jpeg\",\"available-cars\\/September2020\\/Epyk7xdsJwdbwBn3zbMk.jpeg\",\"available-cars\\/September2020\\/mm2E40meIzweOJVrFS7p.jpeg\",\"available-cars\\/September2020\\/vlxPmNERZ1fZ7At2Zhr6.jpeg\",\"available-cars\\/September2020\\/wlIA0hfrL3ClhDYLePi4.jpeg\",\"available-cars\\/September2020\\/hsZk5DPFWUeU6lSYSulX.jpeg\",\"available-cars\\/September2020\\/QFP3SRdDmsMyuOEUFNYM.jpeg\",\"available-cars\\/September2020\\/xtKn7xzO5qL20M2qnvur.jpeg\",\"available-cars\\/September2020\\/ouCOCbgCOdIqbskcq5yh.jpeg\",\"available-cars\\/September2020\\/nXVUuv4EmxYyKuFnCyOR.jpeg\",\"available-cars\\/September2020\\/gK583RiKJNBlPAIau2c6.jpeg\",\"available-cars\\/September2020\\/Np3tfDC823VxOt8NhCUd.jpeg\",\"available-cars\\/September2020\\/Y3kWIW07XHDUZNjMjJcN.jpeg\",\"available-cars\\/September2020\\/M2Jm1u7nXGQl00Sui6WX.jpeg\",\"available-cars\\/September2020\\/UvLUIekOpzJyYkgRqioP.jpeg\",\"available-cars\\/September2020\\/Ynn4zOPntupFrzxZ41BE.jpeg\"]', 'Японія', NULL, 3, 5, '2020-09-08 06:46:01', '2020-12-11 09:48:34', '2020-12-11 09:48:34'),
(18, 4, 13, 6, 8, 41, 2020, 808722, 'available-cars/September2020/WvKRWDpeLTtqENJitVQs.jpeg', '[\"available-cars\\/September2020\\/ZSVNhCAa7T7TSRfwUnXy.jpeg\",\"available-cars\\/September2020\\/QW8WIwYWwMsB2vNykjQZ.jpeg\",\"available-cars\\/September2020\\/vWOESr5eT1waP02KJE9p.jpeg\",\"available-cars\\/September2020\\/fJyRu2KVMxCeglhlMG9p.jpeg\",\"available-cars\\/September2020\\/xhg2X42ObqJsL1Y6LDy0.jpeg\",\"available-cars\\/September2020\\/fdv47ayOI7oqHiIu6Ba0.jpeg\",\"available-cars\\/September2020\\/D0N3oJO80bk1hVpip94F.jpeg\",\"available-cars\\/September2020\\/BuCIqBk9gmbDSeg5GkHR.jpeg\",\"available-cars\\/September2020\\/mhBZfQ8S77tVt8IZqyTG.jpeg\"]', NULL, NULL, 4, 3, '2020-09-28 07:08:00', '2020-11-03 09:47:49', '2020-11-03 09:47:49'),
(19, 3, 11, 9, 6, 4, 2020, 718562, 'available-cars/September2020/c2rbYIPcXUbiquROO4WH.jpeg', '[\"available-cars\\/September2020\\/Tffh8ika2IauXYvwz8Cu.jpeg\",\"available-cars\\/September2020\\/zrVUPtzhWWmAN4Q8jvUX.jpeg\",\"available-cars\\/September2020\\/JSEyy7eJKhmyOdOQe4F3.jpeg\",\"available-cars\\/September2020\\/UfH47sZpNRG6Pn38jvPH.jpeg\",\"available-cars\\/September2020\\/xYD3pBsQLZsAw4eUgriZ.jpeg\",\"available-cars\\/September2020\\/OqXCW63FYILDIMxhGrY5.jpeg\",\"available-cars\\/September2020\\/gGLbk96OfZmg5DxIkxYh.jpeg\",\"available-cars\\/September2020\\/gcBjjOEBZcfID2fLFH8x.jpeg\",\"available-cars\\/September2020\\/1uk7vEAwKFS4KCJocj1l.jpeg\",\"available-cars\\/September2020\\/bWUiGIluzb1xCjj9e2TA.jpeg\",\"available-cars\\/September2020\\/Oq0fb5t353l383H90Azl.jpeg\",\"available-cars\\/September2020\\/IOrac5PagrkxVLemCaIb.jpeg\",\"available-cars\\/September2020\\/a5ZRif2W0SyptHbmhDug.jpeg\",\"available-cars\\/September2020\\/0F48EaA0IYGQaCgiT1qk.jpeg\",\"available-cars\\/September2020\\/DSo0f5M4GJnBBvvwhbUP.jpeg\",\"available-cars\\/September2020\\/1rOACKYJPmWx4C7a2rhz.jpeg\",\"available-cars\\/September2020\\/m1CKdoihIo4gWok8uGl5.jpeg\",\"available-cars\\/September2020\\/znlmJgTyoSeU5MpWjFyT.jpeg\"]', 'Туреччина', NULL, 4, 3, '2020-09-29 05:13:23', '2020-11-25 08:41:28', NULL),
(20, 5, 19, 11, 4, 24, 2020, 842670, 'available-cars/October2020/5tqaY1mO7aNlYeeEOM5n.jpeg', '[\"available-cars\\/October2020\\/Zjbb2MeUX6YuUXcjPBw3.jpeg\",\"available-cars\\/October2020\\/DeY0GnvUVzYDlRtFNf5w.jpeg\",\"available-cars\\/October2020\\/5nuZkr4tAZlIEzEvtCbJ.jpeg\",\"available-cars\\/October2020\\/hRdqOVgMhxblUr8Uxhme.jpeg\",\"available-cars\\/October2020\\/sNB4VrgANuxXu2fkMSpx.jpg\",\"available-cars\\/October2020\\/aa9V9XJ7FJf3PPqTAhjM.jpg\",\"available-cars\\/October2020\\/bGwSQcdcCEb569VjX17R.jpg\",\"available-cars\\/October2020\\/NQFATzlD5qiW1J8tVZRm.jpg\",\"available-cars\\/October2020\\/tOFRwAHe9NAGJYiYLlfQ.jpg\",\"available-cars\\/October2020\\/YIO42cAYtGVN4yZYnH9Y.jpg\",\"available-cars\\/October2020\\/KMXOhYzCmJAHGDplY4E9.jpg\",\"available-cars\\/October2020\\/1f1VjA4x5nTgCkU1siuD.jpg\"]', NULL, NULL, 4, 1, '2020-10-15 06:46:55', '2020-11-03 09:47:55', '2020-11-03 09:47:55'),
(21, 7, NULL, 13, 7, 3, 2020, 1183410, 'available-cars/October2020/FHymlydz8UIaZCUw36do.jpeg', '[\"available-cars\\/October2020\\/kR6fTkTwwUJ2EqCHu7CV.jpeg\",\"available-cars\\/October2020\\/8CZMSbTQ3qoYCVqXHoOv.jpeg\",\"available-cars\\/October2020\\/boLm59HKOC1m7Afipf7k.jpeg\",\"available-cars\\/October2020\\/L2lh4ZTILA4SX6FCutPr.jpeg\",\"available-cars\\/October2020\\/bB5roQSuQy7tGNFT9AHU.jpeg\",\"available-cars\\/October2020\\/WXpV6eiseLW1UiyL68q7.jpeg\",\"available-cars\\/October2020\\/EohQSSALKDzqZ5dSyTPw.jpeg\",\"available-cars\\/October2020\\/BjV7GIuZTkDadSxqNy2U.jpeg\",\"available-cars\\/October2020\\/HNBsMUwt1TNQ6RPiGQhL.jpeg\",\"available-cars\\/October2020\\/01AS1uj1yiv1fiDzNAC3.jpeg\",\"available-cars\\/October2020\\/23P2boTLqShglWsRQyGb.jpeg\",\"available-cars\\/October2020\\/p3hGwMxTv1Ywxc7CYFUZ.jpeg\",\"available-cars\\/October2020\\/e7ZLKwwYrnutPeBkzul8.jpeg\",\"available-cars\\/October2020\\/7fq0aOQSxZPJfHpcqYDo.jpeg\",\"available-cars\\/October2020\\/EdGKfTDc1SNapnsZoKUx.jpeg\",\"available-cars\\/October2020\\/OTfnZNESZIsLMxbT0Xjx.jpeg\",\"available-cars\\/October2020\\/Txsb1hVhI01q3fzAJRhm.jpeg\",\"available-cars\\/October2020\\/Q9xC7sXCGJHgK2PWqt7c.jpeg\",\"available-cars\\/October2020\\/FE2v52bockCN2rpV8C94.jpeg\",\"available-cars\\/October2020\\/JD7QPUEo80qau7Y3CW4m.jpeg\",\"available-cars\\/October2020\\/31E83LUWnA1iHjL6ibyU.jpeg\",\"available-cars\\/October2020\\/Ka4My8j9Hsdb3NrbSKx4.jpeg\"]', NULL, NULL, 3, 5, '2020-10-27 09:46:23', '2020-10-30 08:30:01', '2020-10-30 08:30:01'),
(22, 7, 26, 13, 7, 3, 2020, 1183410, 'available-cars/October2020/BHbZsvKJCemKk6uvNRt6.jpeg', '[\"available-cars\\/October2020\\/hXgML928G1rVNjp4Y626.jpeg\",\"available-cars\\/October2020\\/p3PkwtOZJlPpnIKO6DA8.jpeg\",\"available-cars\\/October2020\\/e5a8XIvyqrVCKxIuLY5i.jpeg\",\"available-cars\\/October2020\\/tU7CWB8oxZ8XG5qEB5B7.jpeg\",\"available-cars\\/October2020\\/JcKuD7p9mYSnxyn1WT18.jpeg\",\"available-cars\\/October2020\\/QK5F5iUWANZwrDecPSaB.jpeg\",\"available-cars\\/October2020\\/jd7NIzrjAiDVOBKO9mQv.jpeg\",\"available-cars\\/October2020\\/cTpeQOwgZOE2kg5XBmOS.jpeg\",\"available-cars\\/October2020\\/W0sW8nFFc2D89Yrx31GY.jpeg\",\"available-cars\\/October2020\\/nH9V2oBIr8NJfy1u1ru4.jpeg\",\"available-cars\\/October2020\\/Zuy68arjnDFzcSLrNI7D.jpeg\",\"available-cars\\/October2020\\/G7z3LAevzXR1hHNdfvV3.jpeg\",\"available-cars\\/October2020\\/CubG6Hl1c3C04g3l3OW1.jpeg\",\"available-cars\\/October2020\\/8zQrfeFfHwQugsUxPuwT.jpeg\",\"available-cars\\/October2020\\/e43myk4msg3qdPCHW4ew.jpeg\",\"available-cars\\/October2020\\/a8n8AGzG1T9gjSU2RZWC.jpeg\",\"available-cars\\/October2020\\/rS5V8xCL56a11Gb6AYGl.jpeg\",\"available-cars\\/October2020\\/TCN4hcXyNG365HCCOXvy.jpeg\",\"available-cars\\/October2020\\/eJg8RDL3md2axP8G4uCb.jpeg\",\"available-cars\\/October2020\\/w8XgXCNz82HJHeZKkJKy.jpeg\",\"available-cars\\/October2020\\/7AJLmmzK8PjIStT4JdhS.jpeg\",\"available-cars\\/October2020\\/bmT8bbADXpKeNUuLmDlp.jpeg\"]', NULL, NULL, 3, 5, '2020-10-27 09:47:09', '2020-11-03 09:47:36', '2020-11-03 09:47:36'),
(23, 6, 24, 12, 11, 41, 2020, 1384810, 'available-cars/October2020/NpJz0Yphe1XpFUYh5pe9.jpeg', '[\"available-cars\\/October2020\\/8R7KYLMolp2Q5HeVePPo.jpeg\",\"available-cars\\/October2020\\/M5kYtKGsQVQWev8bPjAu.jpeg\",\"available-cars\\/October2020\\/mxVk4DW6oX00oDQfmxqy.jpeg\",\"available-cars\\/October2020\\/n2JUjK9YCo7OlOiXWCGs.jpeg\",\"available-cars\\/October2020\\/74efDIIfwfOJNO32Sqg5.jpeg\",\"available-cars\\/October2020\\/pxQg0oFY6kS6TgdX40oU.jpeg\",\"available-cars\\/October2020\\/Zdr2NK7Te9ZcLPJY5nYc.jpeg\",\"available-cars\\/October2020\\/ebz20GQoWepNAvtR8u41.jpeg\",\"available-cars\\/October2020\\/WGW0JGhXREy2dCIPGHfE.jpeg\",\"available-cars\\/October2020\\/y03LFY1oLbqdeMwVRSFZ.jpeg\",\"available-cars\\/October2020\\/BgCWXHGn6SkLAa0Fj3oF.jpeg\",\"available-cars\\/October2020\\/H3tUblKvfqQdeya5O8AE.jpeg\",\"available-cars\\/October2020\\/e8uBZEpDqubAAxdDF48W.jpeg\",\"available-cars\\/October2020\\/6oQgPfmMigTdApInPFlZ.jpeg\",\"available-cars\\/October2020\\/UO7pvZRSHGKFnkPCuTaS.jpeg\",\"available-cars\\/October2020\\/mGJN8GVNoas1p0LnYS7W.jpeg\",\"available-cars\\/October2020\\/WqJYOl32ea5h0JU4ITLp.jpeg\",\"available-cars\\/October2020\\/x5RJSJXXSVq1Sh0ZWKLY.jpeg\",\"available-cars\\/October2020\\/VOe753V7oLXy2EGuinhB.jpeg\",\"available-cars\\/October2020\\/rEeJGm6FsoAoapnKfyj4.jpeg\",\"available-cars\\/October2020\\/U9njIdIfsNIJOQApdHbH.jpeg\",\"available-cars\\/October2020\\/sp9cgIhmfd1hJpxjK10R.jpeg\",\"available-cars\\/October2020\\/pjgVidGj9KOnm9tdfX8v.jpeg\",\"available-cars\\/October2020\\/PHvdxcoiLvHpFFnzFAqd.jpeg\",\"available-cars\\/October2020\\/cwaJt8NNIEpa13fvN93x.jpeg\",\"available-cars\\/October2020\\/1FYG4Jq0XbTS0ZZxIiVD.jpeg\",\"available-cars\\/October2020\\/QHLEA3mjVZ9KeuOKeBVP.jpeg\",\"available-cars\\/October2020\\/fdNePOBKkUQnlEnSEEVb.jpeg\",\"available-cars\\/October2020\\/jXrGf8R49D8TtehIE1jY.jpeg\",\"available-cars\\/October2020\\/tSdKDAPxYcUR03MmWenr.jpeg\",\"available-cars\\/October2020\\/PNZijfKnmRnx3e1M3J7X.jpeg\",\"available-cars\\/October2020\\/NWx8fhr4KMadd8K9O11Q.jpeg\",\"available-cars\\/October2020\\/9dIB3J8bgZnEgiw8t1tI.jpeg\"]', 'США', NULL, 3, 1, '2020-10-30 13:04:28', '2020-11-25 08:40:33', NULL),
(24, 5, 20, 11, 10, 12, 2020, 1016190, 'available-cars/November2020/abSunaUDNeOt06UMOz9d.jpeg', '[\"available-cars\\/November2020\\/ChrY5mcDJw9bTjlMoRBH.jpeg\",\"available-cars\\/November2020\\/346QNWZC9nFi9FoRDpfR.jpeg\",\"available-cars\\/November2020\\/SxNyQ00apJlh0kCYS5sz.jpeg\",\"available-cars\\/November2020\\/4VfyIUNmwIyIw1SDy4T9.jpeg\",\"available-cars\\/November2020\\/E8el2MBEPE1VdcRErUsU.jpeg\",\"available-cars\\/November2020\\/IvHdn8NcrB4nt8w9uyz3.jpeg\",\"available-cars\\/November2020\\/1tK2Q16ZSsXgDi3qJbUm.jpeg\",\"available-cars\\/November2020\\/VtdKRdBAF7595VCBOmkz.jpeg\",\"available-cars\\/November2020\\/sNSHGMOthzlEJHADxhXK.jpeg\",\"available-cars\\/November2020\\/uONuDLTnQ5Uy1BNKQGrE.jpeg\"]', 'Японія', NULL, 3, NULL, '2020-11-09 12:35:32', '2020-11-25 08:43:51', NULL),
(25, 5, 41, 7, 7, 6, 2020, 1207370, 'available-cars/November2020/s0eAee59VoaNfnWKr3Dh.jpeg', '[\"available-cars\\/November2020\\/HpRJtwBxiopPWQJENAK3.jpeg\",\"available-cars\\/November2020\\/L7Gp0bGVRgcAwN29zRPv.jpeg\",\"available-cars\\/November2020\\/LadraVvi1VZY8ixs5zlN.jpeg\",\"available-cars\\/November2020\\/XaCjnG9oexvLw5xIm9L8.jpeg\",\"available-cars\\/November2020\\/tWMMdbY8SKNhbRrtu2eJ.jpeg\",\"available-cars\\/November2020\\/X6qCQP7KG6GWp6vMl5MF.jpeg\",\"available-cars\\/November2020\\/um2oZ9wCqAau5vyPF3LZ.jpeg\",\"available-cars\\/November2020\\/BVp4njJDaMJCkPNIxkQK.jpeg\",\"available-cars\\/November2020\\/uR14zXwDff4pkjgVBVnO.jpeg\",\"available-cars\\/November2020\\/Mbm0QuvCKacyaAjCvOJt.jpeg\",\"available-cars\\/November2020\\/B14Z0xgYU8lYPLe1mbsH.jpeg\",\"available-cars\\/November2020\\/1WE52rl3voSP7bvAfNgA.jpeg\",\"available-cars\\/November2020\\/wx6P1XJfjaKfYuDyHhYQ.jpeg\",\"available-cars\\/November2020\\/C8poMvjRN7JkCxFopSQd.jpeg\",\"available-cars\\/November2020\\/y3HhS1Bls0jvP867OAmq.jpeg\"]', 'Японія', NULL, 3, 1, '2020-11-09 12:42:17', '2020-11-25 08:43:43', NULL),
(26, 7, 26, 14, 7, 23, 2020, 1291180, 'available-cars/November2020/exBmYSnJbTwWBhnA7Fjs.jpg', '[\"available-cars\\/November2020\\/08Zom8GSlNGmCKp1VYy3.jpeg\",\"available-cars\\/November2020\\/TJ083Ivzs7Z41b8oWMaj.jpeg\",\"available-cars\\/November2020\\/Ya5AwY9CCEe3FuvLraqv.jpeg\",\"available-cars\\/November2020\\/Qt0OLDnZkeg7CvTf3fOa.jpeg\",\"available-cars\\/November2020\\/Dbj2Iiqkd57SkTInPA0k.jpeg\",\"available-cars\\/November2020\\/pcB5qSdC2THeakyxOYju.jpeg\",\"available-cars\\/November2020\\/qTGBYE2fKMAfTCSO2RzY.jpeg\",\"available-cars\\/November2020\\/IEmpYDrNRsjOmOz60laN.jpeg\",\"available-cars\\/November2020\\/DiK16sQx90rZPqYbcwdk.jpeg\",\"available-cars\\/November2020\\/vaGWr11SAnEfcfYEquDR.jpeg\",\"available-cars\\/November2020\\/gN4WC8Wvi1ActIjlF2pi.jpeg\",\"available-cars\\/November2020\\/7C1X10zKXsB4ukGZw1ec.jpeg\",\"available-cars\\/November2020\\/woBf0cUShG8LRMOdVaMZ.jpeg\",\"available-cars\\/November2020\\/QzKlf0sWlhwq66FAJyR9.jpeg\",\"available-cars\\/November2020\\/OdxH0MwAuoOf7q1p6Gjb.jpeg\",\"available-cars\\/November2020\\/pNuHI8DsWpySR4OMCb29.jpeg\",\"available-cars\\/November2020\\/7HTY9e16nyml6DccK6rP.jpeg\",\"available-cars\\/November2020\\/JberCSH1tvzVySOMjNBV.jpeg\",\"available-cars\\/November2020\\/YyNdrFfjdEpFldBZB0AA.jpeg\",\"available-cars\\/November2020\\/0REyABbU5qEAY6URID7Y.jpeg\",\"available-cars\\/November2020\\/HyTEKwK8S2tjQ4VVcFih.jpeg\",\"available-cars\\/November2020\\/KutVl6H6fup3s0GS48Om.jpeg\",\"available-cars\\/November2020\\/KC2j9M8LUhDFvP9EdkMd.jpeg\",\"available-cars\\/November2020\\/lWUoeT6ma2BwqNCwXLpn.jpeg\",\"available-cars\\/November2020\\/pEIQixnLoKZwnMZgsdg9.jpeg\",\"available-cars\\/November2020\\/uP8i3LKhLbgrRMetuA06.jpeg\",\"available-cars\\/November2020\\/QrSDNXj4QAoVFigpwxny.jpeg\",\"available-cars\\/November2020\\/DUe4cTw4NZP4k8B22gCo.jpeg\",\"available-cars\\/November2020\\/QvBkY6wpHge2y70vh1wb.jpeg\",\"available-cars\\/November2020\\/8Gif9Qg6KcV3ShuhH6ea.jpeg\",\"available-cars\\/November2020\\/n0xUWE1bHe55yspTUjQG.jpeg\",\"available-cars\\/November2020\\/ZCidkxq82b1xPnmERknQ.jpeg\",\"available-cars\\/November2020\\/8sFqfebzW7o4fX1DDjCx.jpg\",\"available-cars\\/November2020\\/u8w2cTl0SWls4bWXpyof.jpg\"]', 'Японія', NULL, 3, 5, '2020-11-17 06:55:18', '2020-11-25 08:43:35', NULL),
(27, 5, 19, 11, 9, 25, 2020, 860336, 'available-cars/November2020/xkHrydUfYhnJ474AKgAe.jpeg', '[\"available-cars\\/November2020\\/2b0IfoULmLmwaMYI1jSh.jpeg\",\"available-cars\\/November2020\\/YFJJqWh7AO3edeH3ydZN.jpeg\",\"available-cars\\/November2020\\/QPscyHilYTu1NEEgNiSg.jpeg\",\"available-cars\\/November2020\\/8ppeYEdSTMBfJm7ZfsOz.jpeg\",\"available-cars\\/November2020\\/OJqq1KQYfe4WVQ6NUC2r.jpeg\",\"available-cars\\/November2020\\/I7SogjtpnIL8cUTxSsHL.jpeg\",\"available-cars\\/November2020\\/FyMZgfGfYVMzK9sYXap5.jpeg\",\"available-cars\\/November2020\\/bMFZSZRS6UEKooQCGSWF.jpeg\",\"available-cars\\/November2020\\/sUrJgZsaDtDm6zfeNVxp.jpeg\",\"available-cars\\/November2020\\/vAtBk8cTuJPpyjLuY3Sd.jpeg\",\"available-cars\\/November2020\\/nzmsj73v7hl3FAy7vBq3.jpeg\",\"available-cars\\/November2020\\/w0jRKPZWU67LEfLLSigO.jpeg\",\"available-cars\\/November2020\\/2etC4y4wIBcsnvRQcD46.jpeg\",\"available-cars\\/November2020\\/boETDEavSzuGgZOmXJ6r.jpeg\",\"available-cars\\/November2020\\/klxAjxw0DRrgNGC5YY3v.JPG\",\"available-cars\\/November2020\\/8R7Yfz3BqHT5QfrKCFS5.jpg\",\"available-cars\\/November2020\\/esYqy5MdWLgJsGwxv13B.jpg\"]', 'Японія', NULL, 4, 1, '2020-11-20 11:41:07', '2020-11-25 08:40:16', NULL),
(28, 7, 29, 13, 7, 23, 2020, 1675790, 'available-cars/November2020/ZjOypfuv3T49b57nbyMb.jpg', '[\"available-cars\\/November2020\\/tjSSiIEmmjqIqQrWLdFT.jpg\",\"available-cars\\/November2020\\/dEIaiacChgX1eQG14hvZ.jpeg\",\"available-cars\\/November2020\\/3fOvCQlYwPuBgdOqg1GN.jpeg\",\"available-cars\\/November2020\\/ZgesOTqI3ctNTFMZHVN8.jpeg\",\"available-cars\\/November2020\\/kJj0vrLk0ylI04NH3wvG.jpeg\",\"available-cars\\/November2020\\/skVdcxqoJDBe7tyiKNc5.jpeg\",\"available-cars\\/November2020\\/FyCQCfh0LYO0M9ejD6bv.jpeg\",\"available-cars\\/November2020\\/B7kyeTlA5Vhc1UkC5iTt.jpeg\",\"available-cars\\/November2020\\/AqCdvfcjkW1QqRohz47n.jpeg\",\"available-cars\\/November2020\\/2ZQ6En5vTNl3732M9iJq.jpeg\",\"available-cars\\/November2020\\/c6hLcyzurUb7lUZuFhPc.jpeg\",\"available-cars\\/November2020\\/R92Nov1rlEOI2Oer5L9o.jpeg\",\"available-cars\\/November2020\\/RTqTyBenaocriaEI6HlH.jpeg\",\"available-cars\\/November2020\\/b26eWtr58YrOLZKreUxQ.jpeg\",\"available-cars\\/November2020\\/bWCdAvvwcy3KwDRjXIjf.jpeg\",\"available-cars\\/November2020\\/BGeXMS8NtUuEIPju3Cxo.jpeg\",\"available-cars\\/November2020\\/4Eb5Sotusdi9vP2tlyLd.jpeg\",\"available-cars\\/November2020\\/zzpm8rZEjFtCXIVyyQvM.jpeg\",\"available-cars\\/November2020\\/NUc5pYMsxMDvlgBOHUMX.jpeg\",\"available-cars\\/November2020\\/2GsX1yoGQLcKcpUCBbla.jpeg\",\"available-cars\\/November2020\\/jQP4mlACPrq4FHpKPPX5.jpeg\",\"available-cars\\/November2020\\/P5OXKAwk9ph0T12DbkAp.jpeg\",\"available-cars\\/November2020\\/zmtkn47MkJHTvP7kJJl9.jpeg\",\"available-cars\\/November2020\\/p7h2c11XXQql82AkxSAH.jpeg\",\"available-cars\\/November2020\\/YFpwvQ1TIDTELJUBXCuz.jpeg\",\"available-cars\\/November2020\\/ENiw811UyDWCxijY5rpi.jpeg\",\"available-cars\\/November2020\\/uVx50eN6nOE0qCdkeTho.jpeg\",\"available-cars\\/November2020\\/DSSIMLaLSgtBaL8LiQWa.jpeg\",\"available-cars\\/November2020\\/Z1Vgoze8agBu9VVgAiwo.jpeg\",\"available-cars\\/November2020\\/l8KWHBb4SgL9ebuqneem.jpeg\",\"available-cars\\/November2020\\/DP2UCoKJGazZbfXVw0YV.jpeg\",\"available-cars\\/November2020\\/ZsCmSRNidBBC3qBiISnA.jpeg\",\"available-cars\\/November2020\\/9LNtLP01SExBSXy1zt9O.jpeg\",\"available-cars\\/November2020\\/lDfMOzIc9jUAsy3aYhIu.jpeg\",\"available-cars\\/November2020\\/xs5U6YdsJX15Zn0j6hSC.jpeg\",\"available-cars\\/November2020\\/KEqvuIBCftIOczvk1hmp.jpeg\",\"available-cars\\/November2020\\/6HJ5hNLgltYn6zeSGjt6.jpeg\",\"available-cars\\/November2020\\/MsWvC0LacjJVfcaVyoxN.jpeg\",\"available-cars\\/November2020\\/4XKPibz29A22PluAwu6B.jpeg\",\"available-cars\\/November2020\\/QZabOiUBQLnkCE4vb27W.jpeg\",\"available-cars\\/November2020\\/XVGTwjY03PkUtzYlztjv.jpeg\"]', 'Японія', NULL, 3, 5, '2020-11-25 08:33:24', '2020-11-25 08:38:43', NULL),
(29, 5, 21, 7, 6, 37, 2020, 1157770, 'available-cars/December2020/TKxcGIcRHo2ptbYgugCW.jpeg', '[\"available-cars\\/December2020\\/dU3cwXJXOgepymd2JbYa.jpeg\",\"available-cars\\/December2020\\/YYcPUex6ty8ThkCaBHmu.jpeg\",\"available-cars\\/December2020\\/2UaoacmQtySjAnaajfwW.jpeg\",\"available-cars\\/December2020\\/z4TvPa1wCbfFPShOlFFK.jpeg\",\"available-cars\\/December2020\\/G35mKO7oooKivz0o0h6m.jpeg\",\"available-cars\\/December2020\\/XlM87BDhFK9BtQ1hKkZt.jpeg\",\"available-cars\\/December2020\\/jGkpXIl81A28Vo3hCXk8.jpeg\",\"available-cars\\/December2020\\/8sjBuxt5MQcSqsuJuXXq.jpeg\",\"available-cars\\/December2020\\/zsKfBsjR6hMtfPfD5zYy.jpeg\",\"available-cars\\/December2020\\/nyavFlwjuer9mtQWAurz.jpeg\",\"available-cars\\/December2020\\/MvIOECirAWHqhEGJRfyv.jpeg\",\"available-cars\\/December2020\\/gaTjE6T0q5Qd6fwPs60u.jpeg\",\"available-cars\\/December2020\\/3ChB4fOPmg05sOkKXDdU.jpeg\",\"available-cars\\/December2020\\/40yVWzSeOUyMebEKvnNG.jpeg\",\"available-cars\\/December2020\\/EgcRQiDvgXRimj6n2sXj.jpeg\",\"available-cars\\/December2020\\/Wot2rkB3WbKNBZtLAs2N.jpeg\",\"available-cars\\/December2020\\/Tzk9YkmDq3ph45fPPVCb.jpeg\",\"available-cars\\/December2020\\/uRL9aOoXifHKHXK0Sm7Q.jpeg\",\"available-cars\\/December2020\\/j7bb3583pBk13QtpRW5J.jpeg\",\"available-cars\\/December2020\\/1RzR98OwYrBSRfwdpev3.jpeg\",\"available-cars\\/December2020\\/nIxwikzAA6WxCH80WuO7.jpeg\"]', 'Японія', NULL, 3, 1, '2020-12-02 06:48:03', '2020-12-02 06:48:03', NULL),
(30, 1, 3, 23, 6, 10, 2020, 639608, 'available-cars/December2020/Abfq2EMWeyNxNRaJtR7N.jpeg', '[\"available-cars\\/December2020\\/giFr2BTAlX7rLhgYgKwD.jpeg\",\"available-cars\\/December2020\\/bJy6XLdxWZ8rG8l9vC8R.jpeg\",\"available-cars\\/December2020\\/7TYp9sYmb5qIDnwMOV0u.jpeg\",\"available-cars\\/December2020\\/q5NeWx85O89nOAqv3new.jpeg\",\"available-cars\\/December2020\\/WmJlQyI7xT9JqEuCISjW.jpeg\",\"available-cars\\/December2020\\/7YDzPTxd6WNuCTK22LHN.jpeg\",\"available-cars\\/December2020\\/ZOZ4gbTjpcMJZJRVTOUK.jpeg\",\"available-cars\\/December2020\\/1ainiEyOoNOtVh9O1QPc.jpeg\",\"available-cars\\/December2020\\/MedGkFOHcQgUwZDguDKz.jpeg\",\"available-cars\\/December2020\\/TDRBi5KOtWqUr1oeqbi5.jpeg\",\"available-cars\\/December2020\\/XrvvryQXniVHjnAyMYGP.jpeg\",\"available-cars\\/December2020\\/EWFCozZVtubNXKwB14IK.jpeg\",\"available-cars\\/December2020\\/VWjot7nmgYUyDIGn4eSW.jpeg\",\"available-cars\\/December2020\\/OActiDhjj9VdzPP8XKx2.jpeg\",\"available-cars\\/December2020\\/YxaS2uQZdNyImEpzLdbR.jpeg\",\"available-cars\\/December2020\\/EuTq2sy3bRNLbndtMkqs.jpeg\",\"available-cars\\/December2020\\/WIUyLlxNcUP63RQU9dI6.jpeg\",\"available-cars\\/December2020\\/cXxCWNVr0eulINIjGuJg.jpeg\",\"available-cars\\/December2020\\/VAmYV1rZRXLN1QulaoIu.jpeg\",\"available-cars\\/December2020\\/pzVel1j9A1CJkyKKUT4X.jpeg\",\"available-cars\\/December2020\\/62chOxL8O6fA3qynZz25.jpeg\",\"available-cars\\/December2020\\/mVXWPvpu8DQRrBL1Zpi2.jpeg\",\"available-cars\\/December2020\\/kd3FcvVq9PRbyqnOOOKn.jpeg\",\"available-cars\\/December2020\\/JsQYGWdbKAvUwO44DRFc.jpeg\",\"available-cars\\/December2020\\/zJFWNEFYcz3jPkmdgU0J.jpeg\",\"available-cars\\/December2020\\/7jnYrP7KE4KyPBrkq8Zy.jpeg\",\"available-cars\\/December2020\\/TCMerdCQfOvq4IyV64lP.jpeg\",\"available-cars\\/December2020\\/lnb71miZrIPkLcQKBO0X.jpeg\",\"available-cars\\/December2020\\/k18xciCvh2RuCYG3IrPL.jpeg\",\"available-cars\\/December2020\\/u2ihljnj966vJoG42l0I.jpeg\",\"available-cars\\/December2020\\/lUVUtRLsExVMgrV3vl43.jpeg\",\"available-cars\\/December2020\\/b3QB80dyGESZCK8AiPtx.jpeg\",\"available-cars\\/December2020\\/5JYtZsDVodn3s9lRkNoO.jpeg\"]', 'Франція', NULL, 4, 2, '2020-12-08 08:46:43', '2020-12-08 08:46:43', NULL),
(31, 8, 30, 17, 7, 23, 2020, 1864370, 'available-cars/December2020/4wC5Vlkz4lQv7bSmTuVs.jpeg', '[\"available-cars\\/December2020\\/gAn1Zbp99Per2nykMsnd.jpeg\",\"available-cars\\/December2020\\/Nxs78HITpCYK3Cvfmig3.jpeg\",\"available-cars\\/December2020\\/pm2b0fjZ49ue0eOYzNLc.jpeg\",\"available-cars\\/December2020\\/OFjI6SqYCGZwfQ5hPx27.jpeg\",\"available-cars\\/December2020\\/E6wChpnC4gir49HdXYc1.jpeg\",\"available-cars\\/December2020\\/5FCjm0PHCzaSfyICNqAj.jpeg\",\"available-cars\\/December2020\\/JuaYKgGMGey184SjMW0D.jpeg\",\"available-cars\\/December2020\\/oUEgvtSfze0jAzUoaPpc.jpeg\",\"available-cars\\/December2020\\/wFFF7OcGuEgk2xjRNmT0.jpeg\",\"available-cars\\/December2020\\/19TuUCo6gIPuAavjHdqw.jpeg\",\"available-cars\\/December2020\\/UiF2rXdlAxIkDy9FvfqL.jpeg\",\"available-cars\\/December2020\\/HddUNCa8ARQBriR95mh5.jpeg\",\"available-cars\\/December2020\\/NQ5qqosUMAGtxL2q00ql.jpeg\",\"available-cars\\/December2020\\/7C9GWNKjOY86HsdTc1CU.jpeg\",\"available-cars\\/December2020\\/iegD0lYgrAGBBuZJH48M.jpeg\",\"available-cars\\/December2020\\/GY5AFoup7CeP7La9IAuz.jpeg\",\"available-cars\\/December2020\\/IcKAINrjjOsPpZcoWHhL.jpeg\",\"available-cars\\/December2020\\/wzC6NWG8KrSor7sJWrOu.jpeg\",\"available-cars\\/December2020\\/BrPPVtfqfW6k1IJTV33z.jpeg\",\"available-cars\\/December2020\\/kXMIwzatnQ0y5lGd8IvX.jpeg\",\"available-cars\\/December2020\\/ocaQkiEpRdw24rqEROAY.jpeg\",\"available-cars\\/December2020\\/BmzqEdunaeMb9YnAppV4.jpeg\",\"available-cars\\/December2020\\/5jDsKA9c4UlyA8pKal6Z.jpeg\",\"available-cars\\/December2020\\/8cDP81UIS92ooha1vOpP.jpeg\",\"available-cars\\/December2020\\/OC8z8Khj3Spqfkw9dDtH.jpeg\",\"available-cars\\/December2020\\/qXV6tAkJK5GbzXqLdJIJ.jpeg\"]', 'Японія', NULL, 3, 5, '2020-12-11 08:07:56', '2020-12-11 08:09:25', NULL),
(32, 8, 37, 17, 7, 12, 2020, 2463750, 'available-cars/December2020/kFhyJNc8GioN5Dg6xj1c.jpg', '[\"available-cars\\/December2020\\/OLvCESeeynYJSRpMNEWY.jpeg\",\"available-cars\\/December2020\\/yyrL55VsJJljbd67rvLL.jpeg\",\"available-cars\\/December2020\\/QJZomrvrFs4nVHsqUH4b.jpeg\",\"available-cars\\/December2020\\/K37dEwboJM7XqqQCxUTV.jpeg\",\"available-cars\\/December2020\\/at3iBdnHTDnIE3REgSja.jpeg\",\"available-cars\\/December2020\\/A9qukw0BXcRj0rdR1Pli.jpeg\",\"available-cars\\/December2020\\/2lalOAloY4e66EM4AVzT.jpeg\",\"available-cars\\/December2020\\/vCb54tw29o8wyxp1ofCi.jpeg\",\"available-cars\\/December2020\\/v4upwnuWUdbKeXkLEi8s.jpeg\",\"available-cars\\/December2020\\/i3k7w4WKeDQUAlhKSvwI.jpeg\",\"available-cars\\/December2020\\/5RB0QpHgwFTn7moD3WbK.jpeg\",\"available-cars\\/December2020\\/xffwOY56pE5joCcZVVNZ.jpeg\",\"available-cars\\/December2020\\/nlTeYii0I0DCICuS8KnK.jpeg\",\"available-cars\\/December2020\\/FsUpj6B5NrEfIoyoksCg.jpeg\",\"available-cars\\/December2020\\/aPg8BWDmIneWxjJS6Prq.jpeg\",\"available-cars\\/December2020\\/1DxIT8OTuXmTxaGtVf6D.jpeg\",\"available-cars\\/December2020\\/c5lHDXBn3mDCyHb6Gzcw.jpeg\",\"available-cars\\/December2020\\/ZXuyeMqBecFqnzj3LiBO.jpeg\",\"available-cars\\/December2020\\/PkF9hqhQMpdf3UeJdyOV.jpeg\",\"available-cars\\/December2020\\/is7XEo9OOJYRDzdaa7vU.jpeg\",\"available-cars\\/December2020\\/CsYKcLjKhzh0jFJqNaCq.jpeg\",\"available-cars\\/December2020\\/4afVDSWpVjUm2i0t1Rmy.jpeg\",\"available-cars\\/December2020\\/43T8hcK187Aknd0m1FtI.jpeg\",\"available-cars\\/December2020\\/6ArWlAAyMQ0voh0mgJnr.jpeg\",\"available-cars\\/December2020\\/seauMyuyI5mrHVWJF0oQ.jpeg\",\"available-cars\\/December2020\\/hlQguwUuTMxUzXAy0RBQ.jpeg\",\"available-cars\\/December2020\\/MTEyYUF4WUSQZer6mq4s.jpeg\",\"available-cars\\/December2020\\/AWftdZdjjRzqigBk3leI.jpeg\"]', 'Японія', NULL, 3, 5, '2020-12-11 11:14:11', '2020-12-11 11:18:50', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `body_types`
--

CREATE TABLE IF NOT EXISTS `body_types` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `body_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `body_types`
--

INSERT INTO `body_types` (`id`, `body_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Кросовер', '2020-04-29 19:37:27', '2020-04-29 19:54:02', NULL),
(2, 'Хетчбек', '2020-04-29 19:37:55', '2020-04-29 19:53:18', NULL),
(3, 'Седан', '2020-04-29 19:38:32', '2020-04-29 19:53:06', NULL),
(4, 'Пікап', '2020-05-25 09:38:13', '2020-09-15 05:16:42', NULL),
(5, 'Позашляховик', '2020-08-11 07:41:25', '2020-09-15 05:16:31', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `booklets`
--

CREATE TABLE IF NOT EXISTS `booklets` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT NULL,
  `booklet` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accessory` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `booklets`
--

INSERT INTO `booklets` (`id`, `model_id`, `booklet`, `accessory`, `preview`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 8, '[{\"download_link\":\"booklets\\/September2020\\/l5JXij14B3Ya2q5YGDVv.pdf\",\"original_name\":\"Toyota_LC200_LE.pdf\"}]', '[]', 'booklets/May2020/MdwqrbXjkn43k4wKK614.png', NULL, '2020-10-15 07:12:52', NULL),
(2, 5, '[{\"download_link\":\"booklets\\/October2020\\/1eEmR9EvOl2fuuVGfHED.pdf\",\"original_name\":\"Toyota-Rav4-Veresen-2020_tcm-3046-1311084.pdf\"}]', '[]', 'booklets/May2020/nyXkTAKyTir2uFTP7suv.png', NULL, '2020-10-15 07:13:25', NULL),
(3, 2, '[{\"download_link\":\"booklets\\/May2020\\/g0At6H8IngB91uquXQBc.pdf\",\"original_name\":\"toyota-c-hr-2019_tcm-3046-850637.pdf\"}]', '[]', 'booklets/May2020/ht1IwFSx1z1QPIBsfibQ.png', '2020-05-25 06:50:46', '2020-05-25 09:21:35', NULL),
(4, 3, '[{\"download_link\":\"booklets\\/May2020\\/5AQ4UYE718XHb4EwfI8d.pdf\",\"original_name\":\"corolla-2020_tcm-3046-754547.pdf\"}]', '[]', 'booklets/August2020/MIci306iZ03Qxz7vv56A.png', '2020-05-25 06:58:17', '2020-08-25 05:04:18', NULL),
(5, 4, '[{\"download_link\":\"booklets\\/October2020\\/E3Ed1xWxNEtTU3tXJaDJ.pdf\",\"original_name\":\"Camry-brochure_tcm-3046-746748.pdf\"}]', '[]', 'booklets/August2020/qKhxVmQHApWcOxcmVqiB.png', '2020-05-25 06:59:04', '2020-10-15 07:11:18', NULL),
(6, NULL, '[{\"download_link\":\"booklets\\/May2020\\/qbjyb8gVdSHTc6WKepcc.pdf\",\"original_name\":\"camry-hybrid-2020_tcm-3046-780854 (1).pdf\"}]', '[]', 'booklets/August2020/oVunN2Y4z9T3JcTfzJK0.png', '2020-05-25 06:59:43', '2020-08-25 05:05:49', NULL),
(7, 6, '[{\"download_link\":\"booklets\\/May2020\\/C03WgUr9szA1qobIYxtm.pdf\",\"original_name\":\"Highlander_2020_tcm-3046-255121.pdf\"}]', '[]', 'booklets/August2020/6aLavoM3gvOkqyyMFN5u.png', '2020-05-25 07:00:37', '2020-08-25 05:11:03', NULL),
(8, 9, '[{\"download_link\":\"booklets\\/October2020\\/XLRxJpPb9MUK1l0GTHXq.pdf\",\"original_name\":\"toyota-hilux_tcm-3046-480018 (1).pdf\"}]', '[]', 'booklets/August2020/luecQoZ6Uf9ihG7JWvsb.png', '2020-05-25 07:01:49', '2020-10-15 07:09:58', NULL),
(9, 7, '[{\"download_link\":\"booklets\\/October2020\\/6Fi6Zbxa3oEWlTQpH4uy.pdf\",\"original_name\":\"Toyota_Prado-bezin-october_tcm-3046-712853.pdf\"}]', '[]', 'booklets/August2020/s90NvShRtfWeYZ15eesb.png', '2020-05-25 07:03:31', '2020-10-15 07:09:40', NULL),
(10, 7, '[{\"download_link\":\"booklets\\/October2020\\/cs2S0oo32mFSwPpvX3en.pdf\",\"original_name\":\"Toyota_Prado-diesel-october_tcm-3046-244651.pdf\"}]', '[]', 'booklets/August2020/lwSZ3pLmaZKUc5yZB6lh.png', '2020-05-25 07:03:58', '2020-10-15 07:09:20', NULL),
(11, 1, '[{\"download_link\":\"booklets\\/November2020\\/gvRbClbjHou5DUl4IiNZ.pdf\",\"original_name\":\"noviy-toyota-yaris_tcm-3046-218678.pdf\"}]', '[]', 'booklets/November2020/dXelc0rmgZQfKnyu456p.png', '2020-11-23 11:20:19', '2020-11-23 11:20:19', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `colors`
--

CREATE TABLE IF NOT EXISTS `colors` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rgb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metallic` tinyint(4) DEFAULT 0,
  `pearl` tinyint(4) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `color_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `colors_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `colors`
--

INSERT INTO `colors` (`id`, `name`, `code`, `image`, `rgb`, `metallic`, `pearl`, `created_at`, `updated_at`, `deleted_at`, `color_type`) VALUES
(3, 'Білий (040)', '040', 'colors/May2020/CucmWsl8mciN5dl62EMa.JPG', '#fafafa', 0, 0, '2020-05-07 09:23:53', '2020-06-19 10:12:30', NULL, '1'),
(4, 'Сірий металік (1G3)', '1G3', 'colors/May2020/x796cIubqhngAALZe6yY.JPG', '#7c7a7a', 1, 0, '2020-05-07 09:29:12', '2020-06-19 10:14:45', NULL, '3'),
(5, 'Яскраво-синій металік (8X2)', '8X2', 'colors/May2020/lXxb8b61FoEWGFqWEXcz.JPG', '#1d50aa', 1, 0, '2020-05-07 09:45:57', '2020-06-19 10:15:18', NULL, '3'),
(6, 'Чорний металік (209)', '209', 'colors/May2020/yi0xNPvpYdMUO964DLKq.JPG', '#030303', 1, 0, '2020-05-07 09:47:55', '2020-06-19 10:14:58', NULL, '3'),
(7, 'Сірий металік (1G2)', '1G2', 'colors/May2020/ddCaowGjyCIxmgM1JoUb.JPG', '#7a766f', 1, 0, '2020-05-07 09:51:10', '2020-06-19 10:14:31', NULL, '3'),
(8, 'Сріблястий металік (1F7)', '1F7', 'colors/May2020/OKEHaAP0yaZrdj5r3yzl.JPG', '#f2f2f0', 1, 0, '2020-05-07 09:53:42', '2020-06-19 10:14:01', NULL, '3'),
(9, 'Білий металік (084)', '084', 'colors/May2020/WBHlnwU12YjDxZX8a7D6.JPG', '#d7dcd9', 1, 0, '2020-05-07 09:56:10', '2020-06-19 10:17:07', NULL, '4'),
(10, 'Червоний перламутр (3T3)', '3T3', 'colors/May2020/03xEKJtyCz1BAW2OV6Ci.JPG', '#60101e', 0, 1, '2020-05-07 10:00:43', '2020-06-19 10:17:32', NULL, '4'),
(11, 'Сірий металік (1H5)', '1H5', 'colors/May2020/pihA8iSZUykmhCEK8yHp.JPG', '#7d8489', 1, 0, '2020-05-07 10:02:57', '2020-05-07 10:02:57', NULL, '0'),
(12, 'Білий перламутр (070)', '070', 'colors/May2020/fZEmBogXPahKZCGpSZuk.JPG', '#e1e2dd', 0, 1, '2020-05-07 10:15:33', '2020-07-28 08:54:31', NULL, '4'),
(13, 'Сірий металік (1K0)', '1K0', 'colors/May2020/uzZkui9YncmeyTk09SLp.JPG', '#aeabac', 1, 0, '2020-05-07 10:26:33', '2020-06-19 10:15:38', NULL, '3'),
(14, 'Сіро-блакитний металік (1K3)', '1K3', 'colors/May2020/uKIbZMJYGwdRcbx3MDvF.JPG', '#97a4ac', 1, 0, '2020-05-07 10:31:15', '2020-06-19 10:29:48', NULL, '3'),
(15, 'Бронзовий металік (6X1)', '6X1', 'colors/May2020/7P6gCYpDrqiixiBs8zp5.JPG', '#817e6e', 1, 0, '2020-05-07 10:35:03', '2020-06-19 10:16:15', NULL, '3'),
(16, 'Червоний перламутр (3U5)', '3U5', 'colors/May2020/UpkZRD6SZRj7I7y6pc3E.JPG', '#8c0414', 0, 1, '2020-05-07 10:38:23', '2020-06-19 10:18:06', NULL, '4'),
(17, 'Бежевий металік (587)', '587', 'colors/May2020/T2KhY21DZ4cWaNBje4Cj.JPG', '#b4ae9c', 1, 0, '2020-05-07 10:41:39', '2020-06-19 10:15:55', NULL, '3'),
(18, 'Червоний (3P0)', '3P0', 'colors/May2020/xCnitlMlmHC8iGvVBDIh.JPG', '#c9021a', 0, 0, '2020-05-22 03:26:31', '2020-06-19 10:12:56', NULL, '2'),
(19, 'Білий (089)', '089', 'colors/May2020/ixKfXvCPwjzkxqSSXq42.jpg', '#eeeded', 0, 1, '2020-05-22 11:37:31', '2020-06-19 10:28:02', NULL, '4'),
(20, 'Бежевий металік (4X1)', '4X1', 'colors/May2020/Svnc0t6Qxgo9SNq7sfsP.jpg', '#b4ae9c', 1, 0, '2020-05-22 11:37:59', '2020-06-19 10:23:28', NULL, '3'),
(21, 'Коричневий металік (4X7)', '4X7', 'colors/May2020/MmnRrZnkAIdi724tvMn4.jpg', '#604d4d', 1, 0, '2020-05-22 11:38:24', '2020-06-19 10:27:11', NULL, '3'),
(22, 'Темно-синій металік (8W7)', '8W7', 'colors/May2020/vTRuw4fsqClCZ4806G3e.jpg', '#2b3e69', 1, 0, '2020-05-22 11:38:53', '2020-06-19 10:30:50', NULL, '3'),
(23, 'Чорний металік (218)', '218', 'colors/May2020/BLHCYhAZL71perVdVBjb.jpg', '#151618', 1, 0, '2020-05-22 11:39:17', '2020-07-28 08:59:38', NULL, '3'),
(24, 'Хакі (6X3)', '6X3', 'colors/May2020/MvdDsPJ5L7woijsgfjWh.jpg', '#727874', 0, 0, '2020-05-22 15:05:39', '2020-07-28 08:59:05', NULL, '1'),
(25, 'Темно-синій металік (8X8)', '8X8', 'colors/May2020/f4xsY3Mw9B0SaH3ATOAA.jpg', '#191b27', 0, 0, '2020-05-22 15:06:16', '2020-07-28 08:58:32', NULL, '1'),
(26, 'Сріблястий металік (1D6)', '1D6', 'colors/May2020/O5UfBQLEuKCVwO5yeAUV.jpg', '#98999b', 0, 0, '2020-05-22 15:06:43', '2020-07-28 08:58:05', NULL, '1'),
(27, 'Блакитний металік (8W9)', '8W9', 'colors/May2020/3Lv8L0ZMmYNf3EdXz3IZ.jpg', '#137dad', 0, 0, '2020-05-22 15:07:12', '2020-07-28 08:57:34', NULL, '3'),
(28, 'Синій кузов / чорний дах (2NH)', '2NH', 'colors/July2020/1tKHfJaHwxvhfp1MMXZh.jpg', '#1a499c', 0, 0, '2020-07-28 08:13:03', '2020-11-06 09:52:36', NULL, '3'),
(29, 'Сірий кузов / чорний дах (2NB)', '2NB', 'colors/July2020/qTnSVfL7fNZ1cdd6TjDS.jpg', '#4c4d51', 0, 0, '2020-07-28 08:20:31', '2020-11-06 09:52:26', NULL, '3'),
(30, 'Сірий кузов / чорний дах (2NK)', '2NK', 'colors/July2020/mun5TkEXBKX3xHcseBpT.jpg', '#999798', 0, 0, '2020-07-28 08:22:49', '2020-11-06 09:51:42', NULL, '3'),
(31, 'Чорний кузов / сірий дах (2TA)', '2TA', 'colors/July2020/KqKUruzGUoVB1eqst1aA.jpg', '#27282a', 0, 0, '2020-07-28 08:26:36', '2020-11-06 09:51:23', NULL, '3'),
(32, 'Сіро-блакитний кузов / чорний дах (2TH)', '2TH', 'colors/July2020/0Yg537VBCowRbhtWWjs1.jpg', '#63717c', 0, 0, '2020-07-28 08:29:24', '2020-11-06 09:51:02', NULL, '3'),
(33, 'Білий кузов / чорний дах (2NA)', '2NA', 'colors/July2020/YqbVSWgaBl9aOqDsT2Qr.jpg', '#d5dad6', 0, 0, '2020-07-28 08:35:51', '2020-11-06 09:50:44', NULL, '4'),
(34, 'Помаранчевий кузов / чорний дах (2TC)', '2TC', 'colors/July2020/sqNjOANeyMxS5LbhYXFM.jpg', '#a13511', 0, 0, '2020-07-28 08:50:51', '2020-11-06 09:50:28', NULL, '3'),
(35, 'Темно-синій металік з чорним дахом (2RA)', '2RA', 'colors/July2020/qgMxPsCziQ6B2rOy28QO.jpg', '#191d28', 0, 0, '2020-07-28 10:13:52', '2020-07-28 10:13:52', NULL, '3'),
(36, 'Сірий металік з чорним дахом (2QZ)', '2QZ', 'colors/July2020/mzX76WaVOogtbmFvZoM4.jpg', '#4e4f53', 0, 0, '2020-07-28 10:15:18', '2020-07-28 10:15:18', NULL, '3'),
(37, 'Сріблястий металік з чорним дахом (2QY)', '2QY', 'colors/July2020/Hm1gTdKy4mgXzFDNVuSD.jpg', '#a2a3a7', 0, 0, '2020-07-28 10:16:33', '2020-07-28 10:16:33', NULL, '3'),
(38, 'Білий перламутр з чорним дахом (2QJ)', '2QJ', 'colors/July2020/uv5lASMXtJviiwGYpPbt.jpg', '#dce1dd', 0, 0, '2020-07-28 10:20:54', '2020-07-28 10:20:54', NULL, '4'),
(39, 'Сіро-блакитний перламутр (1K5)', '1K5', 'colors/July2020/GUULFdSWRIWaSLqkRQLj.jpg', '#a0b3bd', 0, 0, '2020-07-28 15:09:03', '2020-07-28 15:09:03', NULL, '4'),
(40, 'Сріблястий металік (1J9)', '1J9', 'colors/July2020/AS6FmOGynitxcYokP25I.jpg', '#9a9fa3', 0, 0, '2020-07-28 15:11:17', '2020-07-28 15:11:17', NULL, '3'),
(41, 'Коричневий металік (4X9)', '4X9', 'colors/July2020/tW7sLLoP2Ka4j08q8DPP.jpg', '#403e3f', 0, 0, '2020-07-28 15:13:08', '2020-07-28 15:13:08', NULL, '3'),
(42, 'Чорний (202)', '202', 'colors/July2020/BTNdG4R5ihL7NlOkrqL3.jpg', '#0c0e0f', 0, 0, '2020-07-28 15:16:17', '2020-07-28 15:16:17', NULL, '1'),
(43, 'Червоний \"металік\" (3R3)', '3R3', 'colors/July2020/4o3wHgjEhmYGnOyXa1H5.jpg', '#931722', 0, 0, '2020-07-28 15:18:58', '2020-07-28 15:18:58', NULL, '3'),
(44, 'Бронзовий \"металік\" (4V8)', '4V8', 'colors/July2020/1XYKuhZAbKrwlb0EV97j.jpg', '#8d8682', 0, 0, '2020-07-28 15:21:06', '2020-07-28 15:21:06', NULL, '3'),
(45, 'Коричневий \"перламутр\" (4X4)', '4X4', 'colors/July2020/y9Mr3J1DRm8wPFImS8Ey.jpg', '#271913', 0, 0, '2020-07-28 15:23:31', '2020-07-28 15:23:31', NULL, '4'),
(46, 'Темно-синій \"металік\" (221)', '221', 'colors/July2020/9zG5WugeqGHNKZ7EFZ6g.jpg', '#030f16', 0, 0, '2020-07-28 15:25:28', '2020-07-28 15:25:28', NULL, '3'),
(47, 'Темно-червоний металік (3Q3)', '3Q3', 'colors/July2020/3EM1ubXZ4eEyIMebgxJc.jpg', '#6c1a20', 0, 0, '2020-07-28 15:34:55', '2020-07-28 15:34:55', NULL, '3'),
(48, 'Бежевий металік (4R3)', '4R3', 'colors/July2020/8LdE7x5fRoeGsenPnoC1.jpg', '#bea691', 0, 0, '2020-07-28 15:37:25', '2020-07-28 15:37:25', NULL, '3'),
(49, 'Червоно-коричневий металік (4S6)', '4S6', 'colors/July2020/vOryk0GykCEFQRpcCSHo.jpg', '#4c2925', 0, 0, '2020-07-28 15:39:12', '2020-07-28 15:39:12', NULL, '3'),
(50, 'Темно-синій металік (8P8)', '8P8', 'colors/July2020/t4Qu94rDv9eXMHFK0xaN.jpg', '#121d2f', 0, 0, '2020-07-28 15:40:49', '2020-07-28 15:40:49', NULL, '3'),
(51, 'Чорний перламутр (220)', '220', 'colors/July2020/iiPW21CzgYQoc50AeXd4.jpg', '#29282e', 0, 0, '2020-07-28 15:42:53', '2020-07-28 15:42:53', NULL, '4'),
(52, 'Помаранчевий металік (4R8)', '4R8', 'colors/November2020/pp1Baq0BapcFWZKZQTl3.jpg', '#c3371c', 1, 0, '2020-11-05 11:09:25', '2020-11-05 11:09:25', NULL, '3'),
(53, 'Бронзовий кузов / сірий дах (2TD)', '2TD', 'colors/November2020/fZtGV8DLi6WJ7plLho0i.jpg', '#767466', 0, 0, '2020-11-06 08:58:53', '2020-11-06 09:49:42', NULL, '3'),
(54, 'Бронзовий кузов / чорний дах (2TK)', '2TK', 'colors/November2020/Qd0O1xlbgIjYzyLEPSjN.jpg', '#757366', 0, 0, '2020-11-06 09:06:16', '2020-11-06 09:49:27', NULL, '3'),
(55, 'Білий кузов / бронзовий дах (2VC)', '2VC', 'colors/November2020/4tv6AmZCMf4SBfrCjNxm.jpg', '#e9efec', 0, 0, '2020-11-06 09:15:08', '2020-11-06 09:49:10', NULL, '4'),
(56, 'Cірий кузов / бронзовий дах (2VD)', '2VD', 'colors/November2020/8mbGI1S02nGaofqMsP9K.jpg', '#4c4c4d', 0, 0, '2020-11-06 09:21:02', '2020-11-06 09:48:57', NULL, '3'),
(57, 'Чорний кузов / бронзовий дах (2VE)', '2VE', 'colors/November2020/JHt3nWIMx0Ak1yCWYSoO.jpg', '#222222', 0, 0, '2020-11-06 09:25:47', '2020-11-06 09:48:22', NULL, '3'),
(58, 'Синій (8W2)', '8W2', 'colors/November2020/0MBxRqSGyLj90u3Jq6At.png', '#496386', 0, 0, '2020-11-11 17:31:52', '2020-11-11 17:44:40', NULL, '3'),
(59, 'Чорний кузов/чорний дах (2PN)', '2PN', 'colors/November2020/tDX6cDkLh50DPZ0yL6Lm.jpg', '#60101e', 0, 0, '2020-11-11 17:46:33', '2020-11-11 17:57:13', NULL, '1'),
(60, 'Білий кузов/чорний дах (2PU)', '2PU', 'colors/November2020/8ZLj9U7itxUF9ecphyqi.png', '#f6fcfe', 0, 0, '2020-11-11 18:01:38', '2020-11-11 18:01:38', NULL, '1'),
(61, 'Чорний кузов/білий дах (2ND)', '2ND', 'colors/November2020/970OX3PP2vgRO3zu4krV.jpg', '#030303', 0, 0, '2020-11-11 18:06:23', '2020-11-11 18:06:23', NULL, '1'),
(62, 'Синій кузов/білий дах (2ST)', '2ST', 'colors/November2020/6PK7qLD6AZkoR2xFWIfo.png', '#1c3277', 0, 0, '2020-11-11 18:09:50', '2020-11-11 18:09:50', NULL, '1'),
(63, 'Сірий кузов/білий дах (2SV)', '2SV', 'colors/November2020/tMohRv5t8DkunBpeY3QO.png', '#525252', 0, 0, '2020-11-11 18:12:09', '2020-11-11 18:12:09', NULL, '1'),
(64, 'Червоний кузов/чорний дах (2SW)', '2SW', 'colors/November2020/uJCAUZutXevu7PSqOppj.png', '#c21d26', 0, 0, '2020-11-11 18:16:57', '2020-11-11 18:16:57', NULL, '1');

-- --------------------------------------------------------

--
-- Структура таблицы `engines`
--

CREATE TABLE IF NOT EXISTS `engines` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fuel_type_id` int(11) DEFAULT NULL,
  `horspower` int(11) DEFAULT NULL,
  `volume` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `engines`
--

INSERT INTO `engines` (`id`, `name`, `image`, `description`, `fuel_type_id`, `horspower`, `volume`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, '1.6 Valvematic', 'engines/May2020/IMtkGwbCS0hV8oK86wbu.png', NULL, 1, 132, 1598, '2020-05-07 10:48:03', '2020-05-07 10:48:03', NULL),
(6, '2.5 Dual VVT-i', 'engines/May2020/yS0H3PNSWbUwFSIA2TjD.png', NULL, 1, 181, 2494, '2020-05-08 09:30:46', '2020-05-11 07:08:04', NULL),
(7, '2,5 л Hybrid Dual VVT-i', 'engines/May2020/MumvZHBRmMWwqFuApBl4.png', NULL, 1, 218, 2487, '2020-05-11 07:07:15', '2020-08-11 04:39:03', NULL),
(8, '1,2 D-4T', 'engines/May2020/6cZTUNqo300wtjvPxC5U.png', NULL, 1, 116, 1197, '2020-05-11 07:35:23', '2020-05-22 08:37:19', NULL),
(9, '1.8 HYBRID', 'engines/May2020/2zEOSpWVrUEWPYp25qtB.png', NULL, 1, 122, 1798, '2020-05-11 08:27:18', '2020-05-11 08:27:18', NULL),
(10, '2.0 HYBRID', 'engines/May2020/3WrecwGpoL97PCE3UaXV.png', NULL, 1, 184, 1987, '2020-05-11 08:31:25', '2020-05-11 08:31:25', NULL),
(11, '2.0 л Dual VVT-i', 'engines/May2020/xI7l2ZeeCx78uNQftDnJ.png', NULL, 1, 173, 1987, '2020-05-11 08:47:55', '2020-05-11 08:47:55', NULL),
(12, '3.5 V6 D-4S', 'engines/May2020/M0aQMUlmdz8HFN4G0wEI.png', NULL, 1, 249, 3456, '2020-05-11 10:28:13', '2020-05-11 10:28:13', NULL),
(13, '4.0L Dual VVT-i', 'engines/May2020/MxfYnbyT3bDrWGPEyLH7.png', NULL, 1, 282, 3956, '2020-05-11 10:35:03', '2020-05-11 10:35:03', NULL),
(14, '2.8L D-4D', 'engines/May2020/hQt3zGgnqVhs3txAOOXY.png', NULL, 2, 200, 2775, '2020-05-11 10:37:55', '2020-10-16 06:55:33', NULL),
(15, '4,6 л V8 Dual VVT-i', 'engines/May2020/e6dVcrcutF5s8VfBbzBF.png', NULL, 1, 309, 4608, '2020-05-11 10:42:41', '2020-05-11 10:42:41', NULL),
(16, '2,4 л D-4D', 'engines/May2020/DbTuKafXOyJVbCVAgU8R.png', NULL, 2, 150, 2393, '2020-05-11 10:45:28', '2020-05-11 10:45:28', NULL),
(17, '4.5 D-4D', NULL, NULL, 2, 249, 4.5, '2020-08-10 09:11:12', '2020-09-08 06:49:12', NULL),
(18, '2.7L VVT-i', 'engines/August2020/58P9DPZqfBnRMKrdimji.png', NULL, 1, 163, 2.7, '2020-08-11 04:46:07', '2020-08-11 04:46:07', NULL),
(19, '2,5 л Hybrid VVT-i, AWD', 'engines/August2020/KPFiwyouCiSx2isc3SVh.png', NULL, 3, 222, 2.5, '2020-08-11 04:49:12', '2020-08-11 04:49:39', NULL),
(21, '1.8 HYBRID (Smart Entry and Start +TSS)', NULL, NULL, 3, 122, 1798, '2020-08-26 06:53:50', '2020-08-26 06:54:04', NULL),
(22, '3,5 л D-4S', 'engines/October2020/7LicV2MvQH0GFgZCFRDa.png', NULL, 1, 302, 3.5, '2020-10-16 05:51:06', '2020-10-16 05:51:33', NULL),
(23, '1,5 л Hybrid', 'engines/November2020/HdSCGKFv52SbE0FEFE0x.png', '1,5 л Hybrid\r\nБезступенева з електронним керуванням (2WD)\r\nКомбінований цикл: 3,1 л/100 км\r\nВміст вуглекислого газу у відпрацьованих газах (комбінований цикл): 71 г/км', 1, 116, 1490, '2020-11-23 10:47:42', '2020-11-23 11:14:27', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `fuel_types`
--

CREATE TABLE IF NOT EXISTS `fuel_types` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fuel_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `fuel_types`
--

INSERT INTO `fuel_types` (`id`, `fuel_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Бензин', '2020-04-29 16:16:21', '2020-04-29 16:16:21', NULL),
(2, 'Дизель', '2020-04-29 16:16:31', '2020-04-29 16:16:31', NULL),
(3, 'ГIбрид', '2020-04-29 16:16:42', '2020-04-29 19:56:38', NULL),
(5, 'Електро', '2020-04-29 16:17:19', '2020-04-29 19:56:06', NULL),
(6, 'LPG', '2020-04-29 16:17:52', '2020-04-29 16:17:52', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `gearboxes`
--

CREATE TABLE IF NOT EXISTS `gearboxes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `gearboxes`
--

INSERT INTO `gearboxes` (`id`, `name`, `image`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, '5-ступ. механіка', 'gearboxes/May2020/rToxmaVSc0r1eWFmw1lk.jpg', 'Механічні коробки передач компанії «Тойота» відрізняються точним і водночас плавним перемиканням передач. Під час їзди можна з легкістю зменшити споживання пального, але якщо треба швидко прискоритися, то в запасі у вас буде достатня потужність. Наслідок: якнайкращі враження від контролю над автомобілем під час їзди.', '2020-05-07 10:58:40', '2020-05-22 08:47:14', NULL),
(4, 'Варіатор Multidrive S', 'gearboxes/May2020/tRSiYpfePRlHEmiDU4yQ.jpg', 'Варіатор ще називають безступеневою коробкою передач. У такій конструкції поєднано плавність перемикання передач, притаманну автоматичним КПП, та ощадливе споживання пального, яке характерне для механічних КПП. Завдяки узгодженій зміні діаметрів шківів у залежності від режимів роботи двигуна коробка Multidrive S забезпечує напрочуд ощадливе споживання пального. Крім того, вона має окремий «спортивний» режим. За бажанням, ви зможете перемикати 7 «віртуальних» передач за допомогою важеля КПП або перемикачів передач, розташованих за кермом.', '2020-05-07 11:02:39', '2020-05-22 08:46:26', NULL),
(5, '6 - ступ. механіка', 'gearboxes/May2020/193EYQ3VDavPDPj9N59D.jpg', 'Механічні коробки передач компанії «Тойота» відрізняються точним і водночас плавним перемиканням передач. Під час їзди можна з легкістю зменшити споживання пального, але якщо треба швидко прискоритися, то в запасі у вас буде достатня потужність. Наслідок: якнайкращі враження від контролю над автомобілем під час їзди.', '2020-05-07 11:06:21', '2020-05-07 11:06:21', NULL),
(6, 'Варіатор e-CVT з електронним керуванням', 'gearboxes/May2020/eyaVXPj3yrZQB5vpwT17.jpg', NULL, '2020-05-22 08:58:48', '2020-05-22 08:58:48', NULL),
(7, 'АКПП 6-ступ.автомат (AWD)', NULL, NULL, '2020-06-04 09:25:25', '2020-06-04 09:27:41', NULL),
(8, 'АКПП 6-ступ.автомат (2WD)', NULL, NULL, '2020-06-04 10:33:16', '2020-06-04 10:33:16', NULL),
(9, 'Варіатор Multidrive S (CVT) з фіксованою стартовою передачею (2WD)', NULL, NULL, '2020-06-04 10:35:33', '2020-06-04 10:35:33', NULL),
(10, 'Варіатор Multidrive S (CVT) з фіксованою стартовою передачею (AWD)', NULL, NULL, '2020-06-04 10:38:07', '2020-06-04 10:38:07', NULL),
(11, '8-ст. автоматична (AWD)', NULL, NULL, '2020-08-07 13:50:12', '2020-08-11 07:50:31', NULL),
(12, 'Direct Shift CVT', NULL, NULL, '2020-08-10 07:06:34', '2020-08-10 07:06:34', NULL),
(13, '8-ст. автоматична (2WD)', NULL, NULL, '2020-10-16 05:56:21', '2020-10-16 05:56:21', NULL),
(14, 'гібридна безступенева з електронним керуванням (e-CVT)', 'gearboxes/November2020/DN5XC13UY1ZJIDJDzgCg.png', '1,5 л Hybrid\r\nБезступенева з електронним керуванням\r\nКомбінований цикл: 3,1 л/100 км\r\nВміст вуглекислого газу у відпрацьованих газах (комбінований цикл): 71 г/км', '2020-11-23 10:53:03', '2020-11-23 10:53:03', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `model_names`
--

CREATE TABLE IF NOT EXISTS `model_names` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hybrid` tinyint(4) DEFAULT 0,
  `stock` tinyint(4) DEFAULT 0,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `available` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `model_names`
--

INSERT INTO `model_names` (`id`, `name`, `hybrid`, `stock`, `image`, `slug`, `available`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'НОВИЙ Yaris', 1, 0, 'model-names/November2020/EICCnYqohi1VlTzuTBzH.png', 'novij-yaris', 1, NULL, '2020-12-03 09:15:09', NULL),
(2, 'C-HR', 1, 1, 'model-names/July2020/yWVeZ5IgM4Oqj6JH1N7A.png', 'c-hr', 1, NULL, '2020-08-25 04:59:06', NULL),
(3, 'Corolla', 1, 1, 'model-names/July2020/Wvvn6Rej8GkgoV8dgREF.png', 'corolla', 1, NULL, '2020-09-01 09:47:20', NULL),
(4, 'Camry', 1, 0, 'model-names/July2020/QDuLaiSG7iTI2ycKEObl.png', 'camry', 1, NULL, '2020-08-25 04:58:55', NULL),
(5, 'RAV4', 1, 1, 'model-names/July2020/q0R2Tn1ch9xB6Hhwqc0v.png', 'rav4', 1, NULL, '2020-11-20 10:51:01', NULL),
(6, 'Highlander', 0, 1, 'model-names/July2020/509Ht38bq0i4KdhlpEFt.png', 'highlander', 1, NULL, '2020-12-10 12:01:27', NULL),
(7, 'Land Cruiser Prado', 0, 1, 'model-names/July2020/DB9apivylgGLWCIEC6uN.png', 'land-cruiser-prado', 1, NULL, '2020-09-17 08:32:14', NULL),
(8, 'Land Cruiser 200', 0, 1, 'model-names/July2020/4XWRpHYs28QniBYJPYCN.png', 'land-cruiser-200', 1, NULL, '2020-12-10 12:01:35', NULL),
(9, 'Hilux', 0, 0, 'model-names/July2020/krJUdUr0jsKT2lB0IFSi.png', 'hilux', 1, NULL, '2020-08-25 04:05:51', NULL),
(10, 'Новый Yaris', 1, 0, 'model-names/November2020/iEnpCGuePXwNhgxLeMRX.png', 'novyj-yaris', 0, '2020-11-30 08:55:32', '2020-12-02 17:50:26', '2020-12-02 17:50:26');

-- --------------------------------------------------------

--
-- Структура таблицы `modifications`
--

CREATE TABLE IF NOT EXISTS `modifications` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_name_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name_pivot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_type_id` int(11) DEFAULT NULL,
  `available` tinyint(4) DEFAULT 1,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `modifications`
--

INSERT INTO `modifications` (`id`, `model_name_id`, `name`, `model_name_pivot`, `body_type_id`, `available`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Premiere Edition', 'НОВЫЙ Yaris Premiere Edition', 2, 1, 'Фонова ілюмінація центральної консолі\nБездротовий Qi-зарядний пристрій\nПроекційний кольоровий дисплей 10\" на лобовому склі\nФонова ілюмінація простору для ніг', NULL, '2020-12-02 17:51:39', NULL),
(2, 1, 'Elegant', 'НОВЫЙ Yaris Elegant', 2, 1, 'Легкосплавні диски 15\"\nСклоочисники з сенсором дощу\nСвітлодіодні фари головного світла\nФонова ілюмінація центральної консолі', NULL, '2020-12-02 17:51:46', NULL),
(3, 1, 'Active', 'НОВЫЙ Yaris Active', 2, 1, 'Камера заднього огляду\nПідтримка систем Apple CarPlay та Android Auto\nКлімат-контроль\nПідігрів передніх сидінь', NULL, '2020-12-02 17:51:59', NULL),
(4, 1, 'Style', 'НОВЫЙ Yaris Style', 2, 1, 'Тоновані стекла задніх дверей та заднє скло\nСвітлодіодні фари головного світла\nСтеля чорного кольору', NULL, '2020-12-02 17:52:10', NULL),
(6, 2, 'Active', 'C-HR Active', 1, 1, '17-дюймові легкосплавні колісні диски з п\'ятьма спицями та машинною обробкою\nКамера заднього огляду\nLDA - cистема попередження про з\'їзд зі смуги руху з функцією повернення у смугу руху\nАвтоматичне дальнє світло (AHB)\nLTA - система допомоги утримання авто в смузі руху', NULL, '2020-10-16 05:35:49', NULL),
(7, 2, 'Style', 'C-HR Style', 1, 0, '17-дюймові легкосплавні колісні диски з п\'ятьма спицями та машинною обробкою\nТоновані стекла задніх дверей та заднє скло\nSmart Entry and Start - система безключового доступу до автомобіля й запуску двигуна\nСвітлодіодні передні протитуманні фари', NULL, '2020-10-16 05:27:57', NULL),
(8, 2, 'Premium', 'C-HR Premium', 1, 1, 'Інтелектуальна система адаптивного освітлення дороги — AFS\nСистема моніторингу \"сліпих\" зон - BSM\nЕлектрорегулювання сидіння водія за висотою\nЕлектрорегулювання нахилу подушки сидіння водія\nLTA - система допомоги утримання авто в смузі руху', NULL, '2020-10-16 05:36:16', NULL),
(9, 3, 'City', 'Corolla City', 3, 1, '15-дюймові сталеві колісні диски з ковпаками з вісьмома спицями\nДатчик освітлення\nАвтоматичне вимикання фар\nСистема, що попереджає про низький тиск у шинах (TPWS)\nПрожекторні галогенові фари головного світла', NULL, '2020-08-11 08:00:46', NULL),
(10, 3, 'Live', 'Corolla Live', 3, 1, 'Хромований молдинг віконної лінії\nСвітлодіодні передні протитуманні фари\nКруїз-контроль\nТриспицеве кермо, оздоблене комбінованою шкірою\nЗадній підлокітник з тримачами для чашок\nПідігрів передніх сидінь\n6 подушок безпеки', NULL, '2020-08-11 08:01:28', NULL),
(11, 3, 'Active', 'Corolla Active', 3, 1, 'Легкосплавні диски R16\nКамера заднього огляду\nІнформаційно-розважальна система Toyota Touch 2\nБагатофункціональний сенсорний дисплей 8\"', NULL, '2020-05-22 09:20:30', NULL),
(12, 3, 'Style', 'Corolla Style', 3, 1, '17-дюймові легкосплавні колісні диски з десятьма спицями з машинною обробкою\nТоноване скло у вікнах задніх дверей\nДатчик дощу\nПрожекторні світлодіодні фари головного світла\nЦифровий спідометр\nДзеркало зворотного огляду з електрохромовим покриттям (автоматичне затемнення)', NULL, '2020-08-11 08:02:08', NULL),
(13, 4, 'Comfort', 'Camry Comfort', 3, 1, 'Світлодіодні денні ходові вогні\nКруїз-контроль\n6 гучномовців\nДвозонний клімат-контроль\nСтатичні лінії розмітки на сенсорному екрані під час перегляду сигналу з відеокамери зворотного огляду\nБагаторежимний дисплей бортового комп’ютера з діагоналлю 10,7 см', NULL, '2020-08-11 08:03:59', NULL),
(14, 4, 'Elegance', 'Camry Elegance', 3, 1, '17-дюймові легкосплавні колісні диски з десятьма спицями\nЦентральний підлокітник, оздоблений комбінованою шкірою\nОббивка карт дверей з комбінованої шкіри\nОббивка сидінь з комбінованої шкіри з перфорацією\nЕлектропривод регулювання висоти водійського сидіння\nЕлектропривод регулювання поперекової підтримки на сидінні водія', NULL, '2020-08-11 08:04:59', NULL),
(15, 4, 'Prestige', 'Camry Prestige', 3, 1, 'Транспондерна система відкривання дверей та пуску двигуна\nLDA - cистема сповіщення про з\'їзд зі смуги руху\nСистема розпізнання та інформування водія про дорожні знаки\nACC - круїз-контроль з функцією підтримки безпечної дистанції до автомобіля, що їде попереду\nTPMS - система моніторингу тиску в шинах\nДинамічні лінії розмітки на сенсорному екрані під час перегляду сигналу з відеокамери зворотного огляду', NULL, '2020-08-11 08:05:58', NULL),
(16, 4, 'Premium', 'Camry Premium', 3, 1, '18-дюймові легкосплавні колісні диски з двадцятьма спицями\nБагаторежимний дисплей бортового комп’ютера з діагоналлю 17,8 см\nІформаційно-розважальна система Toyota з навігаційною системою GPS\nСенсорний екран з діагоналлю 20,3 см (8 дюймів) на передній панелі\nЗвуковідтворювальна система фірми JBL з підсилювачем та низкочастотним гучномовцем\n9 гучномовців\nКліматична система з незалежним регулювання зон водій/передній пасажир та для 2-го ряду сидінь', NULL, '2020-08-11 08:06:38', NULL),
(17, 4, 'Premium Hybrid', 'Camry Premium Hybrid', 3, 1, 'Тоноване скло у вікнах задніх дверей\nПеремикач режимів їзди на центральній консолі\nСистема моніторінгу «сліпих» зон (BSM)\nRCTA - система попередження про поперечний рух ззаду з автоматичним гальмуванням\nСенсори паркування задні (4 шт.) з функцією автоматичного гальмування\nСенсори паркування передні (4 шт.) з функцією автоматичного гальмування', NULL, '2020-08-11 08:07:18', NULL),
(18, 5, 'Live', 'RAV4 Live', 1, 1, 'Датчик освітлення\nЕлектропривод регулювання бічних дзеркал зворотного огляду\nПідігрів бічних дзеркал зворотного огляду\nСвітлодіодні денні ходові вогні\nСистема, що попереджає про низький тиск у шинах (TPWS)\nСвітлодіодні рефлекторні фари головного світла\nІнформаційно-розважальна система Toyota Touch 2', NULL, '2020-08-11 08:08:57', NULL),
(19, 5, 'Active', 'RAV4 Active', 1, 1, 'Легкосплавні колісні диски, 17-дюймові\nКруїз-контроль\nПаркувальні датчики позаду\nКнопка пуску двигуна\nПідігрів керма', NULL, '2020-08-11 08:10:21', NULL),
(20, 5, 'Lounge', 'RAV4 Lounge', 1, 1, 'Електропривод відкривання-закривання дверей багажного відділення\nТранспондерна система відкривання дверей та пуску двигуна\nАвтоматичне дальнє світло (AHB)\nКруїз-контроль з функцією підтримки безпечної дистанції до автомобіля, що їде попереду\nСистема попередження про загрозу фронтального зіткнення з функцією автоматичного гальмування', NULL, '2020-08-11 08:12:34', NULL),
(21, 5, 'Style', 'RAV4 Style', 1, 1, 'Легкосплавні чорні колісні диски, 18-дюймові\nЧорний глянцевый дах\nПаркувальні датчики попереду\nЧорна оббивка стелі у салоні\nЕлектропривод регулювання положення водійського сидіння у поздовжньому напрямку\nЕлектропривод регулювання кута нахилу спинки водійського сидіння', NULL, '2020-08-11 08:13:52', NULL),
(22, 5, 'Premium', 'RAV4 Premium', 1, 1, 'Легкосплавні сріблясті колісні диски, 18-дюймові\nСистема безконтактного керування дверима багажного відділення\nСистема моніторінгу «сліпих» зон (BSM)\nСистема панорамного огляду (PVM)\nСистема попередження про поперечний рух ззаду під час виїзду з парковки заднім ходом (RCTA)', NULL, '2020-08-11 08:15:10', NULL),
(24, 6, 'Elegance', 'Highlander Elegance', 1, 1, 'Світлодіодні передні денні ходові вогні\nТоноване заднє скло\nХромований молдинг віконної лінії\nSmart Entry and Start - система безключового доступу до автомобіля й запуску двигуна\nАвтоматичне відключення фар головного світла\nДистанційне відкриття багажного відділення з салону', NULL, '2020-08-11 08:17:38', NULL),
(26, 7, 'Comfort', 'Land Cruiser Prado Comfort', 5, 1, 'Легкосплавні колісні диски R17\nПрожекторні фари (лінзи) з галогеновими лампами\nКруїз-контроль\nІнформаційно-розважальна система Toyota Touch 2', NULL, '2020-08-11 08:19:24', NULL),
(27, 7, 'Elegance', 'Land Cruiser Prado Elegance', 5, 1, 'Прожекторні фари (лінзи) зі світлодіодними лампами ближнього світла\nАвтоматичний коректор кута нахилу світлового променя фар\nВентиляція передніх сидінь з регулюванням інтенсивності\nОбігрів форсунок омивачів лобового скла\nОбігрів всієї поверхні лобового скла з автотаймером', NULL, '2020-08-11 08:20:02', NULL),
(28, 7, 'Prestige', 'Land Cruiser Prado Prestige', 5, 1, 'Легкосплавні колісні диски R18\nДатчик дощу\nПаркувальні датчики попереду\nСистема сповіщення про з’їзд з обраної смуги руху (LDA)\nСистема розпізнання та інформування водія про дорожні знаки\nКруїз-контроль з функцією підтримки безпечної дистанції до автомобіля, що їде попереду\nПідігрів керма', NULL, '2020-08-11 08:20:37', NULL),
(29, 7, 'Premium', 'Land Cruiser Prado Premium', 5, 1, 'Система відеокамер для огляду навколо автомобіля з функцією панорамного виду\nАдаптивна підвіска з регулюванням жорсткості (AVS)\nПеремикач режимів їзди на центральній консолі\nСистема панорамного огляду (PVM)\nІнформаційно-розважальна система Toyota Touch 2 з навігаційною системою GO', NULL, '2020-08-11 08:21:10', NULL),
(30, 8, 'Elegance', 'Land Cruiser 200 Elegance', 5, 1, '18-дюймові легкосплавні диски з п’ятьма подвоєними спицями\nСистема підвищення стабільності руху та позашляхових можливостей (KDSS)\nПрожекторні фари (лінзи) зі світлодіодними лампами ближнього та дальнього світла\n6 гучномовців\nКнопка пуску двигуна', NULL, '2020-08-11 08:22:09', NULL),
(31, 8, 'Premium', 'Land Cruiser 200 Premium', 5, 0, NULL, NULL, '2020-09-15 04:51:27', NULL),
(32, 8, 'Special Edition', 'Land Cruiser 200 Special Edition', 5, 1, '20-дюймові легкосплавні диски з п’ятьма подвоєними спицями з механічно обробленною поверхнею\nФари головного світла з чорними вставками', NULL, '2020-08-20 08:03:03', '2020-08-20 08:03:03'),
(33, 9, 'Business', 'Hilux Business', 4, 1, 'Сенсор освітлення\n Кондиціонер з ручним керуванням\n Підігрів передніх сидінь\n 7 подушок безпеки - фронтальні, передні бокові, захисні шторки та колінна', NULL, '2020-08-17 05:50:43', NULL),
(34, 9, 'Comfort', 'Hilux Comfort', 4, 1, 'Легкосплавні темно-сірі диски R17\n Світлодіодні передні протитуманні фари\n Багатофункціональний сенсорний дисплей 8\"\n Підтримка систем Apple CarPlay та Android Auto', NULL, '2020-08-17 05:51:04', NULL),
(35, 9, 'Legend', 'Hilux Legend', 4, 1, 'Ручка відкриття борту кузова темно-сірого кольору\n Ексклюзивний дизайн переднього бампера\n Декоративні накладки колісних арок\n Фонова ілюмінація на картах задніх дверей', NULL, '2020-08-17 05:50:15', NULL),
(36, 4, 'Prestige Hybrid', 'Camry Prestige Hybrid', 3, 1, 'ранспондерна система відкривання дверей та пуску двигуна\nLDA - cистема сповіщення про з\'їзд зі смуги руху\nСистема розпізнання та інформування водія про дорожні знаки\nACC - круїз-контроль з функцією підтримки безпечної дистанції до автомобіля, що їде попереду\nTPMS - система моніторингу тиску в шинах\nДинамічні лінії розмітки на сенсорному екрані під час перегляду сигналу з відеокамери зворотного огляду\nІонізатор повітря nanoe\nПідсвічування простору під ногами водія та переднього пасажира\nКнопки керування круїз-контролем з функцією підтримки безпечної дистанції до автомобіля, що їде попереду, на кермі\n7 подушок безпеки', '2020-05-22 12:48:27', '2020-08-10 07:35:16', NULL),
(37, 8, 'Executive Lounge', 'Land Cruiser 200 Executive Lounge', 5, 1, '20-дюймові легкосплавні диски з п’ятьма подвоєними спицями з механічно обробленною поверхнею\nФари головного світла з чорними вставками', '2020-05-23 16:49:01', '2020-08-11 08:15:35', NULL),
(38, 9, 'Premium', 'Hilux Premium', 4, 1, 'Легкосплавні чорні диски з механічною обробкою R18\n Smart Entry and Start - система безключового доступу до автомобіля й запуску двигуна\n Бокові підніжки\n Круїз-контроль', '2020-05-23 17:14:20', '2020-08-17 05:49:37', NULL),
(39, 6, 'Premium', 'Highlander Premium', 1, 1, 'Легкосплавні диски R20\nПовнорозмірне легкосплавне запасне колесо\nАнтена \"плавник акули\" на даху\nЗадний спойлер пофарбованний у колір кузова\nОкантовка вікон чорного кольору\nРучки дверей фарбовані у колір кузову\nСвітлодіодні передні денні ходові вогні\nТоноване заднє скло\nХромована вставка верхньої радіаторної решітки\nХромована радіаторна решітка\nХромований молдинг віконної лінії\nSmart Entry and Start - система безключового доступу до автомобіля й запуску двигуна\nАвтоматичне відключення фар головного світла\nДистанційне відкриття багажного відділення з салону\nДистанційне відкриття дверей багажного відділення\nЕлектропривід дверей багажного відділення\nЗовнішні дзеркала з автоматичним складанням\nЗовнішні дзеркала з обігрівом\nЗовнішні дзеркала з електрорегулюванням\nЗовнішні дзеркала з функцією автоматичного нахилу під час руху заднім ходом\nЛампи в бокових дзеркала, що підсвічують зону порогів\nПам`ять положення зовнішніх дзеркал заднього огляду\nПанорамний дах із зсувним електричним люком\nСенсор освітлення\nСклоочисники з сенсором дощу\nЦентральний замок з дистанційним керуванням\nСріблясті рейлінги на даху\nБризковики задні\nБризковики передні\nЗадній спойлер\nПеремикач режимів повного приводу\nСелектор вибору режимів водіння\nІнформаційно-розважальна система Toyota Touch 2 з навігаційною системою Go\nІнформаційно-розважальна система Toyota Touch 2\nDAB-антена\nБагатофункціональний сенсорний дисплей 8\"\nГолосове керування\nЛінійний вхід AUX\nПреміальна акустична система JBL\nСистема безпровідного зв\'язку за протоколом Bluetooth\nПідтримка систем Apple CarPlay та Android Auto\n11 динаміків\nРоз\'єми USB попереду (3 шт.)\nРоз\'єми USB позаду (2 шт.)\nАлюмінієві накладки на пороги\nКермо оздоблене шкірою\nМ\'яке оздоблення карт задніх дверей\nМ\'яке оздоблення центральної консолі\nОздоблення селектору КПП шкірою\nСтеля сірого кольору\nФонова ілюмінація передніх дверей\nФонова ілюмінація центральної консолі\nЕлектричне стоянкове гальмо', '2020-07-28 15:52:36', '2020-08-10 07:32:40', NULL),
(40, 7, 'Base', 'Land Cruiser Prado Base', 5, 0, 'Чорна радіаторна решітка \nЧорні ручки дверей \nЧорні зовнішні дзеркала заднього огляду \nЗадній інтегрований спойлер S Бокові підніжки \n Бризковики передні та задні S Металевий захист картеру двигуна \n Колісні диски: R17 сталеві, шини 245/70 R17', '2020-08-11 08:35:27', '2020-10-16 08:39:37', NULL),
(41, 5, 'BLACK', 'RAV4 BLACK', 1, 1, 'Рейлінги чорного кольору на даху \nЧорна глянцева решітка радіатора \nЧорні глянцеві декоратиіні вставки переднього та заднього бамперів \nПередній та задній бампери глянцевого чорного кольору \nГлянцеве обрамлення протитуманних фар \nНакладка дверей та колісних арок глянцевого чорного кольору', '2020-09-07 04:56:37', '2020-10-06 06:17:29', NULL),
(42, 7, 'COMFORT+', 'Land Cruiser Prado COMFORT+', 5, 1, 'Чорна фарбована радіаторна решітка з оздобленням темним хромом\nЗатемнена передня та задня оптика\nДекоративні накладки протитуманих фар чорного кольору\nНакладка дверей багажного відділення з оздобленням темним хромом\nБокові підніжки із сріблястою декоративною окантовкою та освітленням зони порогів\nКолісні диски : легкосплавні (чорні глянцеві), шини 265/60 R18', '2020-10-16 07:07:32', '2020-10-16 07:07:32', NULL),
(43, 7, 'Prestige+', 'Land Cruiser Prado Prestige+', 5, 1, 'Зовнішні дзеркала заднього огляду кольору кузова\nЗовнішні дзеркала заднього огляду чорного кольору\nАнтена \"плавник акули\" на даху\nСистема допомоги під час паркування із камерою заднього виду з динамічними графічними підказками\nPVM - cистема панорамного огляду з передньою, задньою та двома боковими камерами\nПідтримка систем Apple CarPlay та Android Auto', '2020-10-16 08:17:22', '2020-10-16 08:17:22', NULL),
(44, 1, 'ACTIVE', 'НОВИЙ Yaris ACTIVE', 2, 0, 'Камера заднього огляду\n Підтримка систем Apple CarPlay та Android Auto\n Клімат-контроль\n Підігрів передніх сидінь', '2020-11-23 10:39:28', '2020-11-23 17:05:44', '2020-11-23 17:05:44'),
(45, 1, 'ELEGANT', 'НОВИЙ Yaris ELEGANT', 2, 0, 'Легкосплавні диски 15\"\n Склоочисники з сенсором дощу\n Світлодіодні фари головного світла\n Фонова ілюмінація центральної консолі', '2020-11-23 10:40:03', '2020-11-23 17:05:44', '2020-11-23 17:05:44'),
(46, 1, 'YARIS STYLE', 'НОВИЙ Yaris YARIS STYLE', 2, 0, 'Тоновані стекла задніх дверей та заднє скло\n Світлодіодні фари головного світла\n Стеля чорного кольору', '2020-11-23 10:40:35', '2020-11-23 17:05:44', '2020-11-23 17:05:44'),
(47, 1, 'PREMIERE EDITION', 'НОВИЙ Yaris PREMIERE EDITION', 2, 0, 'Фонова ілюмінація центральної консолі\n Бездротовий Qi-зарядний пристрій\n Проекційний кольоровий дисплей 10\" на лобовому склі\n Фонова ілюмінація простору для ніг', '2020-11-23 10:41:25', '2020-11-23 17:05:44', '2020-11-23 17:05:44'),
(48, 10, 'Style', 'Новый Yaris Style', 2, 0, 'Все есть', '2020-11-30 08:56:59', '2020-12-02 17:48:26', '2020-12-02 17:48:26');

-- --------------------------------------------------------

--
-- Структура таблицы `mod_color_pivots`
--

CREATE TABLE IF NOT EXISTS `mod_color_pivots` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `modification_id` int(11) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `preview` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `mod_color_pivots`
--

INSERT INTO `mod_color_pivots` (`id`, `modification_id`, `color_id`, `preview`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 3, 3, 'mod-color-pivots/May2020/9EdFDiC0X2TjivdH8y8z.png', NULL, '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(5, 3, 8, 'mod-color-pivots/May2020/Ftncwi3v41xHypfjqZA3.png', NULL, '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(6, 3, 4, 'mod-color-pivots/May2020/SAar3u6eG6en4STojlsb.png', '2020-05-11 08:08:14', '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(7, 3, 18, 'mod-color-pivots/May2020/zy1McwrrPYb7QyYBhxsZ.png', '2020-05-22 03:30:00', '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(8, 3, 5, 'mod-color-pivots/May2020/p0kNp8LHZgfJuRCpwd3j.png', '2020-05-22 05:24:54', '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(9, 3, 6, 'mod-color-pivots/May2020/GO0XuHjz1rPkaJUrqZLq.png', '2020-05-22 05:27:34', '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(10, 3, 7, 'mod-color-pivots/May2020/HS4A8TuzNa0kZygwA8p4.png', '2020-05-22 05:28:48', '2020-11-11 17:17:12', '2020-11-11 17:17:12'),
(12, 9, 17, 'mod-color-pivots/May2020/V0aXhMUDYCBSzQ0hN1qV.png', '2020-05-31 13:05:49', '2020-05-31 13:05:49', NULL),
(13, 9, 6, 'mod-color-pivots/May2020/dmP1r9pWWfzun46S4Ffz.png', '2020-05-31 13:06:28', '2020-05-31 13:06:28', NULL),
(14, 9, 12, 'mod-color-pivots/May2020/aKlscw6RaMmWpkeHTI1T.png', '2020-05-31 13:07:19', '2020-05-31 13:07:19', NULL),
(15, 9, 3, 'mod-color-pivots/May2020/14hV3Rlz0QWwdt9r8Mfe.png', '2020-05-31 13:07:38', '2020-05-31 13:07:38', NULL),
(16, 9, 15, 'mod-color-pivots/May2020/N1cskETPFfiNobTHsWPt.png', '2020-05-31 13:08:07', '2020-05-31 13:08:07', NULL),
(17, 9, 16, 'mod-color-pivots/May2020/BkzczxYxbaiDikdbz8AX.png', '2020-05-31 13:08:32', '2020-05-31 13:08:32', NULL),
(18, 9, 14, 'mod-color-pivots/May2020/AGQ6od5MON3UMmLVAfzv.png', '2020-05-31 13:09:04', '2020-05-31 13:09:04', NULL),
(19, 9, 13, 'mod-color-pivots/May2020/2d8Dz18Yx5bp3leVZWrj.png', '2020-05-31 13:09:39', '2020-05-31 13:09:39', NULL),
(20, 9, 8, 'mod-color-pivots/May2020/Bgp6VEkcpBPSgNKUOm8c.png', '2020-05-31 13:10:20', '2020-05-31 13:10:20', NULL),
(21, 10, 17, 'mod-color-pivots/May2020/jGKWkzhZj6VLwDYEJgp3.png', '2020-05-31 13:12:43', '2020-05-31 13:12:43', NULL),
(22, 10, 6, 'mod-color-pivots/May2020/NgAs4UTU3mhazNe2WEsZ.png', '2020-05-31 13:13:15', '2020-05-31 13:13:15', NULL),
(23, 10, 12, 'mod-color-pivots/May2020/doEOilCKlcjrackuvdom.png', '2020-05-31 13:13:57', '2020-05-31 13:13:57', NULL),
(24, 10, 3, 'mod-color-pivots/May2020/WRbtoMIsjrt1Z1g4hSUU.png', '2020-05-31 13:14:14', '2020-05-31 13:14:14', NULL),
(25, 10, 15, 'mod-color-pivots/May2020/vyVkV8pzXW5tpefvCnfZ.png', '2020-05-31 13:14:36', '2020-05-31 13:14:36', NULL),
(26, 10, 16, 'mod-color-pivots/May2020/GU5Cu4BjcBEmSuqJqeT9.png', '2020-05-31 13:14:59', '2020-05-31 13:14:59', NULL),
(27, 10, 14, 'mod-color-pivots/May2020/Flaf6BxnZowg7d6B7ani.png', '2020-05-31 13:15:22', '2020-05-31 13:15:22', NULL),
(28, 10, 13, 'mod-color-pivots/May2020/JRrBkr512Z7V1DmEBbSQ.png', '2020-05-31 13:15:45', '2020-05-31 13:15:45', NULL),
(29, 10, 8, 'mod-color-pivots/May2020/pSh7I9zdSOXBQm8zXDQS.png', '2020-05-31 13:16:06', '2020-05-31 13:16:06', NULL),
(30, 11, 17, 'mod-color-pivots/May2020/skLFQ9Ek2dsf7mURqCfg.png', '2020-05-31 13:18:32', '2020-05-31 13:18:32', NULL),
(31, 11, 6, 'mod-color-pivots/May2020/qpNNUIt12llTTezXG3FH.png', '2020-05-31 13:19:22', '2020-05-31 13:19:22', NULL),
(32, 11, 12, 'mod-color-pivots/May2020/Hbuqqf2SQSnqF8K4kGqi.png', '2020-05-31 13:19:44', '2020-05-31 13:19:44', NULL),
(33, 11, 3, 'mod-color-pivots/May2020/Y4weKiR6axeNOG2DXuXP.png', '2020-05-31 13:20:36', '2020-05-31 13:20:36', NULL),
(34, 11, 15, 'mod-color-pivots/May2020/0vhomDsccAFPBgzSCW36.png', '2020-05-31 13:21:04', '2020-05-31 13:21:04', NULL),
(35, 11, 16, 'mod-color-pivots/May2020/6BS1oNtXZHZTQfslWdJV.png', '2020-05-31 13:21:28', '2020-05-31 13:21:28', NULL),
(36, 11, 14, 'mod-color-pivots/May2020/DzU3YCiAd3OsjWR9s8Fx.png', '2020-05-31 13:21:50', '2020-05-31 13:21:50', NULL),
(37, 11, 13, 'mod-color-pivots/May2020/b5fSXqk6S5UVXAFD3fbn.png', '2020-05-31 13:22:11', '2020-05-31 13:22:11', NULL),
(38, 11, 8, 'mod-color-pivots/May2020/9wyNf3OySXALMppGlw5a.png', '2020-05-31 13:22:33', '2020-05-31 13:22:33', NULL),
(39, 12, 17, 'mod-color-pivots/May2020/Jqtnk8GNIzxiovBRlf02.png', '2020-05-31 13:24:37', '2020-05-31 13:24:37', NULL),
(40, 12, 6, 'mod-color-pivots/May2020/FnkBAyogo60eQCKCRCwX.png', '2020-05-31 13:25:04', '2020-05-31 13:25:04', NULL),
(41, 12, 12, 'mod-color-pivots/May2020/AP3xrkHyNpvm96TW57cp.png', '2020-05-31 13:25:25', '2020-05-31 13:25:25', NULL),
(42, 12, 3, 'mod-color-pivots/May2020/B1grVhivd4TlWQ9i8IFI.png', '2020-05-31 13:25:44', '2020-05-31 13:25:44', NULL),
(43, 12, 15, 'mod-color-pivots/May2020/pbEe8thzbtdIGGCTrR0x.png', '2020-05-31 13:26:11', '2020-05-31 13:26:11', NULL),
(44, 12, 16, 'mod-color-pivots/May2020/xGhvdK8jL166CSEGeeKs.png', '2020-05-31 13:26:36', '2020-05-31 13:26:36', NULL),
(45, 12, 14, 'mod-color-pivots/May2020/zowWXTgceDx6Zv4Xfg36.png', '2020-05-31 13:27:00', '2020-05-31 13:27:00', NULL),
(46, 12, 13, 'mod-color-pivots/May2020/BFl349bVmuImsekxJ2JP.png', '2020-05-31 13:27:46', '2020-05-31 13:27:46', NULL),
(47, 12, 8, 'mod-color-pivots/May2020/A8XL7xOSwZDZzz5k8mm8.png', '2020-05-31 13:28:09', '2020-05-31 13:28:09', NULL),
(48, 6, 4, 'mod-color-pivots/July2020/i0GO7QIEb9x8G7lvRopH.png', '2020-07-28 07:53:10', '2020-07-28 07:53:10', NULL),
(49, 6, 13, 'mod-color-pivots/July2020/9asS36damktaEzRubiUS.png', '2020-07-28 07:53:45', '2020-07-28 07:53:45', NULL),
(50, 6, 14, 'mod-color-pivots/July2020/nLXSMFd3fVmed82tF58q.png', '2020-07-28 07:54:05', '2020-07-28 07:54:05', NULL),
(51, 6, 16, 'mod-color-pivots/July2020/Mc3tPmLuFutevUJpKuWZ.png', '2020-07-28 07:54:26', '2020-07-28 07:54:26', NULL),
(52, 6, 5, 'mod-color-pivots/July2020/JosGWpeysq6bm2u8BCRG.png', '2020-07-28 07:54:44', '2020-07-28 07:54:44', NULL),
(53, 6, 12, 'mod-color-pivots/July2020/cA95re2BsJFtqjNoZ35v.png', '2020-07-28 07:55:02', '2020-07-28 07:55:02', NULL),
(54, 6, 6, 'mod-color-pivots/July2020/Zt56YXhGefrev4FdkM5M.png', '2020-07-28 07:55:19', '2020-07-28 07:55:19', NULL),
(55, 7, 33, 'mod-color-pivots/July2020/Quj63tzhvLLChUE26HAl.png', '2020-07-28 08:42:47', '2020-07-28 08:42:47', NULL),
(56, 7, 29, 'mod-color-pivots/July2020/8bLUvmlNtCpnfJCTfsv9.png', '2020-07-28 08:43:15', '2020-07-28 08:43:15', NULL),
(57, 7, 28, 'mod-color-pivots/July2020/nxhXRu4fpnDUg5aloX1j.png', '2020-07-28 08:43:33', '2020-07-28 08:43:33', NULL),
(58, 7, 30, 'mod-color-pivots/July2020/HI7wm4U4yvP0pxhTJiIq.png', '2020-07-28 08:43:52', '2020-07-28 08:43:52', NULL),
(59, 7, 31, 'mod-color-pivots/July2020/BXND0itOFqp6yil9kOQn.png', '2020-07-28 08:44:12', '2020-07-28 08:44:12', NULL),
(60, 7, 32, 'mod-color-pivots/July2020/gZLLuGIaVqus9mxRzQBf.png', '2020-07-28 08:44:34', '2020-07-28 08:44:34', NULL),
(61, 8, 33, 'mod-color-pivots/November2020/Ec1gUH0SEYlhgA7iWcTV.png', '2020-07-28 08:51:23', '2020-11-06 08:28:55', NULL),
(62, 8, 29, 'mod-color-pivots/November2020/Z7gyZyMETooMBCthDCac.png', '2020-07-28 08:51:43', '2020-11-06 08:28:32', NULL),
(63, 8, 30, 'mod-color-pivots/November2020/eK6razfpnoAguanv3hTf.png', '2020-07-28 08:52:04', '2020-11-06 08:28:03', NULL),
(64, 8, 34, 'mod-color-pivots/November2020/uOnz1kYL6jfS05u5nnpD.png', '2020-07-28 08:52:24', '2020-11-06 08:27:20', NULL),
(65, 13, 8, 'mod-color-pivots/July2020/q7x8jGrjVebgOmMGgsHH.png', '2020-07-28 09:13:51', '2020-07-28 09:13:51', NULL),
(66, 13, 16, 'mod-color-pivots/July2020/WaeHmwqC8nICMni0uUVv.png', '2020-07-28 09:14:12', '2020-07-28 09:14:12', NULL),
(67, 13, 20, 'mod-color-pivots/July2020/z14mpbrwK1EpNcaXasaK.png', '2020-07-28 09:14:35', '2020-07-28 09:14:35', NULL),
(68, 13, 21, 'mod-color-pivots/July2020/8ngMdooAKcEIIHVUxD4H.png', '2020-07-28 09:14:58', '2020-07-28 09:14:58', NULL),
(69, 13, 22, 'mod-color-pivots/July2020/Wqwa3YAaIpyGpjaHPRBP.png', '2020-07-28 09:15:22', '2020-07-28 09:15:22', NULL),
(70, 13, 19, 'mod-color-pivots/July2020/qc5weIIQfuBF1qsrCZL9.png', '2020-07-28 09:15:40', '2020-07-28 09:15:40', NULL),
(71, 13, 23, 'mod-color-pivots/July2020/kst6PqLDmjZ8I7hNBa63.png', '2020-07-28 09:15:58', '2020-07-28 09:15:58', NULL),
(72, 14, 8, 'mod-color-pivots/July2020/7wCC95D4UzBgHPbBY4IW.png', '2020-07-28 09:18:04', '2020-07-28 09:18:04', NULL),
(73, 14, 16, 'mod-color-pivots/July2020/NZy4JB4bSC1ug8oUFJ0m.png', '2020-07-28 09:18:26', '2020-07-28 09:18:26', NULL),
(74, 14, 20, 'mod-color-pivots/July2020/UsweXFbmTOppC4GUeelI.png', '2020-07-28 09:18:45', '2020-07-28 09:18:45', NULL),
(75, 14, 21, 'mod-color-pivots/July2020/KBO24lATchNNCtCysxcm.png', '2020-07-28 09:19:06', '2020-07-28 09:19:06', NULL),
(76, 14, 22, 'mod-color-pivots/July2020/YJ8yEFxYaZ6KoUib7Tyx.png', '2020-07-28 09:19:29', '2020-07-28 09:19:29', NULL),
(77, 14, 19, 'mod-color-pivots/July2020/Kp4zyPQIcxJTxncoTr1z.png', '2020-07-28 09:19:49', '2020-07-28 09:19:49', NULL),
(78, 14, 23, 'mod-color-pivots/July2020/8k915rPPxFGEGXSqRzDD.png', '2020-07-28 09:20:14', '2020-07-28 09:20:14', NULL),
(79, 15, 8, 'mod-color-pivots/July2020/TgfnNw1CWx3zfCZHIsLr.png', '2020-07-28 09:21:46', '2020-07-28 09:22:02', NULL),
(80, 15, 16, 'mod-color-pivots/July2020/1VpoU676U4XSy1tvrX57.png', '2020-07-28 09:22:21', '2020-07-28 09:22:21', NULL),
(81, 15, 20, 'mod-color-pivots/July2020/gEfwVKRde2TH3yPsNPuv.png', '2020-07-28 09:22:43', '2020-07-28 09:22:43', NULL),
(82, 15, 21, 'mod-color-pivots/July2020/oZSfA9i1zRsBFv4xHMpq.png', '2020-07-28 09:23:03', '2020-07-28 09:23:03', NULL),
(83, 15, 22, 'mod-color-pivots/July2020/wGXwbDLmj9X3sfBxsjqp.png', '2020-07-28 09:23:25', '2020-07-28 09:23:25', NULL),
(84, 15, 19, 'mod-color-pivots/July2020/2r0zOiKDGU9AiH1jqrQC.png', '2020-07-28 09:23:46', '2020-07-28 09:23:46', NULL),
(85, 15, 23, 'mod-color-pivots/July2020/H2DbU9mu1782ZbtEiijG.png', '2020-07-28 09:24:03', '2020-07-28 09:24:03', NULL),
(86, 36, 8, 'mod-color-pivots/July2020/7LeIvKg9MrvVDXf6pKns.png', '2020-07-28 09:26:07', '2020-07-28 09:26:07', NULL),
(87, 36, 16, 'mod-color-pivots/July2020/FkcJTDUA7byUKsSwnigc.png', '2020-07-28 09:26:32', '2020-07-28 09:26:32', NULL),
(88, 36, 20, 'mod-color-pivots/July2020/RYcqISS5xFLjdPRgLSiF.png', '2020-07-28 09:26:58', '2020-07-28 09:26:58', NULL),
(89, 36, 21, 'mod-color-pivots/July2020/LiRqSdEBenF8OeMPyOja.png', '2020-07-28 09:27:24', '2020-07-28 09:27:24', NULL),
(90, 36, 22, 'mod-color-pivots/July2020/Ljk2XOBi9vcPCSNYIrgK.png', '2020-07-28 09:27:49', '2020-07-28 09:27:49', NULL),
(91, 36, 3, 'mod-color-pivots/July2020/rWFwa0LLCziLaQae6jDE.png', '2020-07-28 09:28:08', '2020-07-28 09:28:08', NULL),
(92, 36, 19, 'mod-color-pivots/July2020/EvO6PJvy73YsLkkWB0Gb.png', '2020-07-28 09:28:29', '2020-07-28 09:28:29', NULL),
(93, 36, 23, 'mod-color-pivots/July2020/w2kVkPy3meVcooFo5Diu.png', '2020-07-28 09:28:50', '2020-07-28 09:28:50', NULL),
(94, 16, 8, 'mod-color-pivots/July2020/bbpw9DNkoboHpv0Z38FD.png', '2020-07-28 09:30:44', '2020-07-28 09:30:44', NULL),
(95, 16, 16, 'mod-color-pivots/July2020/dNPnw9K09eHTnciXIgi3.png', '2020-07-28 09:31:05', '2020-07-28 09:31:05', NULL),
(96, 16, 20, 'mod-color-pivots/July2020/yuuu8ulrH77kasEaEQmL.png', '2020-07-28 09:31:24', '2020-07-28 09:31:24', NULL),
(97, 16, 21, 'mod-color-pivots/July2020/asyAy1gOvBModNo64c6Z.png', '2020-07-28 09:31:43', '2020-07-28 09:31:43', NULL),
(98, 16, 22, 'mod-color-pivots/July2020/yne4IkxJcN2ZmGZod56Y.png', '2020-07-28 09:32:26', '2020-07-28 09:32:26', NULL),
(99, 16, 19, 'mod-color-pivots/July2020/XRhZPJmEqKAsaw3ET3pV.png', '2020-07-28 09:32:50', '2020-07-28 09:32:50', NULL),
(100, 16, 23, 'mod-color-pivots/July2020/bn7WiIn5QFngjk5SnFGp.png', '2020-07-28 09:33:15', '2020-07-28 09:33:15', NULL),
(101, 17, 8, 'mod-color-pivots/July2020/dhEq7hZQUGII92zF3nxs.png', '2020-07-28 09:35:20', '2020-07-28 09:35:20', NULL),
(102, 17, 16, 'mod-color-pivots/July2020/egvbd1QLVYw81u2TLJAQ.png', '2020-07-28 09:35:40', '2020-07-28 09:35:40', NULL),
(103, 17, 20, 'mod-color-pivots/July2020/pvnwgWdLgpiLQB3jskCO.png', '2020-07-28 09:35:59', '2020-07-28 09:35:59', NULL),
(104, 17, 21, 'mod-color-pivots/July2020/gyqMObSRRjSpZ6nHvGq6.png', '2020-07-28 09:36:19', '2020-07-28 09:36:19', NULL),
(105, 17, 22, 'mod-color-pivots/July2020/qpPNwxUADaIFyLN0mrnq.png', '2020-07-28 09:36:53', '2020-07-28 09:36:53', NULL),
(106, 17, 19, 'mod-color-pivots/July2020/jfbiPpV3fWH4Qo6cBRkx.png', '2020-07-28 09:37:13', '2020-07-28 09:37:13', NULL),
(107, 17, 23, 'mod-color-pivots/July2020/RkCgOmZueYPIyQVW0efR.png', '2020-07-28 09:37:34', '2020-07-28 09:37:34', NULL),
(108, 18, 26, 'mod-color-pivots/July2020/yXLiMSv8UZJfMJY4MuMp.png', '2020-07-28 09:41:10', '2020-07-28 09:41:10', NULL),
(109, 18, 4, 'mod-color-pivots/July2020/TVkiPMUgOo2vuu8ZvadC.png', '2020-07-28 09:41:33', '2020-07-28 09:41:33', NULL),
(110, 18, 10, 'mod-color-pivots/July2020/h1TsYfYNbF1UGyIQGHwD.png', '2020-07-28 09:41:55', '2020-07-28 09:41:55', NULL),
(111, 18, 24, 'mod-color-pivots/July2020/0CFKIFCrbgM8MPKMNtJL.png', '2020-07-28 09:42:18', '2020-07-28 09:42:18', NULL),
(112, 18, 27, 'mod-color-pivots/July2020/p5cpQenFTZMKKN8fg8kz.png', '2020-07-28 09:42:44', '2020-07-28 09:42:44', NULL),
(113, 18, 25, 'mod-color-pivots/July2020/VUXctjTGwxT0AQPlYnhX.png', '2020-07-28 09:43:30', '2020-07-28 09:43:30', NULL),
(114, 18, 3, 'mod-color-pivots/July2020/Zh6fm26aXMY3PuKP2wwA.png', '2020-07-28 09:43:49', '2020-07-28 09:43:49', NULL),
(115, 18, 12, 'mod-color-pivots/July2020/KH9WJrh0S87z5MyonJdk.png', '2020-07-28 09:44:13', '2020-07-28 09:44:13', NULL),
(116, 18, 23, 'mod-color-pivots/July2020/niQ3RqzcjzElA40JLj8m.png', '2020-07-28 09:44:39', '2020-07-28 09:44:39', NULL),
(117, 19, 26, 'mod-color-pivots/July2020/7hk9oH5QN8opCPFL50T4.png', '2020-07-28 09:47:43', '2020-07-28 09:47:43', NULL),
(118, 19, 4, 'mod-color-pivots/July2020/jAsi23oNzGFKgaBBq2Js.png', '2020-07-28 09:48:05', '2020-07-28 09:48:05', NULL),
(119, 19, 10, 'mod-color-pivots/July2020/PdnT2182lrqOLsnDZQn7.png', '2020-07-28 09:48:24', '2020-07-28 09:48:24', NULL),
(120, 19, 24, 'mod-color-pivots/July2020/IvCMHVRxs8C1snV9NbE9.png', '2020-07-28 09:48:47', '2020-07-28 09:48:47', NULL),
(121, 19, 27, 'mod-color-pivots/July2020/sT0ArK3MjRASTSgcsE9M.png', '2020-07-28 09:49:10', '2020-07-28 09:49:10', NULL),
(122, 19, 25, 'mod-color-pivots/July2020/ZP2uUlui44tC35M8ml64.png', '2020-07-28 09:49:35', '2020-07-28 09:49:35', NULL),
(123, 19, 3, 'mod-color-pivots/July2020/t7rW3U2A7mrWNqGpLpSu.png', '2020-07-28 09:49:57', '2020-07-28 09:49:57', NULL),
(124, 19, 12, 'mod-color-pivots/July2020/KxnDMej6EL0jAVDXat3m.png', '2020-07-28 09:50:25', '2020-07-28 09:50:25', NULL),
(125, 19, 23, 'mod-color-pivots/July2020/zBn0HEt6zdH8EIUr22ob.png', '2020-07-28 09:50:45', '2020-07-28 09:50:45', NULL),
(126, 20, 26, 'mod-color-pivots/July2020/roxypl8NdUbumLCjEJ6O.png', '2020-07-28 09:58:40', '2020-07-28 09:58:40', NULL),
(127, 20, 4, 'mod-color-pivots/July2020/T2geGtTmDaWthSUo5L4X.png', '2020-07-28 09:59:09', '2020-07-28 09:59:09', NULL),
(128, 20, 10, 'mod-color-pivots/July2020/D3nO4aAmk8tv3nD2fDQl.png', '2020-07-28 09:59:39', '2020-07-28 09:59:39', NULL),
(129, 20, 24, 'mod-color-pivots/July2020/DfzUEotrxBg5xi7uIDRH.png', '2020-07-28 09:59:58', '2020-07-28 09:59:58', NULL),
(130, 20, 27, 'mod-color-pivots/July2020/k21H0CHuiqiForhpenUx.png', '2020-07-28 10:00:29', '2020-07-28 10:00:29', NULL),
(131, 20, 25, 'mod-color-pivots/July2020/jx4N2mPPSinuEAFqX6qw.png', '2020-07-28 10:01:06', '2020-07-28 10:01:06', NULL),
(132, 20, 3, 'mod-color-pivots/July2020/VgNBzYcw1ZkEz8gxHuiv.png', '2020-07-28 10:01:25', '2020-07-28 10:01:25', NULL),
(133, 20, 12, 'mod-color-pivots/July2020/rXdWqLa0U3Rjf1pTi5OI.png', '2020-07-28 10:01:47', '2020-07-28 10:01:47', NULL),
(134, 20, 23, 'mod-color-pivots/July2020/H5V5JFDneAbd0N80sCh5.png', '2020-07-28 10:02:08', '2020-07-28 10:02:08', NULL),
(135, 22, 26, 'mod-color-pivots/July2020/vCLWqme70eXIGVGjLcGE.png', '2020-07-28 10:04:57', '2020-07-28 10:04:57', NULL),
(136, 22, 4, 'mod-color-pivots/July2020/uqB34vhDaYwy9nHiIV0e.png', '2020-07-28 10:05:30', '2020-07-28 10:05:30', NULL),
(137, 22, 10, 'mod-color-pivots/July2020/jdNVYAPvElNgRHvlR0ad.png', '2020-07-28 10:06:00', '2020-07-28 10:06:00', NULL),
(138, 22, 24, 'mod-color-pivots/July2020/rAI5q2ocfUDbDHnHQ4pq.png', '2020-07-28 10:06:21', '2020-07-28 10:06:21', NULL),
(139, 22, 27, 'mod-color-pivots/July2020/f2E7YCoJ4sCgRZfWSmGm.png', '2020-07-28 10:06:52', '2020-07-28 10:06:52', NULL),
(140, 22, 25, 'mod-color-pivots/July2020/bJ7yk8lg2j8h528QMBhc.png', '2020-07-28 10:07:11', '2020-07-28 10:07:11', NULL),
(141, 22, 12, 'mod-color-pivots/July2020/AHLsgOECcw0hDDqHbmBW.png', '2020-07-28 10:07:33', '2020-07-28 10:07:33', NULL),
(142, 22, 23, 'mod-color-pivots/July2020/UAW8u44n9BDx1vhqN5m4.png', '2020-07-28 10:08:01', '2020-07-28 10:08:01', NULL),
(143, 21, 38, 'mod-color-pivots/July2020/WOjilJhIhAJPouT4y8GL.png', '2020-07-28 10:22:46', '2020-07-28 10:22:46', NULL),
(144, 21, 37, 'mod-color-pivots/July2020/SLUhxTHa25IHZhI9KAu8.png', '2020-07-28 10:23:07', '2020-07-28 10:23:07', NULL),
(145, 21, 36, 'mod-color-pivots/July2020/FAgJiou0xiiowVCYUqhm.png', '2020-07-28 10:23:28', '2020-07-28 10:23:28', NULL),
(146, 21, 35, 'mod-color-pivots/July2020/M5HAxMHEYl0nlcZG2u2H.png', '2020-07-28 10:23:47', '2020-07-28 10:23:47', NULL),
(147, 24, 4, 'mod-color-pivots/July2020/LdQmwXfmX5BFemhGRtU7.png', '2020-07-28 15:46:10', '2020-07-28 15:46:10', NULL),
(148, 24, 40, 'mod-color-pivots/July2020/dZPTAzonH3dCCT3B01Ks.png', '2020-07-28 15:46:41', '2020-07-28 15:46:41', NULL),
(149, 24, 39, 'mod-color-pivots/July2020/7XMVw1oosUS4MhEzaUOJ.png', '2020-07-28 15:47:03', '2020-07-28 15:47:03', NULL),
(150, 24, 10, 'mod-color-pivots/July2020/xIaQFXSXl1BoTR5xhBAO.png', '2020-07-28 15:47:23', '2020-07-28 15:47:23', NULL),
(151, 24, 41, 'mod-color-pivots/July2020/UHQ2adApXSFgiO0fMUEf.png', '2020-07-28 15:47:46', '2020-07-28 15:47:46', NULL),
(152, 24, 25, 'mod-color-pivots/July2020/ebsVSilNNmtxeVNR9ija.png', '2020-07-28 15:48:05', '2020-07-28 15:48:05', NULL),
(153, 24, 12, 'mod-color-pivots/July2020/F3tMkkUDkKtR9ezmWarX.png', '2020-07-28 15:48:40', '2020-07-28 15:48:40', NULL),
(154, 24, 23, 'mod-color-pivots/July2020/q4tV0OZ5wM1Zm3kkpqQB.png', '2020-07-28 15:48:59', '2020-07-28 15:48:59', NULL),
(155, 39, 4, 'mod-color-pivots/July2020/QgLLUBPtLtQpMElszBFr.png', '2020-07-28 16:31:12', '2020-07-28 16:31:12', NULL),
(156, 39, 40, 'mod-color-pivots/July2020/1B0BHTJHvc3MqMDEQZbU.png', '2020-07-28 16:31:45', '2020-07-28 16:31:45', NULL),
(157, 39, 39, 'mod-color-pivots/July2020/L6MJKq1kB33jNBiFd39c.png', '2020-07-28 16:33:05', '2020-07-28 16:33:05', NULL),
(158, 39, 10, 'mod-color-pivots/July2020/WyMH1Q1G7rkPUge5Zg6e.png', '2020-07-28 16:33:45', '2020-07-28 16:33:45', NULL),
(159, 39, 41, 'mod-color-pivots/July2020/MPsnlr2HyrrPEBfv0BKg.png', '2020-07-28 16:34:06', '2020-07-28 16:34:06', NULL),
(160, 39, 25, 'mod-color-pivots/July2020/QEvCI8yri2j65E0BKlAR.png', '2020-07-28 16:34:29', '2020-07-28 16:34:29', NULL),
(161, 39, 12, 'mod-color-pivots/July2020/hYWTncSErRAXTN4lRJUU.png', '2020-07-28 16:34:51', '2020-07-28 16:34:51', NULL),
(162, 39, 23, 'mod-color-pivots/July2020/M1AJ0w2SUHdkChwCUJvG.png', '2020-07-28 16:35:15', '2020-07-28 16:35:15', NULL),
(163, 26, 8, 'mod-color-pivots/July2020/GZnNrWGelCu7YToP3jmN.png', '2020-07-28 17:38:57', '2020-07-28 17:38:57', NULL),
(164, 26, 4, 'mod-color-pivots/July2020/kEYaMFVD1mseGP1G4Em6.png', '2020-07-28 17:39:24', '2020-07-28 17:39:24', NULL),
(165, 26, 43, 'mod-color-pivots/July2020/yAbM2bDZMnAcTmC7Qtfw.png', '2020-07-28 17:39:54', '2020-07-28 17:39:54', NULL),
(166, 26, 44, 'mod-color-pivots/July2020/INUTtdnU18Y9ImuCoewA.png', '2020-07-28 17:40:21', '2020-07-28 17:40:21', NULL),
(167, 26, 45, 'mod-color-pivots/July2020/UFsdqkTQvuCoLjmyjIS1.png', '2020-07-28 17:40:54', '2020-07-28 17:40:54', NULL),
(168, 26, 3, 'mod-color-pivots/July2020/u71kAGbmE2FCkvjGFNZk.png', '2020-07-28 17:41:26', '2020-07-28 17:41:26', NULL),
(169, 26, 12, 'mod-color-pivots/July2020/4cU91srL7JUWq6lVFQct.png', '2020-07-28 17:41:50', '2020-07-28 17:41:50', NULL),
(170, 26, 42, 'mod-color-pivots/July2020/Mutms21UB1Jgn7GPAbp6.png', '2020-07-28 17:42:16', '2020-07-28 17:42:16', NULL),
(171, 26, 23, 'mod-color-pivots/July2020/9oRshaCEE5Q4I1t92sJa.png', '2020-07-28 17:42:46', '2020-07-28 17:42:46', NULL),
(172, 26, 46, 'mod-color-pivots/July2020/jvWShQSkMzocxp8YjOeQ.png', '2020-07-28 17:43:12', '2020-07-28 17:43:12', NULL),
(173, 27, 8, 'mod-color-pivots/July2020/jBKQ47fYt2QpTwmp0gmL.png', '2020-07-28 17:46:50', '2020-07-28 17:46:50', NULL),
(174, 27, 4, 'mod-color-pivots/July2020/UVLygz1yj10HvLW2VIIp.png', '2020-07-28 17:47:15', '2020-07-28 17:47:15', NULL),
(175, 27, 43, 'mod-color-pivots/July2020/SO5GgDqNmVIVhzZMWhjy.png', '2020-07-28 17:47:43', '2020-07-28 17:47:43', NULL),
(176, 27, 44, 'mod-color-pivots/July2020/8udcnxjFbS6Xqg4NVUbW.png', '2020-07-28 17:48:07', '2020-07-28 17:48:07', NULL),
(177, 27, 45, 'mod-color-pivots/July2020/GAtVoOcZNc0w7N19vLI4.png', '2020-07-28 17:48:28', '2020-07-28 17:48:28', NULL),
(178, 27, 3, 'mod-color-pivots/July2020/hgWc680QGmHAZx02v7WS.png', '2020-07-28 17:49:26', '2020-07-28 17:49:26', NULL),
(179, 27, 12, 'mod-color-pivots/July2020/hrEf2eAf1mP07EKnZeml.png', '2020-07-28 17:50:01', '2020-07-28 17:50:01', NULL),
(180, 27, 42, 'mod-color-pivots/July2020/aDfCbtzZXHnlqGS6cFvt.png', '2020-07-28 17:50:26', '2020-07-28 17:50:26', NULL),
(181, 27, 23, 'mod-color-pivots/July2020/lX9GwY1mfNOxLohJvJzX.png', '2020-07-28 17:51:00', '2020-07-28 17:51:00', NULL),
(182, 27, 46, 'mod-color-pivots/July2020/oKRWGdS9fY8GuXVu4sYq.png', '2020-07-28 17:51:21', '2020-07-28 17:51:21', NULL),
(183, 28, 8, 'mod-color-pivots/July2020/eOV1IcRl7KMYrXTMHU1V.png', '2020-07-28 17:58:12', '2020-07-28 17:58:12', NULL),
(184, 28, 4, 'mod-color-pivots/July2020/kiMhTrotFHYSkcoMhmNB.png', '2020-07-28 17:58:37', '2020-07-28 17:58:37', NULL),
(185, 28, 43, 'mod-color-pivots/July2020/QtOnTi38PoOzyLwcxeGt.png', '2020-07-28 17:59:03', '2020-07-28 17:59:03', NULL),
(186, 28, 44, 'mod-color-pivots/July2020/0aENl7IJw9yEXoy1jDau.png', '2020-07-28 17:59:25', '2020-07-28 17:59:25', NULL),
(187, 28, 45, 'mod-color-pivots/July2020/yRTDyyBUf7MxrclPnPmj.png', '2020-07-28 17:59:51', '2020-07-28 17:59:51', NULL),
(188, 28, 3, 'mod-color-pivots/July2020/ok1DtLoSpH3GHqusTOji.png', '2020-07-28 18:00:13', '2020-07-28 18:00:13', NULL),
(189, 28, 12, 'mod-color-pivots/July2020/iPiU8eiasStQjCFc5mcx.png', '2020-07-28 18:00:34', '2020-07-28 18:00:34', NULL),
(190, 28, 42, 'mod-color-pivots/July2020/OTREu7x5B81v2KjoQxeR.png', '2020-07-28 18:00:58', '2020-07-28 18:00:58', NULL),
(191, 28, 23, 'mod-color-pivots/July2020/fcCnq5ogp2n8OATKI7Ed.png', '2020-07-28 18:01:37', '2020-07-28 18:01:37', NULL),
(192, 28, 46, 'mod-color-pivots/July2020/5MTL4PMxcsPDY0c8kQej.png', '2020-07-28 18:02:03', '2020-07-28 18:02:03', NULL),
(193, 29, 8, 'mod-color-pivots/July2020/XwQUpTG6co5KQ6aBeHug.png', '2020-07-28 18:07:39', '2020-07-28 18:07:39', NULL),
(194, 29, 4, 'mod-color-pivots/July2020/J3SnATEvnWQXE0ois4ZK.png', '2020-07-28 18:08:49', '2020-07-28 18:08:49', NULL),
(195, 29, 43, 'mod-color-pivots/July2020/zRTQBFuT99xdHUnpjOjI.png', '2020-07-28 18:09:21', '2020-07-28 18:09:21', NULL),
(196, 29, 44, 'mod-color-pivots/July2020/Kq1XQPzCxS6fzYfs9UHx.png', '2020-07-28 18:10:46', '2020-07-28 18:10:46', NULL),
(197, 29, 45, 'mod-color-pivots/July2020/26VrOeekLD6vvJAzkRHV.png', '2020-07-28 18:11:13', '2020-07-28 18:11:13', NULL),
(198, 29, 3, 'mod-color-pivots/July2020/wCd9EJrn6RDOyLQf3yYD.png', '2020-07-28 18:11:36', '2020-07-28 18:11:36', NULL),
(199, 29, 12, 'mod-color-pivots/July2020/iq2tvQtUF3TwSfZnemsW.png', '2020-07-28 18:12:01', '2020-07-28 18:12:01', NULL),
(200, 29, 42, 'mod-color-pivots/July2020/VQn0vgQQ7jRT9gZORMxE.png', '2020-07-28 18:12:29', '2020-07-28 18:12:29', NULL),
(201, 29, 23, 'mod-color-pivots/July2020/k4tWG60RZnBTcoPWGwDi.png', '2020-07-28 18:13:05', '2020-07-28 18:13:05', NULL),
(202, 29, 46, 'mod-color-pivots/July2020/3q1KZj5vB4nYxHfW44W2.png', '2020-07-28 18:13:26', '2020-07-28 18:13:26', NULL),
(203, 30, 8, 'mod-color-pivots/July2020/O68mIQgp8A0p9sr81RSw.png', '2020-07-28 18:21:00', '2020-07-28 18:21:00', NULL),
(204, 30, 4, 'mod-color-pivots/July2020/MgIWURWlzskzVCoCiRLx.png', '2020-07-28 18:21:21', '2020-07-28 18:21:21', NULL),
(205, 30, 47, 'mod-color-pivots/July2020/bog6bBMVuo8HMqQzamIh.png', '2020-07-28 18:22:00', '2020-07-28 18:22:00', NULL),
(206, 30, 48, 'mod-color-pivots/July2020/8b2pSoUjgj3U4yekHtrp.png', '2020-07-28 18:22:35', '2020-07-28 18:22:35', NULL),
(207, 30, 49, 'mod-color-pivots/July2020/9Iarl9tqOvX5uRAjjZf2.png', '2020-07-28 18:23:02', '2020-07-28 18:23:02', NULL),
(208, 30, 50, 'mod-color-pivots/July2020/mVmy9ZC5i7xy2yN5lu5i.png', '2020-07-28 18:23:28', '2020-07-28 18:23:28', NULL),
(209, 30, 3, 'mod-color-pivots/July2020/ujGutH8wJLpSphtHrIZ0.png', '2020-07-28 18:23:48', '2020-07-28 18:23:48', NULL),
(210, 30, 12, 'mod-color-pivots/July2020/RvkZVTdsYLwElMMu9zGX.png', '2020-07-28 18:24:13', '2020-07-28 18:24:13', NULL),
(211, 30, 42, 'mod-color-pivots/July2020/7eS7TsHU4wc4a2D9zS7i.png', '2020-07-28 18:24:35', '2020-07-28 18:24:35', NULL),
(212, 30, 23, 'mod-color-pivots/July2020/jbzUBToqLOVbvA6mSuHf.png', '2020-07-28 18:24:57', '2020-07-28 18:24:57', NULL),
(213, 30, 51, 'mod-color-pivots/July2020/Gg7hajIQqOIVLxxn8jBz.png', '2020-07-28 18:25:23', '2020-07-28 18:25:23', NULL),
(214, 37, 8, 'mod-color-pivots/September2020/kKEwflK8eGYef36UVRSW.png', '2020-07-28 18:29:02', '2020-09-15 05:41:09', NULL),
(215, 37, 4, 'mod-color-pivots/September2020/hvxstWGA9MUNcPOseZEd.png', '2020-07-28 18:29:22', '2020-09-15 05:33:03', NULL),
(216, 37, 12, 'mod-color-pivots/September2020/ro5YRn5DbdYmTXEEZI7b.png', '2020-07-28 18:29:49', '2020-09-15 05:35:11', NULL),
(217, 37, 23, 'mod-color-pivots/September2020/EOqE73AhzCQprlaBnspf.png', '2020-07-28 18:30:11', '2020-09-15 05:34:02', NULL),
(218, 37, 51, 'mod-color-pivots/July2020/CVlXLYnOs26OlNrsoLV3.png', '2020-07-28 18:30:37', '2020-09-15 05:38:22', '2020-09-15 05:38:22'),
(219, 33, 3, 'mod-color-pivots/August2020/2Dc40OcCXesEo5Cu0TPI.png', '2020-08-17 04:40:29', '2020-08-17 04:40:29', NULL),
(220, 35, 15, 'mod-color-pivots/August2020/ARjZOim7CgmuAJaN9dSE.png', '2020-08-17 04:43:16', '2020-08-17 04:43:16', NULL),
(221, 35, 4, 'mod-color-pivots/August2020/8UwesHec9wyiEuqVOzrC.png', '2020-08-17 04:45:29', '2020-08-17 04:45:29', NULL),
(222, 33, 26, 'mod-color-pivots/August2020/7zr4g0TZLrLo3tP1sEJz.png', '2020-08-17 04:51:09', '2020-08-17 04:51:09', NULL),
(223, 33, 23, 'mod-color-pivots/August2020/xqb2KxzVFSvupzSvlqb3.png', '2020-08-17 04:52:49', '2020-08-17 04:52:49', NULL),
(224, 33, 16, 'mod-color-pivots/August2020/xOfVUNy0K22X2JiEW4SV.png', '2020-08-17 04:55:14', '2020-08-17 04:55:14', NULL),
(225, 33, 25, 'mod-color-pivots/August2020/MkFMpX0EyfZB29IK46jG.png', '2020-08-17 05:00:00', '2020-08-17 05:00:00', NULL),
(226, 41, 23, 'mod-color-pivots/September2020/2UP07msBJZ4Gq7TCAPSH.png', '2020-09-07 05:03:40', '2020-09-07 05:03:40', NULL),
(227, 42, 8, 'mod-color-pivots/November2020/ag2qkhNROgEUBAdlD2PR.png', '2020-11-05 09:24:43', '2020-11-05 09:24:43', NULL),
(228, 42, 4, 'mod-color-pivots/November2020/pxTKdlsCsHQXZkflzaNm.png', '2020-11-05 09:25:10', '2020-11-05 09:25:10', NULL),
(229, 42, 43, 'mod-color-pivots/November2020/mPZGbea28typSODBHxT8.png', '2020-11-05 09:25:33', '2020-11-05 09:25:33', NULL),
(230, 42, 44, 'mod-color-pivots/November2020/SSm3N7TvyhiRoFPemkAE.png', '2020-11-05 09:26:03', '2020-11-05 09:26:03', NULL),
(231, 42, 45, 'mod-color-pivots/November2020/feGOoHf25ZX2yqaD8OKh.png', '2020-11-05 09:26:31', '2020-11-05 09:26:31', NULL),
(232, 42, 3, 'mod-color-pivots/November2020/EEP9UdIkcpCUEhZN9g7n.png', '2020-11-05 09:29:33', '2020-11-05 09:29:33', NULL),
(233, 42, 12, 'mod-color-pivots/November2020/GrtvKGz9VtMBrZz4QfyW.png', '2020-11-05 09:29:58', '2020-11-05 09:29:58', NULL),
(234, 42, 42, 'mod-color-pivots/November2020/dwzMCAlXckeOz9j3qSca.png', '2020-11-05 09:30:30', '2020-11-05 09:30:30', NULL),
(235, 42, 23, 'mod-color-pivots/November2020/yKG5SeBlan3hBIDSVXR9.png', '2020-11-05 09:30:59', '2020-11-05 09:30:59', NULL),
(236, 42, 46, 'mod-color-pivots/November2020/3uFSsfLAhohJDu3wEDK6.png', '2020-11-05 09:31:26', '2020-11-05 09:31:26', NULL),
(237, 43, 8, 'mod-color-pivots/November2020/aAUeiXEwYtPTpy2u918m.png', '2020-11-05 09:38:04', '2020-11-05 09:38:04', NULL),
(238, 43, 4, 'mod-color-pivots/November2020/arApwynWOKbtySiuoul6.png', '2020-11-05 09:38:33', '2020-11-05 09:38:33', NULL),
(239, 43, 43, 'mod-color-pivots/November2020/ckhC8mbavuJe2Fot8iwM.png', '2020-11-05 09:38:59', '2020-11-05 09:38:59', NULL),
(240, 43, 44, 'mod-color-pivots/November2020/pLHAqKEAHjjQzeJDnvJA.png', '2020-11-05 09:39:40', '2020-11-05 09:39:40', NULL),
(241, 43, 45, 'mod-color-pivots/November2020/r5Bg30HvafOo2BXNREmW.png', '2020-11-05 09:40:17', '2020-11-05 09:40:17', NULL),
(242, 43, 3, 'mod-color-pivots/November2020/LsU47rI5c2qZjMlgrfV5.png', '2020-11-05 09:40:41', '2020-11-05 09:40:41', NULL),
(243, 43, 42, 'mod-color-pivots/November2020/82daw0lsFIQyfoURXZxa.png', '2020-11-05 09:41:24', '2020-11-05 09:41:24', NULL),
(244, 43, 23, 'mod-color-pivots/November2020/Tw5uXUuiU0fa9NE8Be97.png', '2020-11-05 09:41:58', '2020-11-05 09:41:58', NULL),
(245, 43, 46, 'mod-color-pivots/November2020/ohpi53Rxbmkjhk0yUJR1.png', '2020-11-05 09:42:26', '2020-11-05 09:42:26', NULL),
(246, 43, 12, 'mod-color-pivots/November2020/AmsWJjDZ8etJeYSHO2Wt.png', '2020-11-05 09:42:52', '2020-11-05 09:42:52', NULL),
(247, 6, 52, 'mod-color-pivots/November2020/Fda9hOElaLDs9PG8RRMd.png', '2020-11-05 11:10:18', '2020-11-05 11:10:18', NULL),
(248, 8, 53, 'mod-color-pivots/November2020/6LvrhJHKwVvLjBYSkD4d.png', '2020-11-06 08:59:38', '2020-11-06 08:59:38', NULL),
(249, 8, 54, 'mod-color-pivots/November2020/6QqTYSfX529nleNqQdGW.png', '2020-11-06 09:07:03', '2020-11-06 09:07:03', NULL),
(250, 8, 55, 'mod-color-pivots/November2020/WqBuHmdp5vb8rRrTslF8.png', '2020-11-06 09:15:34', '2020-11-06 09:15:34', NULL),
(251, 8, 56, 'mod-color-pivots/November2020/JfcpsN9IwH8BCwKpoPFk.png', '2020-11-06 09:22:17', '2020-11-06 09:22:17', NULL),
(252, 8, 57, 'mod-color-pivots/November2020/MkPXHBZ6P0zz7IHPRt1p.png', '2020-11-06 09:26:20', '2020-11-06 09:26:20', NULL),
(253, 3, 8, 'mod-color-pivots/November2020/02ldPoxFzMb14DPNKdJs.png', '2020-11-11 17:19:18', '2020-11-11 17:19:18', NULL),
(254, 3, 4, 'mod-color-pivots/November2020/fB6fJKG6cRXL2JhDUZNb.png', '2020-11-11 17:20:03', '2020-11-11 17:20:03', NULL),
(255, 3, 10, 'mod-color-pivots/November2020/JhMWJjkaXJEMvwqvk4Nu.png', '2020-11-11 17:20:25', '2020-11-11 17:20:25', NULL),
(256, 3, 15, 'mod-color-pivots/November2020/dlX8bq6naD4TRv1dhjoM.png', '2020-11-11 17:20:47', '2020-11-11 17:20:47', NULL),
(257, 3, 22, 'mod-color-pivots/November2020/homZr7LGFqCRZ9zmBr2V.png', '2020-11-11 17:21:40', '2020-11-11 17:21:40', NULL),
(258, 3, 3, 'mod-color-pivots/November2020/x6T05dBnYC0koitnhO5Y.png', '2020-11-11 17:22:03', '2020-11-11 17:22:03', NULL),
(259, 3, 19, 'mod-color-pivots/November2020/hbhqsANdDS5yoVAPvqmS.png', '2020-11-11 17:22:25', '2020-11-11 17:22:25', NULL),
(260, 3, 6, 'mod-color-pivots/November2020/RL0RR5NaM6zQufo41CIc.png', '2020-11-11 17:22:48', '2020-11-11 17:22:48', NULL),
(261, 3, 58, 'mod-color-pivots/November2020/xZEsd8kNwasbiYIpFybg.png', '2020-11-11 17:33:10', '2020-11-11 17:33:10', NULL),
(262, 2, 8, 'mod-color-pivots/November2020/03LEw5y9NVUC4BFgT8Vu.png', '2020-11-11 17:37:34', '2020-11-11 17:37:34', NULL),
(263, 2, 4, 'mod-color-pivots/November2020/q3aSbLMhaM50GU2vuKPK.png', '2020-11-11 17:38:08', '2020-11-11 17:38:08', NULL),
(264, 2, 10, 'mod-color-pivots/November2020/u3DyhH3NL5OtADfuQYts.png', '2020-11-11 17:38:27', '2020-11-11 17:38:27', NULL),
(265, 2, 15, 'mod-color-pivots/November2020/4sKjuPYQt8DiR8NBG9By.png', '2020-11-11 17:38:48', '2020-11-11 17:38:48', NULL),
(266, 2, 58, 'mod-color-pivots/November2020/Cs6NLHWURVSaGMo61iaL.png', '2020-11-11 17:39:05', '2020-11-11 17:39:05', NULL),
(267, 2, 3, 'mod-color-pivots/November2020/kXj1fevTwY8INP9ddY89.png', '2020-11-11 17:39:23', '2020-11-11 17:39:23', NULL),
(268, 2, 19, 'mod-color-pivots/November2020/BxDwwi7ofWUXKeG5arqX.png', '2020-11-11 17:39:41', '2020-11-11 17:39:41', NULL),
(269, 2, 6, 'mod-color-pivots/November2020/SXD84mxuTGopnA5TT2q7.png', '2020-11-11 17:40:00', '2020-11-11 17:40:00', NULL),
(270, 4, 59, 'mod-color-pivots/November2020/SxARHBqG08XdjB3bicNR.png', '2020-11-11 17:57:50', '2020-11-11 17:57:50', NULL),
(271, 4, 60, 'mod-color-pivots/November2020/3FPXgEgMYrtIB9tThdQ0.png', '2020-11-11 18:01:59', '2020-11-11 18:01:59', NULL),
(272, 4, 61, 'mod-color-pivots/November2020/tcCbGJsODqZ6lxOkz6P8.png', '2020-11-11 18:07:23', '2020-11-11 18:07:23', NULL),
(273, 4, 62, 'mod-color-pivots/November2020/LZcoeRyavSUIWtmx7u0U.png', '2020-11-11 18:10:23', '2020-11-11 18:10:23', NULL),
(274, 4, 63, 'mod-color-pivots/November2020/1gtsxOSigg88ulCazZ7G.png', '2020-11-11 18:12:27', '2020-11-11 18:12:27', NULL),
(275, 1, 64, 'mod-color-pivots/November2020/UE2I6oHhwb64N5bEJy69.png', '2020-11-11 18:18:17', '2020-11-11 18:18:17', NULL),
(276, 48, 3, 'mod-color-pivots/November2020/eRowQDAKUNfPYLLqky6l.png', '2020-11-30 09:00:57', '2020-12-02 17:51:14', '2020-12-02 17:51:14');

-- --------------------------------------------------------

--
-- Структура таблицы `mod_eng_gear_pivots`
--

CREATE TABLE IF NOT EXISTS `mod_eng_gear_pivots` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `modification_id` int(11) DEFAULT NULL,
  `engine_id` int(11) DEFAULT NULL,
  `gearbox_id` int(11) DEFAULT NULL,
  `drive_type_id` int(11) DEFAULT NULL,
  `sfx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_color_type_1` float DEFAULT NULL,
  `price_color_type_2` float DEFAULT NULL,
  `price_color_type_3` float DEFAULT NULL,
  `price_color_type_4` float DEFAULT NULL,
  `prod_price_color_type_1` float DEFAULT NULL,
  `prod_price_color_type_2` float DEFAULT NULL,
  `prod_price_color_type_3` float DEFAULT NULL,
  `prod_price_color_type_4` float DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `horspower` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fuel_consumption` double DEFAULT NULL,
  `fuel_consumption_city` double DEFAULT NULL,
  `max_speed` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `mod_eng_gear_pivots`
--

INSERT INTO `mod_eng_gear_pivots` (`id`, `modification_id`, `engine_id`, `gearbox_id`, `drive_type_id`, `sfx`, `price_color_type_1`, `price_color_type_2`, `price_color_type_3`, `price_color_type_4`, `prod_price_color_type_1`, `prod_price_color_type_2`, `prod_price_color_type_3`, `prod_price_color_type_4`, `code`, `created_at`, `updated_at`, `deleted_at`, `horspower`, `fuel_consumption`, `fuel_consumption_city`, `max_speed`) VALUES
(3, 3, 4, 4, 4, 'NC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NSP131L-CHXNBW', NULL, '2020-10-13 08:24:43', NULL, '82/6000', 4.6, 5.3, 175),
(4, 11, 9, 6, 4, 'CD', 764090, NULL, 774465, 779652, 738475, NULL, 748502, 753516, 'ZWE211L-DEXNBW', NULL, '2020-12-10 12:21:25', NULL, '122', 4.2, 3.8, 180),
(5, 11, 2, 5, 4, 'BY', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ZRE210L-DEFNPW', NULL, '2020-10-13 10:09:23', NULL, '132', 5.1, 8, 190),
(6, 11, 2, 4, 4, 'CA', 687541, NULL, 697916, 703103, 664492, NULL, 674519, 679532, 'ZRE210L-DEXNPW', NULL, '2020-12-10 12:21:25', NULL, '132', 5.1, 8, 190),
(7, 9, 2, 5, 4, '0C', 533601, NULL, 543976, 549163, 485000, NULL, 494425, 499138, 'ZRE210L-DEFDPW', NULL, '2020-12-10 12:21:25', NULL, '132', 5.2, 8.4, 200),
(8, 9, 2, 4, 4, '0J', 579306, NULL, 589681, 594869, 559886, NULL, 569913, 574926, 'ZRE210L-DEXDPW', NULL, '2020-12-10 12:21:25', NULL, '132', 5.1, 8, 190),
(9, 10, 2, 5, 4, 'BZ', 573418, NULL, 583793, 588980, 554195, NULL, 564222, 569236, 'ZRE210L-DEFNPW', NULL, '2020-12-10 12:21:25', NULL, '132', 5.2, 8.4, 200),
(10, 10, 2, 4, 4, 'CB', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ZRE210L-DEXNPW', NULL, '2020-12-02 06:24:44', NULL, '132', 5.1, 8, 190),
(11, 12, 2, 8, 4, 'CC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ZRE210L-DEXNPW', NULL, '2020-10-05 07:34:50', NULL, '132', 5.1, 8, 190),
(12, 12, 9, 6, 4, 'CE', 824096, NULL, 834470, 839658, 796469, NULL, 806496, 811510, 'ZWE211L-DEXNBW', NULL, '2020-12-10 12:21:25', NULL, '122', 4.2, 3.8, 180),
(13, 12, 21, 6, 4, 'IB', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ZWE211L-DEXNBW', NULL, '2020-10-05 07:34:50', NULL, '122', 4.2, 3.8, 180),
(14, 6, 8, 4, 4, 'DJ', NULL, NULL, 809795, 815964, NULL, NULL, NULL, NULL, 'NGX10L-AHXKXW', '2020-07-28 08:02:35', '2020-12-10 12:21:25', NULL, '116', 5.7, 8, 185),
(15, 7, 8, 4, 4, 'KE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NGX10L-AHXGXW', '2020-07-28 08:04:19', '2020-10-05 07:34:50', NULL, '116', 5.7, 8, 185),
(16, 8, 8, 4, 4, 'UL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NGX10L-AHXEXW', '2020-07-28 08:06:57', '2020-10-16 05:39:11', '2020-10-16 05:39:11', '116', 5.7, 8, 185),
(17, 6, 9, 6, 4, '1T', NULL, NULL, 890831, 897000, NULL, NULL, 860967, 866929, 'ZYX11L-AHXKBW', '2020-07-28 08:08:05', '2020-12-10 12:21:25', NULL, '122', 3.8, 4.5, 170),
(18, 7, 9, 6, 4, 'E8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ZYX11L-AHXGBW', '2020-07-28 08:08:54', '2020-10-05 07:34:50', NULL, '122', 4.5, 3.8, 170),
(19, 8, 9, 6, 4, '4K', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ZYX11L-AHXEBW', '2020-07-28 08:09:49', '2020-10-16 05:38:47', '2020-10-16 05:38:47', '122', 4.5, 3.8, 170),
(20, 6, 10, 6, 4, '1F', NULL, NULL, 952799, 958968, NULL, NULL, 920858, 926820, 'MAXH10L-AHXKBW', '2020-07-28 08:11:00', '2020-12-10 12:21:25', NULL, '122', 5.7, 8, 185),
(21, 7, 10, 6, 4, 'D3', NULL, NULL, NULL, NULL, NULL, NULL, 961508, 967470, 'MAXH10L-AHXGBW', '2020-07-28 09:10:45', '2020-12-10 12:21:25', NULL, '184', 4.5, 4, 180),
(22, 8, 10, 6, 4, '4J', NULL, NULL, 1051220, 1057390, NULL, NULL, 1015980, 1021940, 'MAXH10L-AHXEBW', '2020-07-28 09:11:25', '2020-12-10 12:21:25', NULL, '184', 4.5, 4, 180),
(23, 13, 6, 8, 4, '2B', NULL, NULL, 837274, 845686, NULL, NULL, 809206, 817336, 'ASV70L-AETNKW', '2020-08-07 12:10:55', '2020-12-10 12:21:25', NULL, '181', 6.4, 11.5, 210),
(24, 14, 6, 8, 4, '3B', NULL, NULL, 915506, 923918, NULL, NULL, 884815, 892945, 'ASV70L-AETNKW', '2020-08-07 12:27:10', '2020-12-10 12:21:25', NULL, '181', 6.4, 11.5, 210),
(25, 15, 6, 8, 4, '4B', NULL, NULL, 978596, 987008, NULL, NULL, 945790, 953920, 'ASV70L-AETNKW', '2020-08-07 12:28:14', '2020-12-10 12:21:25', NULL, '181', 6.4, 11.5, 210),
(26, 16, 6, 8, 4, '5B', NULL, NULL, 1121320, 1129730, NULL, NULL, 1083730, 1091860, 'ASV70L-AETNKW', '2020-08-07 12:29:58', '2020-12-10 12:21:25', NULL, '181', 6.4, 11.5, 210),
(27, 15, 7, 6, 4, 'U4', NULL, NULL, 1037760, 1046170, NULL, NULL, 1002970, 1011100, 'AXVH71L-AEXDBW', '2020-08-07 12:34:08', '2020-12-10 12:21:25', NULL, '218', 4.4, 5.2, 180),
(28, 16, 7, 6, 4, 'U6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AXVH71L-AEXDBW', '2020-08-07 12:35:10', '2020-10-16 06:06:55', '2020-10-16 06:06:55', '218', 4.4, 5.2, 180),
(29, 18, 11, 5, 4, 'BI', NULL, NULL, NULL, NULL, 675000, 679423, 690349, 698154, 'MXAA52L-ANFXBW', '2020-08-07 12:38:09', '2020-12-10 12:21:25', NULL, '173', 5.7, 8.6, 190),
(30, 19, 7, 6, 4, 'L7', NULL, NULL, NULL, NULL, NULL, NULL, 956359, NULL, 'AXAH52L-ANXMBW', '2020-08-07 13:13:35', '2020-12-10 12:21:25', NULL, '218', 4.7, 4.8, 180),
(31, 20, 7, 6, 4, 'I3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AXAH52L-ANXMBW', '2020-08-07 13:14:34', '2020-09-25 10:05:03', NULL, '218', 4.7, 4.8, 180),
(32, 21, 7, 6, 4, 'T6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1088610, 'AXAH52L-ANXMBW', '2020-08-07 13:15:34', '2020-12-10 12:21:25', NULL, '218', 4.7, 4.8, 180),
(33, 19, 7, 6, 5, 'L7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AXAH54L-ANXMBW', '2020-08-07 13:18:17', '2020-11-06 12:24:03', NULL, '222', 4.8, 5, 180),
(34, 20, 7, 6, 5, 'I3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AXAH54L-ANXMBW', '2020-08-07 13:19:59', '2020-12-02 06:24:44', NULL, '222', 4.8, 5, 180),
(35, 21, 7, 6, 5, 'T6', NULL, NULL, NULL, NULL, NULL, NULL, 1169360, NULL, 'AXAH54L-ANXMBW', '2020-08-07 13:22:02', '2020-12-10 12:21:25', NULL, '222', 4.8, 5, 180),
(36, 22, 7, 6, 5, '5S', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1232780, 'AXAH54L-ANXGBW', '2020-08-07 13:48:17', '2020-12-10 12:21:25', NULL, '222', 4.8, 5, 180),
(37, 24, 12, 11, 3, 'AA / CC', NULL, NULL, 1432840, 1441260, NULL, NULL, 1384810, 1392940, 'GSU75L-ARZNHX', '2020-08-07 13:51:01', '2020-12-10 12:21:25', NULL, '249', 7.2, 13.3, 180),
(38, 39, 12, 11, 3, '00 / 02', NULL, NULL, 1737080, 1745490, NULL, NULL, 1678840, 1686980, 'GSU75L-ARZGHX', '2020-08-07 13:52:01', '2020-12-10 12:21:25', NULL, '249', 7.5, 13.6, 180),
(39, 33, 16, 5, 3, 'GZ', 981961, NULL, 998504, 1006920, NULL, NULL, 965031, NULL, 'GUN125L-DTFSXW', '2020-08-07 13:55:22', '2020-12-10 12:21:25', NULL, '150', 6.6, 8.8, 170),
(40, 18, 11, 12, 4, 'AJ', NULL, NULL, NULL, NULL, 755277, 759884, 771266, 779396, 'MXAA52L-ANXXBW', '2020-08-10 07:10:17', '2020-12-10 12:21:25', NULL, '173', 5.7, 7.8, 190),
(41, 19, 11, 12, 4, 'FM', NULL, NULL, NULL, NULL, NULL, 845791, NULL, 865303, 'MXAA52L-ANXMBW', '2020-08-10 08:38:18', '2020-12-10 12:21:25', NULL, '173', 5.7, 7.8, 190),
(42, 19, 6, 12, 3, 'FN', NULL, NULL, NULL, NULL, 930072, 934679, 946061, 954191, 'MXAA54L-ANXMBW', '2020-08-10 08:39:33', '2020-12-10 12:21:25', NULL, '222', 4.8, 5, 180),
(43, 20, 11, 12, 3, 'CE', NULL, NULL, NULL, NULL, NULL, NULL, 1004330, 1012460, 'MXAA54L-ANXMBW', '2020-08-10 08:40:28', '2020-12-10 12:21:25', NULL, '173', 5.8, 8.2, 190),
(44, 22, 11, 12, 3, 'LG', NULL, NULL, NULL, NULL, NULL, 1114080, 1125460, 1133590, 'MXAA54L-ANXGBW', '2020-08-10 08:41:49', '2020-12-10 12:21:25', NULL, '173', 5.8, 8.2, 190),
(45, 26, 14, 7, 3, 'Z4', 1331060, NULL, 1347600, 1356010, 1286440, NULL, 1302430, 1310560, 'GDJ150L-GKTEYX', '2020-08-10 09:00:25', '2020-12-10 12:21:25', NULL, '200', 6.9, 9.6, 175),
(46, 27, 14, 7, 3, 'Z5', 1481070, NULL, 1497620, 1506030, 1431420, NULL, 1447410, 1455540, 'GDJ150L-GKTEYX', '2020-08-10 09:01:54', '2020-12-10 12:21:25', NULL, '200', 6.9, 9.6, 175),
(47, 27, 13, 7, 3, '4B/4C', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'GRJ150L-GKTEKX', '2020-08-10 09:03:21', '2020-10-16 08:39:02', '2020-10-16 08:39:02', '282', 9, 15.5, 175),
(48, 28, 13, 7, 3, '7C/8B', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'GRJ150L-GKTEKX', '2020-08-10 09:04:14', '2020-10-05 07:34:50', NULL, '282', 9, 15.5, 175),
(49, 29, 13, 7, 3, '1D/2D', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'GRJ150L-GKTEKX', '2020-08-10 09:05:11', '2020-10-05 07:34:50', NULL, '282', 9, 15.5, 175),
(50, 30, 17, 7, 3, 'B4', 1873070, NULL, 1917940, 1933360, 1810280, NULL, 1853640, 1868540, 'VDJ200L-GMTEZW', '2020-08-10 09:12:03', '2020-12-10 12:21:25', NULL, '249', 9, 11.5, 210),
(51, 37, 17, 7, 3, '7D/7E', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'VDJ200L-GMTEZW', '2020-08-10 09:12:55', '2020-08-14 10:18:23', NULL, '249', 9, 11.5, 210),
(52, 30, 15, 7, 3, 'B2', 1819800, NULL, 1864660, 1880080, 1758790, NULL, 1802150, 1817060, 'URJ202L-GMTEKW', '2020-08-10 09:17:20', '2020-12-10 12:21:25', NULL, '249', 10.9, 18.5, 195),
(53, 37, 15, 7, 3, 'QH / NP', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'URJ202L-GNTVKW', '2020-08-10 09:18:11', '2020-11-06 12:24:03', NULL, '309', 10.9, 18.5, 195),
(54, 40, 18, 2, 3, '64', 924479, NULL, 941022, 949434, NULL, NULL, NULL, NULL, 'TRJ150L-GKMEKX', '2020-08-11 09:02:31', '2020-12-10 12:21:25', NULL, NULL, NULL, NULL, NULL),
(55, 40, 14, 7, 3, 'X1', 1128890, NULL, 1145430, 1153850, 1091050, NULL, 1107040, 1115160, 'GDJ150L-GKTEYX', '2020-08-11 09:06:37', '2020-12-10 12:21:25', NULL, NULL, NULL, NULL, NULL),
(56, 34, 16, 7, 3, 'BY', 1165900, NULL, 1182450, 1190860, 1126820, NULL, 1142810, 1150940, 'GUN125L-DTTSXW', '2020-08-17 04:27:46', '2020-12-10 12:21:25', NULL, '150', 7, 9.5, 170),
(57, 38, 14, 7, 3, 'EU', 1376760, NULL, 1393310, 1401720, 1330610, NULL, 1346600, 1354730, 'GUN126L-DTTHXW', '2020-08-17 04:30:12', '2020-12-10 12:21:25', NULL, '204', 7, 9.6, 175),
(58, 35, 14, 7, 3, 'QK', 1409850, NULL, 1426390, 1434810, 1362590, NULL, 1378580, 1386710, 'GUN126L-DTTHXW', '2020-08-17 04:33:16', '2020-12-10 12:21:25', NULL, '204', 7, 9.6, 175),
(59, 41, 7, 6, 4, 'W3', NULL, NULL, 1123000, 1131410, NULL, NULL, 1085360, NULL, 'AXAH52L-ANXMBW', '2020-09-07 08:16:47', '2020-12-10 12:21:25', NULL, '178', 4.7, 4.8, 180),
(60, 41, 7, 6, 5, 'W3', NULL, NULL, 1214970, NULL, NULL, NULL, 1174240, NULL, 'AXAH54L-ANXMBW', '2020-09-07 08:17:35', '2020-12-10 12:21:25', NULL, '178', 5, 4.8, 180),
(61, 16, 12, 13, 4, '5C', NULL, NULL, 1217760, 1226170, NULL, NULL, 1177400, 1185530, 'GSV70L-AEZGBW', '2020-10-16 06:03:58', '2020-12-10 12:21:25', NULL, '302', 12.5, 6.4, 220),
(62, 42, 13, 7, 3, '2C', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'GRJ150L-GKTEKX', '2020-10-16 07:25:43', '2020-10-16 08:38:29', '2020-10-16 08:38:29', '282', 9, 15.5, 175),
(63, 43, 14, 7, 3, '7C / 8B', 1709040, NULL, 1725580, 1733990, NULL, NULL, NULL, NULL, 'GDJ150L-GKTEYX', '2020-10-16 07:45:26', '2020-12-10 12:21:25', NULL, '200', 6.9, 9.6, 175),
(64, 43, 13, 7, 3, '7C / 8B', 1524530, NULL, 1541080, 1549490, 1473430, NULL, NULL, 1497550, 'GRJ150L-GKTEKX', '2020-10-16 08:24:51', '2020-12-10 12:21:25', NULL, '282', 9, 15.5, 175),
(65, 42, 13, 7, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-19 10:13:51', '2020-10-19 10:13:51', NULL, '282', 9, 15.5, 175),
(66, 3, 23, 14, 4, 'GI', 646602, 649687, 654173, 659361, 624926, NULL, 632243, 637256, 'MXPH11L-BHXNBW', '2020-11-23 11:03:21', '2020-12-10 12:21:25', NULL, '116', 3.5, 2.7, 175),
(67, 2, 23, 14, 4, 'T1', 686419, 689504, 693990, 699177, NULL, NULL, NULL, 675738, 'MXPH11L-BHXGBW', '2020-11-23 11:09:27', '2020-12-10 12:21:25', NULL, '116', 2.7, 3.5, 175),
(68, 4, 23, 14, 4, 'VY', NULL, NULL, 702402, 707589, NULL, NULL, NULL, 683868, 'MXPH11L-BHXSBW', '2020-11-23 11:11:50', '2020-12-10 12:21:25', NULL, '116', 2.7, 3.5, 116),
(69, 1, 23, 14, 4, 'VZ', NULL, NULL, NULL, 730021, NULL, NULL, NULL, NULL, 'MXPH11L-BHXSBW', '2020-11-23 11:13:13', '2020-12-10 12:21:25', NULL, '116', 2.7, 3.5, 175);

-- --------------------------------------------------------

--
-- Структура таблицы `mod_interior_pivots`
--

CREATE TABLE IF NOT EXISTS `mod_interior_pivots` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `modification_id` int(11) DEFAULT NULL,
  `interior_id` int(11) DEFAULT NULL,
  `preview` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `mod_interior_pivots`
--

INSERT INTO `mod_interior_pivots` (`id`, `modification_id`, `interior_id`, `preview`, `image`, `views`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 3, 5, NULL, NULL, NULL, '2020-05-11 12:08:45', '2020-11-11 18:33:23', NULL),
(4, 9, 4, 'mod-interior-pivots/May2020/5lBrhnTmREfr5aDTkaIu.jpg', '[\"mod-interior-pivots\\/May2020\\/gYQMXAtoQSrPrxyF0BLj.jpg\",\"mod-interior-pivots\\/May2020\\/bBs54Pb7Wel7JCZlHyvP.jpg\",\"mod-interior-pivots\\/May2020\\/VAFNHA2GRDbAbRmJdjJy.jpg\"]', NULL, '2020-05-31 13:45:40', '2020-05-31 13:45:40', NULL),
(5, 9, 3, 'mod-interior-pivots/May2020/mYxmpGVnjVVhINeHMc9e.jpg', '[\"mod-interior-pivots\\/May2020\\/0kK6umpikYyX2JeUZ91c.jpg\",\"mod-interior-pivots\\/May2020\\/Sxqf7C6IHEMbQ191FgPb.jpg\",\"mod-interior-pivots\\/May2020\\/bD4c3YmNKlasY0xoueLD.jpg\"]', NULL, '2020-05-31 13:46:16', '2020-05-31 13:46:16', NULL),
(6, 10, 6, 'mod-interior-pivots/May2020/RmeNS4VkgOoirtwwr6rg.jpg', '[\"mod-interior-pivots\\/May2020\\/cesh7GMqTLCnRCnQ4H2X.jpg\",\"mod-interior-pivots\\/May2020\\/BTNODMIbhwBqB1Gd2NbA.jpg\",\"mod-interior-pivots\\/May2020\\/dLPsV1j7BZ59vJsMVikt.jpg\"]', NULL, '2020-05-31 13:48:33', '2020-05-31 13:48:33', NULL),
(7, 10, 5, 'mod-interior-pivots/May2020/RRzMKAW8kk2I1guHDNsq.jpg', '[\"mod-interior-pivots\\/May2020\\/wbv7mho1ajqMwBvNWKLa.jpg\",\"mod-interior-pivots\\/May2020\\/XH5s41ZPW1BtlUW3Pbgu.jpg\",\"mod-interior-pivots\\/May2020\\/qYyIdAO6TxoYavv69W3E.jpg\"]', NULL, '2020-05-31 13:49:03', '2020-05-31 13:50:56', NULL),
(8, 11, 6, 'mod-interior-pivots/May2020/eFhZiZjqucieKutjHQkc.jpg', '[\"mod-interior-pivots\\/May2020\\/1UqTQWeqSDaBWgO5By6h.jpg\",\"mod-interior-pivots\\/May2020\\/7YyZ22AOGeF2NPAGzDic.jpg\",\"mod-interior-pivots\\/May2020\\/MB3LtMcsGUk4xG8DQAX2.jpg\"]', NULL, '2020-05-31 13:51:28', '2020-05-31 13:51:28', NULL),
(9, 11, 5, 'mod-interior-pivots/May2020/hnbbhmA6LziYb88KyF4W.jpg', '[\"mod-interior-pivots\\/May2020\\/XsvSPpInJ4kswvG6YX2I.jpg\",\"mod-interior-pivots\\/May2020\\/ki6EYFpky8uaVuv9H1ed.jpg\",\"mod-interior-pivots\\/May2020\\/4YMMUsVKZFjsXdislNfE.jpg\"]', NULL, '2020-05-31 13:51:53', '2020-05-31 13:51:53', NULL),
(10, 12, 6, 'mod-interior-pivots/May2020/TUu4z2EQZAf96Cop2ndn.jpg', '[\"mod-interior-pivots\\/May2020\\/jC1PxxkTfZ7fpE9g8bPV.jpg\",\"mod-interior-pivots\\/May2020\\/lfyAZxKN0WZ0c1xLAtJD.jpg\",\"mod-interior-pivots\\/May2020\\/f8OTcAJpMLcERR9EwtdI.jpg\"]', NULL, '2020-05-31 13:55:41', '2020-05-31 13:55:41', NULL),
(11, 12, 5, 'mod-interior-pivots/May2020/EyGZy04yLWbTnOaYTSFq.jpg', '[\"mod-interior-pivots\\/May2020\\/toYL89p9w3FB7QXNv4f0.jpg\",\"mod-interior-pivots\\/May2020\\/61TMClnZ9CCaU5EfRJ0Z.jpg\",\"mod-interior-pivots\\/May2020\\/6Sq5AuGlvVtaBb1BM1YP.jpg\"]', NULL, '2020-05-31 13:56:09', '2020-05-31 13:56:09', NULL),
(12, 13, 4, 'mod-interior-pivots/July2020/dOTkBB2P4bZQ4Wu5SRA9.jpg', '[\"mod-interior-pivots\\/July2020\\/U6xREq71AlOWUlqK3Xg9.jpg\",\"mod-interior-pivots\\/July2020\\/4y7jhiNZs9W13DBady8A.jpg\",\"mod-interior-pivots\\/July2020\\/s62FfQn37X4Ex2f7DziY.jpg\"]', NULL, '2020-07-29 06:55:09', '2020-07-29 06:55:09', NULL),
(13, 14, 7, 'mod-interior-pivots/July2020/tAHUvwzSVLw01bommlxp.jpg', '[\"mod-interior-pivots\\/July2020\\/IXzYSGA5zKXa7G9zpt19.jpg\",\"mod-interior-pivots\\/July2020\\/YFophkX8h05gPyeWUap4.jpg\",\"mod-interior-pivots\\/July2020\\/d02IHNJlfeH0uz7XJQc6.jpg\"]', NULL, '2020-07-29 06:59:53', '2020-07-29 06:59:53', NULL),
(14, 14, 8, 'mod-interior-pivots/July2020/ibabh5Ev9XW40FEu0U2S.jpg', '[\"mod-interior-pivots\\/July2020\\/rtBHPIJ0CdaPxPhW7YMz.jpg\",\"mod-interior-pivots\\/July2020\\/ouw6uDVpJ86wYGVnjWa0.jpg\",\"mod-interior-pivots\\/July2020\\/UAcFJ1brkudaNXBEF7Di.jpg\"]', NULL, '2020-07-29 07:00:57', '2020-07-29 07:00:57', NULL),
(15, 15, 7, 'mod-interior-pivots/July2020/k9TT37Rx0gV8bxgmPCqy.jpg', '[\"mod-interior-pivots\\/July2020\\/HgDolOM9ntek8oKvMy9o.jpg\",\"mod-interior-pivots\\/July2020\\/e4oA3xLDbVbGzV9bdai9.jpg\",\"mod-interior-pivots\\/July2020\\/DWd94SEy6z57XS9VkUUc.jpg\"]', NULL, '2020-07-29 07:02:36', '2020-07-29 07:02:36', NULL),
(16, 15, 8, 'mod-interior-pivots/July2020/ocA2EJQ8CnrGC32s7yWI.jpg', '[\"mod-interior-pivots\\/July2020\\/uGM1OAAM2BvMIOllZclR.jpg\",\"mod-interior-pivots\\/July2020\\/VJ3ZLgILdrSqyH1ne4nO.jpg\",\"mod-interior-pivots\\/July2020\\/zALVyPGWiaixm7B76gF2.jpg\"]', NULL, '2020-07-29 07:03:28', '2020-07-29 07:03:28', NULL),
(17, 36, 7, 'mod-interior-pivots/July2020/5pOC8x5wTT9Q1XFJ4f2v.jpg', '[\"mod-interior-pivots\\/July2020\\/xpn5CHJwmU9nE0kXRSNC.jpg\",\"mod-interior-pivots\\/July2020\\/qQs5RKckhFjdwQTKXPVj.jpg\",\"mod-interior-pivots\\/July2020\\/Amwza4rCFP1l4pvmqxbJ.jpg\"]', NULL, '2020-07-29 07:04:53', '2020-07-29 07:04:53', NULL),
(18, 36, 8, 'mod-interior-pivots/July2020/nLqeU17FTL6WmtzTIpDR.jpg', '[\"mod-interior-pivots\\/July2020\\/Pip3KVMRpscLz5CgQGaT.jpg\",\"mod-interior-pivots\\/July2020\\/To0ZZeyZRNR5TqC0iRoG.jpg\",\"mod-interior-pivots\\/July2020\\/7GXZEz1e2sfLYu3NXI4r.jpg\"]', NULL, '2020-07-29 07:05:46', '2020-07-29 07:05:46', NULL),
(19, 16, 7, 'mod-interior-pivots/July2020/paqQ4aZegWcQQBT488Rq.jpg', '[\"mod-interior-pivots\\/July2020\\/YAMsYqeUfypN68tRNPtR.jpg\",\"mod-interior-pivots\\/July2020\\/3jp3Q0nUe62D3x4AENQx.jpg\",\"mod-interior-pivots\\/July2020\\/fUwNmh64S8jzTbfCBzCM.jpg\"]', NULL, '2020-07-29 07:08:00', '2020-07-29 07:08:00', NULL),
(20, 16, 8, 'mod-interior-pivots/July2020/mCQ4O0hqEwnvuxs5dF4P.jpg', '[\"mod-interior-pivots\\/July2020\\/CjS4wSqIDCovA7YwZQ3F.jpg\",\"mod-interior-pivots\\/July2020\\/G1qfrsgvkzJMGT3P76vY.jpg\",\"mod-interior-pivots\\/July2020\\/k0jmhf6Wr5eqfV0wvlYV.jpg\"]', NULL, '2020-07-29 07:08:48', '2020-07-29 07:08:48', NULL),
(21, 17, 7, 'mod-interior-pivots/July2020/S3BKt0oSzbHFdU2QUkqs.jpg', '[\"mod-interior-pivots\\/July2020\\/aCx5dLeNAPfDxqvY4KXg.jpg\",\"mod-interior-pivots\\/July2020\\/UnbxGQL79Svvuksp5C2h.jpg\",\"mod-interior-pivots\\/July2020\\/3367Yg29hoQ5YLvZXp2q.jpg\"]', NULL, '2020-07-29 07:11:33', '2020-07-29 07:11:33', NULL),
(22, 17, 8, 'mod-interior-pivots/July2020/QowCLgaioEqyif46no09.jpg', '[\"mod-interior-pivots\\/July2020\\/6UlhbFhtHPm9toeXtLlV.jpg\",\"mod-interior-pivots\\/July2020\\/PWEXv02aRUXfr2zgsMDq.jpg\",\"mod-interior-pivots\\/July2020\\/6Flk56UKqJVAlTnG4GEg.jpg\"]', NULL, '2020-07-29 07:12:29', '2020-07-29 07:12:29', NULL),
(23, 6, 9, 'mod-interior-pivots/July2020/R2YP02h7WAo4MwifvGvs.jpg', '[\"mod-interior-pivots\\/July2020\\/BRz6ASDgJQkFT3daakf6.jpg\",\"mod-interior-pivots\\/July2020\\/Jo2X36ebPk2LvMU1cKP3.jpg\",\"mod-interior-pivots\\/July2020\\/0PJvPakTwT8ADyRIye3O.jpg\"]', NULL, '2020-07-29 07:20:58', '2020-07-29 07:20:58', NULL),
(24, 6, 10, 'mod-interior-pivots/July2020/p73qxMLDjyp8Vr0SgsDZ.jpg', '[\"mod-interior-pivots\\/July2020\\/YEqZ9YmVP1DZdyBp44HU.jpg\",\"mod-interior-pivots\\/July2020\\/TyKbh2NolW75WnG2CIDv.jpg\",\"mod-interior-pivots\\/July2020\\/5x3JmbaB7BSwr1hfJvBu.jpg\"]', NULL, '2020-07-29 07:22:14', '2020-07-29 07:22:14', NULL),
(25, 7, 11, 'mod-interior-pivots/July2020/EWpWV6OtSpzg3aNZaUqh.jpg', '[\"mod-interior-pivots\\/July2020\\/ffbfRuqg5uqMh20aiEgG.jpg\",\"mod-interior-pivots\\/July2020\\/dasXpS0BSdXfzF0so7EM.jpg\",\"mod-interior-pivots\\/July2020\\/qRCc5ouaDaJeLamKITG6.jpg\"]', NULL, '2020-07-29 07:25:05', '2020-07-29 07:25:05', NULL),
(26, 8, 12, 'mod-interior-pivots/November2020/tp55CwDNrS4jszKnnfXt.jpg', '[\"mod-interior-pivots\\/November2020\\/FUPuTdE62nfxbKPxPyLt.jpg\",\"mod-interior-pivots\\/November2020\\/0WL1vL0ZW9hnuy6PUU8z.jpg\",\"mod-interior-pivots\\/November2020\\/Vbmh5TficpjRwm30Sbti.jpg\"]', NULL, '2020-07-29 07:27:23', '2020-11-06 10:03:52', NULL),
(27, 18, 4, 'mod-interior-pivots/July2020/sxVR4USHvv9QfTRxkGYr.jpg', '[\"mod-interior-pivots\\/July2020\\/p3AwqICaULlDHSbTOn7N.jpg\",\"mod-interior-pivots\\/July2020\\/hZWrSaMLRqJV4GAbDJKv.jpg\",\"mod-interior-pivots\\/July2020\\/ivJOw8DEfrZzbhyqGT3b.jpg\"]', NULL, '2020-07-29 07:29:02', '2020-07-29 07:29:02', NULL),
(28, 19, 4, 'mod-interior-pivots/July2020/NH1yC8Dpd1njNBXJMdX1.jpg', '[\"mod-interior-pivots\\/July2020\\/zNYiPSSs53Vij1Ze5z8R.jpg\",\"mod-interior-pivots\\/July2020\\/dAClvdzHXcTP8nTw7tjl.jpg\",\"mod-interior-pivots\\/July2020\\/egAsedWAHRExx1BpEC2i.jpg\"]', NULL, '2020-07-29 07:30:37', '2020-07-29 07:30:37', NULL),
(29, 20, 1, 'mod-interior-pivots/July2020/6fMFS3fOmH0eq6CGDLCf.jpg', '[\"mod-interior-pivots\\/July2020\\/1To5XDZb3NVqvCDosw65.jpg\",\"mod-interior-pivots\\/July2020\\/IC83iur5d5j7faM3KxNp.jpg\",\"mod-interior-pivots\\/July2020\\/vP0gbF6energfcezJtVB.jpg\"]', NULL, '2020-07-29 11:42:34', '2020-07-29 11:42:34', NULL),
(30, 21, 13, 'mod-interior-pivots/July2020/8T0sKDPwdWW5ZQk0dxcg.jpg', '[\"mod-interior-pivots\\/July2020\\/9o08esDym67Ggv9N4UTg.jpg\",\"mod-interior-pivots\\/July2020\\/uZv8XNafWdzVgMSABgIl.jpg\",\"mod-interior-pivots\\/July2020\\/sJtTHI5MKLuRCBpZOBtr.jpg\"]', NULL, '2020-07-29 11:44:52', '2020-07-29 11:44:52', NULL),
(31, 22, 14, 'mod-interior-pivots/July2020/yrxy5pB4ftXqyDxOXnrn.jpg', '[\"mod-interior-pivots\\/July2020\\/3CKTpuyjCNbssfFRDY8h.jpg\",\"mod-interior-pivots\\/July2020\\/hMLCiqXMe38ONvyDtcnB.jpg\",\"mod-interior-pivots\\/July2020\\/oMEPN6pQzbBWl8j6k2EX.jpg\"]', NULL, '2020-07-29 11:47:08', '2020-07-29 11:47:08', NULL),
(32, 22, 7, 'mod-interior-pivots/July2020/VX4rSufxGgxCZBlPJLh8.jpg', '[\"mod-interior-pivots\\/July2020\\/sXlIjc26PBZGlCNB6cVE.jpg\",\"mod-interior-pivots\\/July2020\\/wS8JO96x7H3izWjRXChE.jpg\",\"mod-interior-pivots\\/July2020\\/xUupQlw7VPQVIfsRtCxz.jpg\"]', NULL, '2020-07-29 11:48:00', '2020-07-29 11:48:00', NULL),
(33, 22, 8, 'mod-interior-pivots/July2020/472mkH30nClf9TocYLCO.jpg', '[\"mod-interior-pivots\\/July2020\\/P9gDN5fk6nwVMM8Xdzt7.jpg\",\"mod-interior-pivots\\/July2020\\/Db4KfFf7B1E9yA4K9uz9.jpg\",\"mod-interior-pivots\\/July2020\\/PvUAMNjK0sIYObVM6EMV.jpg\"]', NULL, '2020-07-29 11:48:42', '2020-07-29 11:48:42', NULL),
(34, 26, 18, 'mod-interior-pivots/July2020/dZeJG7YYyMgpWLdnHdub.jpg', '[\"mod-interior-pivots\\/July2020\\/Sc2PugmhOPSFuEoYWzPw.jpg\",\"mod-interior-pivots\\/July2020\\/E9aRtlPabBbxrRn3S7PC.jpg\",\"mod-interior-pivots\\/July2020\\/nvBL6gXc207RB7I76ebH.jpg\"]', NULL, '2020-07-29 12:06:52', '2020-07-29 12:06:52', NULL),
(35, 26, 19, 'mod-interior-pivots/July2020/XQY6n5aT7KvupEqjBGWY.jpg', '[\"mod-interior-pivots\\/July2020\\/v2FhA0HybanO0ixk5UXA.jpg\",\"mod-interior-pivots\\/July2020\\/G7XlIa1PBtVaoJjn4VzS.jpg\",\"mod-interior-pivots\\/July2020\\/VE4Z7vXLvgRcOD7QSz37.jpg\"]', NULL, '2020-07-29 12:07:40', '2020-07-29 12:07:40', NULL),
(36, 27, 20, 'mod-interior-pivots/July2020/wXsdi5O744dSn61dCd7I.jpg', '[\"mod-interior-pivots\\/July2020\\/kHuYbmwKy8JNuXavHrRl.jpg\",\"mod-interior-pivots\\/July2020\\/HaQggrtN6WQzx5TPrNVr.jpg\",\"mod-interior-pivots\\/July2020\\/Z9wcGjamtIzbWw8vymZp.jpg\"]', NULL, '2020-07-29 12:12:05', '2020-07-29 12:12:05', NULL),
(37, 27, 21, 'mod-interior-pivots/July2020/5674stROJq2qBNcQjQGt.jpg', '[\"mod-interior-pivots\\/July2020\\/Pl4Vw3leRladxjZmOpIC.jpg\",\"mod-interior-pivots\\/July2020\\/50uwebmRdADXPA5zH7A8.jpg\",\"mod-interior-pivots\\/July2020\\/TajuDvx8uHQb6VOcImIW.jpg\"]', NULL, '2020-07-29 12:12:57', '2020-07-29 12:12:57', NULL),
(38, 27, 22, 'mod-interior-pivots/July2020/CUcfBinv8M4FX8Mnp0H8.jpg', '[\"mod-interior-pivots\\/July2020\\/L8In4mRUlM6fP7z5X018.jpg\",\"mod-interior-pivots\\/July2020\\/Lw8YHu2XnjoOpJ3mJSMt.jpg\",\"mod-interior-pivots\\/July2020\\/wOzN5tEwaKvxuuxVJwUI.jpg\"]', NULL, '2020-07-29 12:13:59', '2020-07-29 12:13:59', NULL),
(39, 28, 20, 'mod-interior-pivots/July2020/ubUInOrqGAb0xAgYfSjS.jpg', '[\"mod-interior-pivots\\/July2020\\/bnrmSphpReuOAOwCFryO.jpg\",\"mod-interior-pivots\\/July2020\\/IhQmwdoaY4pR20dswKrd.jpg\",\"mod-interior-pivots\\/July2020\\/mIO5AJWWLqD8BfTl7uXU.jpg\"]', NULL, '2020-07-29 12:15:25', '2020-07-29 12:15:25', NULL),
(40, 28, 21, 'mod-interior-pivots/July2020/Xt2ppcSZmm3S0WTeNiHJ.jpg', '[\"mod-interior-pivots\\/July2020\\/HlqlaVmhEutynpI6jROW.jpg\",\"mod-interior-pivots\\/July2020\\/V24xqdAFqnlGBH7upYOU.jpg\",\"mod-interior-pivots\\/July2020\\/B0rhDOZVydlyb9Yz13IW.jpg\"]', NULL, '2020-07-29 12:16:13', '2020-07-29 12:16:13', NULL),
(41, 28, 22, 'mod-interior-pivots/July2020/hS0j2S0lNJRPd7dRTLZu.jpg', '[\"mod-interior-pivots\\/July2020\\/xaw45v6tSFEu4NLyoWSz.jpg\",\"mod-interior-pivots\\/July2020\\/9mrwKgj8JwzNuoXr3SCM.jpg\",\"mod-interior-pivots\\/July2020\\/JcOItoHZulqvOXmQII6G.jpg\"]', NULL, '2020-07-29 12:16:55', '2020-07-29 12:16:55', NULL),
(42, 29, 23, 'mod-interior-pivots/July2020/NsdiawwIWjFhbvZRGxID.jpg', '[\"mod-interior-pivots\\/July2020\\/1x8TyaKPulIOXjyjh2wa.jpg\",\"mod-interior-pivots\\/July2020\\/0HLE7IQnrtDcWhstNXes.jpg\",\"mod-interior-pivots\\/July2020\\/n4uZRM5myBX50oLNrjhS.jpg\"]', NULL, '2020-07-29 12:19:29', '2020-07-29 12:19:29', NULL),
(43, 29, 24, 'mod-interior-pivots/July2020/1Z4SqIVgNAWb7DERBuZV.jpg', '[\"mod-interior-pivots\\/July2020\\/oK67EQHjbAJV3GaYIFk0.jpg\",\"mod-interior-pivots\\/July2020\\/fIa17tKEvMHf8401JaT9.jpg\",\"mod-interior-pivots\\/July2020\\/otW7jHb6tVVS6ThL7ydJ.jpg\"]', NULL, '2020-07-29 12:22:16', '2020-07-29 12:22:16', NULL),
(44, 29, 25, 'mod-interior-pivots/July2020/QxhJjhhVTIQ6izRJxhF4.jpg', '[\"mod-interior-pivots\\/July2020\\/J29ttWBkqBwT405o0Jlm.jpg\",\"mod-interior-pivots\\/July2020\\/3qB4QmHJRrG5bOkuvhFs.jpg\",\"mod-interior-pivots\\/July2020\\/6ZE7ZjW31xn9thOMXDvP.jpg\"]', NULL, '2020-07-29 12:23:02', '2020-07-29 12:23:02', NULL),
(45, 30, 26, 'mod-interior-pivots/July2020/RJ9fzWp6ky0PSAJWLgsx.jpg', '[\"mod-interior-pivots\\/July2020\\/rd6qngttczoOkIL9nnWs.jpg\",\"mod-interior-pivots\\/July2020\\/I1cckHegrAXbsQg7Rxkb.jpg\",\"mod-interior-pivots\\/July2020\\/gMwj8EjfGlyjffpQpBKt.jpg\"]', NULL, '2020-07-29 12:27:52', '2020-07-29 12:27:52', NULL),
(46, 30, 27, 'mod-interior-pivots/July2020/JhpO4tpKltkWjRznzF8V.jpg', '[\"mod-interior-pivots\\/July2020\\/zD2NMEvrfEDIbMEcl2Pi.jpg\",\"mod-interior-pivots\\/July2020\\/Pnd5HMj0TbUdYPUbTxwh.jpg\",\"mod-interior-pivots\\/July2020\\/bB8Vl0O6rxQ36zTFN9dG.jpg\"]', NULL, '2020-07-29 12:28:40', '2020-07-29 12:28:40', NULL),
(47, 30, 28, 'mod-interior-pivots/July2020/I027MQtyQ6kgcxSWg2X1.jpg', '[\"mod-interior-pivots\\/July2020\\/6iu1uOD7lljBb87RIEIP.jpg\",\"mod-interior-pivots\\/July2020\\/yknT64UiQdoltHhFLkBB.jpg\",\"mod-interior-pivots\\/July2020\\/KcZ6EOgfM8PbQZ3Q8qak.jpg\"]', NULL, '2020-07-29 12:29:28', '2020-07-29 12:29:28', NULL),
(48, 30, 29, 'mod-interior-pivots/July2020/JVt6enMnlvknhSLOIo1l.jpg', '[\"mod-interior-pivots\\/July2020\\/w2qGzqqoWQ5wc8Ukv0NJ.jpg\",\"mod-interior-pivots\\/July2020\\/BdFLUikplAQiDHLTnk0S.jpg\",\"mod-interior-pivots\\/July2020\\/8rpmjIlrWcQwVtJDO31T.jpg\"]', NULL, '2020-07-29 12:30:27', '2020-07-29 12:30:27', NULL),
(49, 37, 30, 'mod-interior-pivots/July2020/g02f0CfQGUjnnlUNBFtO.jpg', '[\"mod-interior-pivots\\/July2020\\/cidaWo94jr9I5GnrlDSa.jpg\",\"mod-interior-pivots\\/July2020\\/sHVPT1cNwNtxCZZTkfm9.jpg\",\"mod-interior-pivots\\/July2020\\/JhFRxUJJ51lqRgjKMO9j.jpg\"]', NULL, '2020-07-29 12:34:31', '2020-07-29 12:34:31', NULL),
(50, 37, 31, 'mod-interior-pivots/July2020/jyrESruOOrftGZEJWFMT.jpg', '[\"mod-interior-pivots\\/July2020\\/7ueljIAXiUnWMckOks7U.jpg\",\"mod-interior-pivots\\/July2020\\/jSVUiWtEPXKhSsWl2q9B.jpg\",\"mod-interior-pivots\\/July2020\\/qlpHX3gspFIZuWn5QV2P.jpg\"]', NULL, '2020-07-29 12:35:19', '2020-07-29 12:35:19', NULL),
(51, 37, 32, 'mod-interior-pivots/July2020/aWBvo6iJizduje6EvkRf.jpg', '[\"mod-interior-pivots\\/July2020\\/tUWP7IVypiZbeY6kTErE.jpg\",\"mod-interior-pivots\\/July2020\\/9ht3dnNPzm96mSzoPatF.jpg\",\"mod-interior-pivots\\/July2020\\/9GBg8netljrBfRMEBbsA.jpg\"]', NULL, '2020-07-29 12:36:18', '2020-07-29 12:36:18', NULL),
(52, 37, 33, 'mod-interior-pivots/July2020/JkTxBV83nPmQ3abit9tJ.jpg', '[\"mod-interior-pivots\\/July2020\\/WKdeKYjm96Lbq4m3gQwr.jpg\",\"mod-interior-pivots\\/July2020\\/4nZV5JAuY9lIDLZofd7D.jpg\",\"mod-interior-pivots\\/July2020\\/j8nin3l4fsaC59Cz1KAr.jpg\"]', NULL, '2020-07-29 12:37:14', '2020-07-29 12:37:14', NULL),
(53, 26, 34, 'mod-interior-pivots/August2020/Auh33tiUkhhgWXQyX8Kb.jpg', '[\"mod-interior-pivots\\/August2020\\/xlh4CRp6SGDVqfcznjLv.jpg\",\"mod-interior-pivots\\/August2020\\/gP2WkiutFNfTNcPXiHoX.jpg\",\"mod-interior-pivots\\/August2020\\/yPtf0irUUO4jbHk867Jj.jpg\"]', NULL, '2020-08-10 07:45:59', '2020-08-10 07:45:59', NULL),
(54, 26, 35, 'mod-interior-pivots/August2020/96aYCcgaZa7jDQXdqtqI.jpg', '[\"mod-interior-pivots\\/August2020\\/QuY7Carm0giCIPzyr1JW.jpg\",\"mod-interior-pivots\\/August2020\\/aL5d7p5IgZXs6utx4Kqq.jpg\",\"mod-interior-pivots\\/August2020\\/JpUquAjxMrPtVrNyXJ06.jpg\"]', NULL, '2020-08-10 07:47:16', '2020-08-10 07:47:16', NULL),
(55, 27, 36, 'mod-interior-pivots/August2020/X0auy1FAwqeCVupuvvF3.jpg', '[\"mod-interior-pivots\\/August2020\\/gBEMJhuHOaxh7YNHUAo4.jpg\",\"mod-interior-pivots\\/August2020\\/U7xLacuBm3MYiB07zYGr.jpg\",\"mod-interior-pivots\\/August2020\\/cosnl1DROpFTzK1cEf8s.jpg\"]', NULL, '2020-08-10 09:01:06', '2020-08-10 09:01:06', NULL),
(56, 27, 37, 'mod-interior-pivots/August2020/K4NRXq2hXi0P5VBkQvPn.jpg', '[\"mod-interior-pivots\\/August2020\\/Jm1fyAhDYjZ5UZn6qBmM.jpg\",\"mod-interior-pivots\\/August2020\\/hYfwPcVRwNmzbdnj0V58.jpg\",\"mod-interior-pivots\\/August2020\\/TjRW0JEnk90WnSJoRevi.jpg\"]', NULL, '2020-08-10 09:01:47', '2020-08-10 09:01:47', NULL),
(57, 24, 15, 'mod-interior-pivots/August2020/QHHDAndUNT1CzjLxVuQs.png', '[\"mod-interior-pivots\\/August2020\\/PCmDhdDdy7Don8Pn0Bra.png\"]', NULL, '2020-08-11 13:32:44', '2020-08-13 15:40:41', NULL),
(58, 24, 16, 'mod-interior-pivots/August2020/kn1J1kUdTWLoLePkS0jI.png', '[\"mod-interior-pivots\\/August2020\\/4LElrJKPFPTOwfmceJyZ.png\"]', NULL, '2020-08-11 13:33:12', '2020-08-13 15:41:39', NULL),
(59, 24, 17, 'mod-interior-pivots/August2020/vvMhsYT9wlhuTlx0BRnT.png', '[\"mod-interior-pivots\\/August2020\\/8gZVtHkbRLpCkfHCCspl.png\"]', NULL, '2020-08-11 13:33:45', '2020-08-13 15:42:09', NULL),
(60, 39, 7, 'mod-interior-pivots/August2020/5w64EfWWTnQPD78XqdBH.png', '[\"mod-interior-pivots\\/August2020\\/pCWE6phIzg58LMdYcJjL.png\"]', NULL, '2020-08-11 13:47:22', '2020-08-13 15:42:38', NULL),
(61, 39, 8, 'mod-interior-pivots/August2020/J6NsJID1TOUjCeSgu9EI.png', '[\"mod-interior-pivots\\/August2020\\/nsVP7xodnBc4zWtCz509.png\"]', NULL, '2020-08-11 13:47:54', '2020-08-13 15:43:11', NULL),
(62, 39, 38, 'mod-interior-pivots/August2020/7gKz6NS50zltwA0s2bnl.png', '[\"mod-interior-pivots\\/August2020\\/A778CE4zqVEf9sdMpJQ8.png\"]', NULL, '2020-08-11 13:48:32', '2020-08-13 15:43:41', NULL),
(63, 39, 14, 'mod-interior-pivots/August2020/wG15Grdc96ME7agkI9M8.png', '[\"mod-interior-pivots\\/August2020\\/WNLNSAxOB0ZoGxsWxbRt.png\"]', NULL, '2020-08-11 13:49:02', '2020-08-13 15:44:38', NULL),
(64, 33, 39, 'mod-interior-pivots/August2020/I30dS1qf5D8iB8ICf40g.png', '[\"mod-interior-pivots\\/August2020\\/FQ750qJGxMCK4d42dmLp.png\"]', NULL, '2020-08-17 08:01:30', '2020-08-17 08:03:25', NULL),
(65, 41, 40, 'mod-interior-pivots/September2020/5O7JOU6Tiuq0sUef05mp.jpg', '[\"mod-interior-pivots\\/September2020\\/yL4PaoWS2teWViMhVidN.jpg\",\"mod-interior-pivots\\/September2020\\/VI0uhDOsehwThADcOYaE.jpg\",\"mod-interior-pivots\\/September2020\\/WQ9rkMhqwBhiRA7xDoar.jpg\"]', NULL, '2020-09-07 08:22:38', '2020-09-07 08:22:38', NULL),
(66, 42, 41, 'mod-interior-pivots/November2020/XXF32ysyLMowl7c3kTLT.jpg', '[\"mod-interior-pivots\\/November2020\\/YIlvVVkgjXK7lgGNBou6.jpg\",\"mod-interior-pivots\\/November2020\\/TKPUXS09fT6mbMPCWE2c.jpg\",\"mod-interior-pivots\\/November2020\\/qdWcxRa4TGUKOYbc6Iiv.jpg\"]', NULL, '2020-11-05 09:50:18', '2020-11-05 09:50:18', NULL),
(67, 42, 42, 'mod-interior-pivots/November2020/Xpr2vmVXSMg4h2hrx8nd.jpg', '[\"mod-interior-pivots\\/November2020\\/5D3TsG0SYDbZ38iqOcPm.jpg\",\"mod-interior-pivots\\/November2020\\/C2y0rQZoAXwTUsJ84VIT.jpg\",\"mod-interior-pivots\\/November2020\\/R5M54FstxCIk8qdc7QGq.jpg\"]', NULL, '2020-11-05 09:51:24', '2020-11-05 09:51:24', NULL),
(68, 43, 43, 'mod-interior-pivots/November2020/q0spJ1jqdkgC7RUvdtUm.jpg', '[\"mod-interior-pivots\\/November2020\\/TPjMMhfEo3TA8eR9Paqw.jpg\",\"mod-interior-pivots\\/November2020\\/kUzoSbep30eTYrYG3kjD.jpg\",\"mod-interior-pivots\\/November2020\\/stw7fthq1OaxaIEDt9ig.jpg\"]', NULL, '2020-11-05 09:58:01', '2020-11-05 09:58:01', NULL),
(69, 43, 44, 'mod-interior-pivots/November2020/crkWmjKA1vw2CGeEAFvE.jpg', '[\"mod-interior-pivots\\/November2020\\/v3ZKX9qmZs6irI94kNzS.jpg\",\"mod-interior-pivots\\/November2020\\/FzKQu1AUa4lg4qEMwLzi.jpg\",\"mod-interior-pivots\\/November2020\\/gM5L7nXHcxCyjx7a5qyC.jpg\"]', NULL, '2020-11-05 09:58:48', '2020-11-05 09:58:48', NULL),
(70, 43, 45, 'mod-interior-pivots/November2020/698QVAzJa0WcEqhZe7s2.jpg', '[\"mod-interior-pivots\\/November2020\\/j0nwU0Y6Ks4MFkmRyeCJ.jpg\",\"mod-interior-pivots\\/November2020\\/BJPp3p8Uk710cDvAzdww.jpg\",\"mod-interior-pivots\\/November2020\\/1AqcDBJ72lzszYT3Pm5W.jpg\"]', NULL, '2020-11-05 09:59:50', '2020-11-05 09:59:50', NULL),
(71, 8, 48, 'mod-interior-pivots/November2020/FJHM9Okl6j0yZF1VapYl.jpg', '[\"mod-interior-pivots\\/November2020\\/LbzDZGR4emdTAMgyadHm.jpg\",\"mod-interior-pivots\\/November2020\\/A8nqmnDjNUC8n6cYYz05.jpg\",\"mod-interior-pivots\\/November2020\\/EKjELpV1LXw9qzWOyoob.jpg\"]', NULL, '2020-11-06 10:05:03', '2020-11-06 10:05:03', NULL),
(72, 8, 47, 'mod-interior-pivots/November2020/gHsPTPho9ItZkHuatNyp.jpg', '[\"mod-interior-pivots\\/November2020\\/mulc3C4XlOapABtChYLt.jpg\",\"mod-interior-pivots\\/November2020\\/qn4tlaYonhYOyPv5G0tB.jpg\",\"mod-interior-pivots\\/November2020\\/74q3IMbH6IFuPi1oXNH7.jpg\"]', NULL, '2020-11-06 10:06:04', '2020-11-06 10:06:04', NULL),
(73, 8, 46, 'mod-interior-pivots/November2020/xJBH3x8zvlHpfPIWiX04.jpg', '[\"mod-interior-pivots\\/November2020\\/Q3KwYcdq0VlxSOJI7CDQ.jpg\",\"mod-interior-pivots\\/November2020\\/No5wVKY7VZ1OJNdygSu4.jpg\",\"mod-interior-pivots\\/November2020\\/K0MJnKMb8o1lNpye5Gn8.jpg\"]', NULL, '2020-11-06 10:07:07', '2020-11-06 10:07:07', NULL),
(74, 2, 49, NULL, NULL, NULL, '2020-11-11 18:36:44', '2020-11-11 18:36:44', NULL),
(75, 4, 15, NULL, NULL, NULL, '2020-11-11 18:37:52', '2020-11-11 18:37:52', NULL),
(76, 1, 50, NULL, NULL, NULL, '2020-11-11 18:39:23', '2020-11-11 18:39:23', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `mod_wheel_pivots`
--

CREATE TABLE IF NOT EXISTS `mod_wheel_pivots` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `modification_id` int(11) DEFAULT NULL,
  `wheel_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `mod_wheel_pivots`
--

INSERT INTO `mod_wheel_pivots` (`id`, `modification_id`, `wheel_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 2, '2020-03-08 21:37:48', '2020-03-10 13:31:35', NULL),
(2, 4, 1, '2020-03-10 13:31:48', '2020-03-10 13:31:48', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `workers`
--

CREATE TABLE IF NOT EXISTS `workers` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisibleEmail` tinyint(4) DEFAULT NULL,
  `viber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisibleViber` tinyint(4) DEFAULT NULL,
  `telegram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisibleTelegram` tinyint(4) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisiblePhone` tinyint(4) DEFAULT NULL,
  `skype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisibleSkype` tinyint(4) DEFAULT NULL,
  `messenger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisibleMessenger` tinyint(4) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT NULL,
  `isFront` tinyint(4) DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posInList` tinyint(4) DEFAULT 100,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `workers`
--

INSERT INTO `workers` (`id`, `name`, `dep_id`, `email`, `isVisibleEmail`, `viber`, `isVisibleViber`, `telegram`, `isVisibleTelegram`, `phone`, `isVisiblePhone`, `skype`, `isVisibleSkype`, `messenger`, `isVisibleMessenger`, `isActive`, `isFront`, `position`, `photo`, `posInList`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 'Кротенко Андрій', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Начальник відділу сервісу', 'workers/May2020/eAy8sazplOOXT7mfBc9y.jpg', 89, NULL, '2020-08-21 07:56:44', NULL),
(5, 'Антощук Микола', 50, 'Nikolay.antoshchuk@kit-t.toyota.ua', 0, '+38 (067) 617 48 77', 1, NULL, 0, '380676174877', 0, NULL, 0, NULL, 0, 1, 1, 'Фахівець з гарантії ,сервісний консультант', 'workers/May2020/VqT3k8IqpL87Asw54UNf.jpg', 90, NULL, '2020-08-21 08:13:00', NULL),
(6, 'Гончаренко Денис', 50, 'Denis.Goncharenko@kit-t.toyota.ua', 0, '067 617 48 78', 1, NULL, 0, '0676174878', 1, NULL, 0, NULL, 0, 1, 0, 'Начальник відділу запасних частин і аксесуарів', 'workers/May2020/nEaUpj13IiU30XAouFe5.jpg', 98, NULL, '2020-08-25 08:12:30', NULL),
(7, 'Ткачук Вероніка', 30, 'Veronika.Tkachuk@kit-t.toyota.ua', 1, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Адміністратор сервісу ,фахівець по роботі з клієнтами', 'workers/May2020/iei9suwzCTyDUezaNcVv.jpg', 100, NULL, '2020-08-12 04:32:17', NULL),
(8, 'Шкуренко Тетяна', 50, 'Tatiana.shkurenko@kit-t.toyota.ua', 1, NULL, 1, NULL, 0, '380676174873', 1, NULL, 0, NULL, 0, 1, 1, 'Сервісний консультант', 'workers/May2020/fSNv744ZpiEF2pHVIxih.jpg', 91, NULL, '2020-08-21 07:56:58', NULL),
(10, 'Богатюк Юлія', 20, 'Julia.Bogatyuk@kit-t.toyota.ua', 1, '+38 (067) 617 48 71', 1, 'toyota_nikolaev', 1, '380676174871', 1, NULL, 0, NULL, 0, 1, 1, 'Молодший консультант відділу продажів', 'workers/May2020/ziHMFJSiMDnM3cp5YIOP.jpg', 5, NULL, '2020-08-26 05:39:28', NULL),
(11, 'Билінкіна Ірина', 30, NULL, 1, NULL, 1, NULL, 0, NULL, 1, NULL, 0, NULL, 0, 1, 0, 'Хостес', 'workers/October2020/bc80iBZXjwqZlM0q4LN3.jpg', 100, NULL, '2020-10-30 09:04:55', NULL),
(12, 'Оганесян Вікторія', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Комірник', 'workers/May2020/gmCQ0pQ82oI95QM3WfAW.jpg', 100, NULL, NULL, NULL),
(14, 'Сарницька Людмила', 30, 'Lyudmila.Sarnitskaya@kit-t.toyota.ua', 1, '+38 (067) 617 44 88', 1, NULL, 0, '380676174488', 1, NULL, 0, NULL, 0, 1, 0, 'Адміністратор відділу продажів, інспектор з кадрів', 'workers/May2020/NTkQSSTttgrCMN2D6UsV.jpg', 6, NULL, '2020-09-28 08:31:52', NULL),
(15, 'Мельничук Олена', 40, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Касир', 'workers/May2020/VtW6biZb7UwKij3v8Pej.jpg', 5, NULL, '2020-08-21 08:27:50', NULL),
(16, 'Власюк Інна', 40, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Головний бухгалтер', 'workers/May2020/N00xtbpGdUdSAi1XPRDi.jpg', 1, NULL, '2020-08-21 08:18:45', NULL),
(17, 'Власюк Віталій', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Начальник малярної ділянки', 'workers/May2020/ROOs5lsBdvImLApDNZjH.jpg', 100, NULL, NULL, NULL),
(18, 'Шишка Олег', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Механік', 'workers/May2020/95T6xVHYxsnfEmfc8EJ3.jpg', 100, NULL, NULL, NULL),
(19, 'Стожук Віктор', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Механік', 'workers/May2020/F0WaJWIF1tHbiBESjTHg.jpg', 100, NULL, NULL, NULL),
(20, 'Галімова Анна', 40, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Бухгалтер', 'workers/May2020/47zgN6bVIWe0UxfZcLBw.jpg', 2, NULL, '2020-08-27 05:10:41', NULL),
(21, 'Губанов Володимир', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Діагност-електрик', 'workers/May2020/fyG9I0BcTG3ejX0501d4.jpg', 100, NULL, NULL, NULL),
(22, 'Качура Василь', 60, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Водій', 'workers/May2020/i3SwCqIFxFq2jTFd76BJ.jpg', 100, NULL, '2020-08-19 07:34:33', NULL),
(23, 'Павленко Анатолій', 60, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Системний адміністратор', 'workers/May2020/GwpiP30e7GhiRrsI0N5G.jpg', 100, NULL, '2020-08-19 07:34:02', NULL),
(24, 'Гура Андрій', 60, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 0, 0, 'Сторож', 'workers/May2020/WmTUrGm2qW4UIZIdthLK.jpg', 100, NULL, '2020-08-19 07:32:44', NULL),
(25, 'Потеляха Павло', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Механік', 'workers/May2020/U0kMSyO6bMiGyUBGGlLI.jpg', 100, NULL, NULL, NULL),
(26, 'Лагдан Михайло', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Оператор мийної установки', 'workers/May2020/o9F7DarMlET7SaegTDzo.jpg', 100, NULL, NULL, NULL),
(27, 'Ніколовський Володимир', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Оператор мийної установки', 'workers/May2020/2FoPnDRY86o5pF76Q8Cp.jpg', 100, NULL, NULL, NULL),
(28, 'Чигир Оксана', 20, 'oksana.chyhyr@kit-t.toyota.ua', 1, '0676174477', 1, NULL, 0, '0676174477', 1, NULL, 0, NULL, 0, 1, 0, 'Фахівець з публічних закупівель та страхування, консультант по роботі з корпоративними клієнтами', 'workers/May2020/n6neRN0DvWEtIJ6zerUU.jpg', 7, NULL, '2020-08-25 06:04:14', NULL),
(29, 'Яцина Дар\'я', 20, 'Daria.Yatsyna@kit-t.toyota.ua', 1, '+38 067 617 48 72', 1, NULL, 0, '380676174872', 1, NULL, 0, NULL, 0, 1, 1, 'Начальник відділу продажів', 'workers/May2020/rwG81YS1lnwHsXgYmt8S.jpg', 3, NULL, '2020-08-21 05:14:33', NULL),
(30, 'Міщенко Ірина', 30, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Хостес', 'workers/November2020/UACHPooZO85SnKYojtZa.jpg', 100, NULL, '2020-11-02 08:33:58', NULL),
(32, 'Бурхачова Інна', 20, 'Inna.Burkhachova@kit-t.toyota.ua', 1, NULL, 0, NULL, 0, '0676174898', 1, NULL, 0, NULL, 0, 1, 0, 'Маркетолог, SMM менеджер', 'workers/May2020/4ogzrcNY1WOFIjOdlsxe.jpg', 100, NULL, NULL, NULL),
(33, 'Пак Станіслав', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Діагност-електрик', 'workers/May2020/IhK2ix2vPDKhL9Un7MO0.jpg', 100, NULL, NULL, NULL),
(34, 'Сукова Людмила', 60, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Прибиральник службових приміщень', 'workers/May2020/2znkgDZTRAwkpt7WxMB2.jpg', 100, NULL, '2020-08-19 07:32:17', NULL),
(35, 'Любенко Ірина', 60, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Прибиральник службових приміщень', 'workers/May2020/7qbr4OaChv8RQmKCcsvw.jpg', 100, NULL, '2020-08-19 07:29:59', NULL),
(38, 'Туріца Андрій', 10, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Директор', 'workers/May2020/BmtZ9ZZMRdB1FbLxwFjV.jpg', 1, NULL, '2020-08-12 04:36:58', NULL),
(39, 'Гетьман Агнеса', 60, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Прибиральник службових приміщень', 'workers/May2020/27tsQZi4dzuaVeebn8ic.jpg', 100, NULL, '2020-08-19 07:31:53', NULL),
(40, 'Кіяшко Володимир', 50, 'Vladimir.Kiyashko@kit-t.toyota.ua', 1, '067 671 48 76', 1, NULL, 0, '676714876', 1, NULL, 0, NULL, 0, 1, 1, 'Сервісний консультант', 'workers/June2020/h9OuK25ytlX6hCompKRj.jpg', 90, NULL, '2020-08-26 09:46:13', NULL),
(41, 'Леонова Тетяна', 20, 'Tatiana.Leonova@kit-t.toyota.ua', 1, NULL, 0, NULL, 0, '380676174874', 1, NULL, 0, 'toyotacentrnikolaev', 1, 1, 1, 'Старший консультант відділу продажів', 'workers/August2020/7GxRg9gD8mGmC2067gXE.jpg', 4, NULL, '2020-08-26 05:41:46', NULL),
(42, 'Ворчаков Денис', 50, 'Denis.Vorchakov@kit-t.toyota.ua', 1, '0676174499', 1, NULL, 0, '0676174499', 1, NULL, 0, NULL, 0, 1, 0, 'Менеджер відділу запчастин', 'workers/August2020/L7sSmVddJXMddTc5UBmE.jpg', 99, '2020-08-21 08:07:54', '2020-08-26 05:42:37', NULL),
(43, 'Шульга Ірина', 40, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Бухгалтер', 'workers/August2020/q2YYI4ZXHo38JWM6SmKj.jpg', 3, '2020-08-21 08:25:59', '2020-08-21 08:26:17', NULL),
(44, 'Слабік Наталія', 40, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Касир', 'workers/August2020/symXYkGy25eoRMOHwF4I.jpg', 4, '2020-08-21 08:27:27', '2020-08-26 09:45:03', NULL),
(45, 'Василенко Сергій', 50, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Механік', 'workers/August2020/OJD9ykueDOpo74eNppRh.jpg', 100, '2020-08-25 04:32:18', '2020-08-25 04:35:57', NULL),
(46, 'Кваша Олександр', 20, 'Oleksandr.kvasha@kit-t.toyota.ua', 1, '+38 (067) 617 44 55', 1, NULL, 0, '380676174455', 1, NULL, 0, NULL, 0, 1, 1, 'Консультант відділу продажів', 'workers/October2020/hjDYsxvnIB16s7A8wA04.jpg', 6, '2020-10-30 08:43:55', '2020-10-30 08:45:26', NULL),
(47, 'Крашенінніков Геннадій', 10, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, 1, 0, 'Комерційний директор', 'workers/December2020/RfdGCKR8YP76piU0qdji.jpg', 2, '2020-12-11 10:50:18', '2020-12-11 10:50:18', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `worker_deps`
--

CREATE TABLE IF NOT EXISTS `worker_deps` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name_dep` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `worker_deps`
--

INSERT INTO `worker_deps` (`id`, `name_dep`, `created_at`, `updated_at`, `deleted_at`) VALUES
(10, 'Керівництво', '2020-08-11 07:07:27', '2020-08-11 07:09:40', NULL),
(20, 'Менеджери', '2020-05-22 06:21:37', '2020-08-11 07:10:01', NULL),
(30, 'Адміністрація', '2020-05-22 06:21:08', '2020-08-11 07:09:22', NULL),
(40, 'Бухгалтерія', '2020-05-22 06:23:08', '2020-08-11 07:09:04', NULL),
(50, 'СТО', '2020-05-22 06:22:52', '2020-05-22 06:22:52', NULL),
(60, 'Персонал', '2020-08-11 07:07:43', '2020-08-11 07:07:43', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
